#SKD101|thetenni_CjeOEma|221|2009.05.26 10:12:28|2765|2|1|1|21|2|73|1|2|2|6|7|5|10|1|10|1|1|4|4|115|1|1|47|1|2|3|2|4|6|248|277|277|4|501|31|25|521|25|3|29|1|1|1|2|194|194|27|27|3|3|15|6|3|3|2|2|1|3

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;

SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `dxov_admin_assert`;
CREATE TABLE `dxov_admin_assert` (
  `assert_id` int(10) unsigned NOT NULL auto_increment,
  `assert_type` varchar(20) NOT NULL default '',
  `assert_data` text,
  PRIMARY KEY  (`assert_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='ACL Asserts';

DROP TABLE IF EXISTS `dxov_admin_role`;
CREATE TABLE `dxov_admin_role` (
  `role_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL default '0',
  `tree_level` tinyint(3) unsigned NOT NULL default '0',
  `sort_order` tinyint(3) unsigned NOT NULL default '0',
  `role_type` char(1) NOT NULL default '0',
  `user_id` int(11) unsigned NOT NULL default '0',
  `role_name` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`role_id`),
  KEY `parent_id` (`parent_id`,`sort_order`),
  KEY `tree_level` (`tree_level`)
) ENGINE=InnoDB AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='ACL Roles';

INSERT INTO `dxov_admin_role` VALUES
(1, 0, 1, 1, 'G', 0, 'Administrators'),
(3, 1, 2, 0, 'U', 2, 'Lance');

DROP TABLE IF EXISTS `dxov_admin_rule`;
CREATE TABLE `dxov_admin_rule` (
  `rule_id` int(10) unsigned NOT NULL auto_increment,
  `role_id` int(10) unsigned NOT NULL default '0',
  `resource_id` varchar(255) NOT NULL default '',
  `privileges` varchar(20) NOT NULL default '',
  `assert_id` int(10) unsigned NOT NULL default '0',
  `role_type` char(1) default NULL,
  `permission` varchar(10) default NULL,
  PRIMARY KEY  (`rule_id`),
  KEY `resource` (`resource_id`,`role_id`),
  KEY `role_id` (`role_id`,`resource_id`),
  CONSTRAINT `FK_admin_rule` FOREIGN KEY (`role_id`) REFERENCES `dxov_admin_role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='ACL Rules';

INSERT INTO `dxov_admin_rule` VALUES
(1, 1, 'all', '', 0, 'G', 'allow');

DROP TABLE IF EXISTS `dxov_admin_user`;
CREATE TABLE `dxov_admin_user` (
  `user_id` mediumint(9) unsigned NOT NULL auto_increment,
  `firstname` varchar(32) NOT NULL default '',
  `lastname` varchar(32) NOT NULL default '',
  `email` varchar(128) NOT NULL default '',
  `username` varchar(40) NOT NULL default '',
  `password` varchar(40) NOT NULL default '',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified` datetime default NULL,
  `logdate` datetime default NULL,
  `lognum` smallint(5) unsigned NOT NULL default '0',
  `reload_acl_flag` tinyint(1) NOT NULL default '0',
  `is_active` tinyint(1) NOT NULL default '1',
  `extra` text,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Users';

INSERT INTO `dxov_admin_user` VALUES
(2, 'Lance', 'Lvovsky', 'stringsdepotplus@yahoo.com', 'ttdepot92', '79dd7227d7e8dbfcda6258acf6e5b2d6:k5', '2009-05-25 13:46:14', '2009-05-25 13:46:14', '2009-05-26 16:59:28', 7, 0, 1, 'a:1:{s:11:\"configState\";a:31:{s:12:\"admin_emails\";s:1:\"0\";s:13:\"admin_startup\";s:1:\"0\";s:9:\"admin_url\";s:1:\"0\";s:14:\"admin_security\";s:1:\"0\";s:20:\"admin_fontis_wysiwyg\";s:1:\"1\";s:24:\"cataloginventory_options\";s:1:\"0\";s:29:\"cataloginventory_item_options\";s:1:\"1\";s:14:\"catalog_review\";s:1:\"0\";s:16:\"catalog_frontend\";s:1:\"0\";s:15:\"catalog_sitemap\";s:1:\"0\";s:20:\"catalog_productalert\";s:1:\"0\";s:25:\"catalog_productalert_cron\";s:1:\"0\";s:19:\"catalog_placeholder\";s:1:\"0\";s:25:\"catalog_recently_products\";s:1:\"0\";s:13:\"catalog_price\";s:1:\"0\";s:18:\"catalog_navigation\";s:1:\"0\";s:14:\"catalog_search\";s:1:\"0\";s:11:\"catalog_seo\";s:1:\"0\";s:20:\"catalog_downloadable\";s:1:\"0\";s:22:\"catalog_custom_options\";s:1:\"1\";s:25:\"trans_email_ident_general\";s:1:\"1\";s:23:\"trans_email_ident_sales\";s:1:\"1\";s:25:\"trans_email_ident_support\";s:1:\"1\";s:25:\"trans_email_ident_custom1\";s:1:\"1\";s:25:\"trans_email_ident_custom2\";s:1:\"1\";s:17:\"contacts_contacts\";s:1:\"1\";s:14:\"contacts_email\";s:1:\"1\";s:15:\"shipping_origin\";s:1:\"1\";s:15:\"shipping_option\";s:1:\"0\";s:29:\"livechatconfiguration_general\";s:1:\"1\";s:29:\"livechatconfiguration_display\";s:1:\"1\";}}');

DROP TABLE IF EXISTS `dxov_adminnotification_inbox`;
CREATE TABLE `dxov_adminnotification_inbox` (
  `notification_id` int(10) unsigned NOT NULL auto_increment,
  `severity` tinyint(3) unsigned NOT NULL default '0',
  `date_added` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `url` varchar(255) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL default '0',
  `is_remove` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`notification_id`),
  KEY `IDX_SEVERITY` (`severity`),
  KEY `IDX_IS_READ` (`is_read`),
  KEY `IDX_IS_REMOVE` (`is_remove`)
) ENGINE=InnoDB AUTO_INCREMENT=22 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_adminnotification_inbox` VALUES
(1, 4, '2008-07-25 01:24:40', 'Magento 1.1 Production Version Now Available', 'We are thrilled to announce the availability of the production release of Magento 1.1. Read more about the release in the Magento Blog.', 'http://www.magentocommerce.com/blog/comments/magento-11-is-here-1/', 0, 0),
(2, 4, '2008-08-02 01:30:16', 'Updated iPhone Theme is now available', 'Updated iPhone theme for Magento 1.1 is now available on Magento Connect and for upgrade through your Magento Connect Manager.', 'http://www.magentocommerce.com/blog/comments/updated-iphone-theme-for-magento-11-is-now-available/', 0, 0),
(3, 3, '2008-08-02 01:40:27', 'Magento version 1.1.2 is now available', 'Magento version 1.1.2 is now available for download and upgrade.', 'http://www.magentocommerce.com/blog/comments/magento-version-112-is-now-available/', 0, 0),
(4, 3, '2008-08-13 17:51:46', 'Magento version 1.1.3 is now available', 'Magento version 1.1.3 is now available', 'http://www.magentocommerce.com/blog/comments/magento-version-113-is-now-available/', 0, 0),
(5, 1, '2008-09-02 21:10:31', 'Magento Version 1.1.4 Security Update Now Available', 'Magento 1.1.4 Security Update Now Available. If you are using Magento version 1.1.x, we highly recommend upgrading to this version as soon as possible.', 'http://www.magentocommerce.com/blog/comments/magento-version-114-security-update/', 0, 0),
(6, 3, '2008-09-15 22:09:54', 'Magento version 1.1.5 Now Available', 'Magento version 1.1.5 Now Available.\n\nThis release includes many bug fixes, a new category manager and a new skin for the default Magento theme.', 'http://www.magentocommerce.com/blog/comments/magento-version-115-now-available/', 0, 0),
(7, 3, '2008-09-17 20:18:35', 'Magento version 1.1.6 Now Available', 'Magento version 1.1.6 Now Available.\n\nThis version includes bug fixes for Magento 1.1.x that are listed in the release notes section.', 'http://www.magentocommerce.com/blog/comments/magento-version-116-now-available/', 0, 0),
(8, 4, '2008-11-07 23:46:42', 'Reminder: Change Magento`s default phone numbers and callouts before site launch', 'Before launching your Magento store, please remember to change Magento`s default phone numbers that appear in email templates, callouts, templates, etc.', '', 0, 0),
(9, 3, '2008-11-20 01:31:12', 'Magento version 1.1.7 Now Available', 'Magento version 1.1.7 Now Available.\n\nThis version includes over 350 issue resolutions for Magento 1.1.x that are listed in the release notes section, and new functionality that includes:\n\n-Google Website Optimizer integration\n-Google Base integration\n-Scheduled DB logs cleaning option', 'http://www.magentocommerce.com/blog/comments/magento-version-117-now-available/', 0, 0),
(10, 3, '2008-11-26 21:24:50', 'Magento Version 1.1.8 Now Available', 'Magento version 1.1.8 now available.\n\nThis version includes some issue resolutions for Magento 1.1.x that are listed in the release notes section.', 'http://www.magentocommerce.com/blog/comments/magento-version-118-now-available/', 0, 0),
(11, 3, '2008-12-30 07:45:59', 'Magento version 1.2.0 is now available for download and upgrade', 'We are extremely happy to announce the availability of Magento version 1.2.0 for download and upgrade.\n\nThis version includes numerous issue resolutions for Magento version 1.1.x and some highly requested new features such as:\n\n    * Support for Downloadable/Digital Products. \n    * Added Layered Navigation to site search result page.\n    * Improved site search to utilize MySQL fulltext search\n    * Added support for fixed-taxes on product level.\n    * Upgraded Zend Framework to the latest stable version 1.7.2', 'http://www.magentocommerce.com/blog/comments/magento-version-120-is-now-available/', 0, 0),
(12, 2, '2008-12-30 21:59:22', 'Magento version 1.2.0.1 now available', 'Magento version 1.2.0.1 now available.This version includes some issue resolutions for Magento 1.2.x that are listed in the release notes section.', 'http://www.magentocommerce.com/blog/comments/magento-version-1201-available/', 0, 0),
(13, 2, '2009-01-12 20:41:49', 'Magento version 1.2.0.2 now available', 'Magento version 1.2.0.2 is now available for download and upgrade. This version includes an issue resolutions for Magento version 1.2.0.x as listed in the release notes.', 'http://www.magentocommerce.com/blog/comments/magento-version-1202-now-available/', 0, 0),
(14, 3, '2009-01-24 00:25:56', 'Magento version 1.2.0.3 now available', 'Magento version 1.2.0.3 is now available for download and upgrade. This version includes issue resolutions for Magento version 1.2.0.x as listed in the release notes.', 'http://www.magentocommerce.com/blog/comments/magento-version-1203-now-available/', 0, 0),
(15, 3, '2009-02-02 21:57:00', 'Magento version 1.2.1 is now available for download and upgrade', 'We are happy to announce the availability of Magento version 1.2.1 for download and upgrade.\n\nThis version includes some issue resolutions for Magento version 1.2.x. A full list of items included in this release can be found on the release notes page.', 'http://www.magentocommerce.com/blog/comments/magento-version-121-now-available/', 0, 0),
(16, 3, '2009-02-24 00:45:47', 'Magento version 1.2.1.1 now available', 'Magento version 1.2.1.1 now available.This version includes some issue resolutions for Magento 1.2.x that are listed in the release notes section.', 'http://www.magentocommerce.com/blog/comments/magento-version-1211-now-available/', 0, 0),
(17, 3, '2009-02-27 01:39:24', 'CSRF Attack Prevention', 'We have just posted a blog entry about a hypothetical CSRF attack on a Magento admin panel. Please read the post to find out if your Magento installation is at risk at http://www.magentocommerce.com/blog/comments/csrf-vulnerabilities-in-web-application-and-how-to-avoid-them-in-magento/', 'http://www.magentocommerce.com/blog/comments/csrf-vulnerabilities-in-web-application-and-how-to-avoid-them-in-magento/', 0, 0),
(18, 2, '2009-03-03 23:03:58', 'Magento version 1.2.1.2 now available', 'Magento version 1.2.1.2 is now available for download and upgrade.\nThis version includes some updates to improve admin security as described in the release notes page.', 'http://www.magentocommerce.com/blog/comments/magento-version-1212-now-available/', 0, 0),
(19, 3, '2009-03-31 02:22:40', 'Magento version 1.3.0 now available', 'Magento version 1.3.0 is now available for download and upgrade. This version includes numerous issue resolutions for Magento version 1.2.x and new features as described on the release notes page.', 'http://www.magentocommerce.com/blog/comments/magento-version-130-is-now-available/', 0, 0),
(20, 3, '2009-04-18 04:06:02', 'Magento version 1.3.1 now available', 'Magento version 1.3.1 is now available for download and upgrade. This version includes some issue resolutions for Magento version 1.3.x and new features such as Checkout By Amazon and Amazon Flexible Payment. To see a full list of updates please check the release notes page.', 'http://www.magentocommerce.com/blog/comments/magento-version-131-now-available/', 0, 0),
(21, 3, '2009-05-19 22:31:21', 'Magento version 1.3.1.1 now available', 'Magento version 1.3.1.1 is now available for download and upgrade. This version includes some issue resolutions for Magento version 1.3.x and a security update for Magento installations that run on multiple domains or sub-domains. If you are running Magento with multiple domains or sub-domains we highly recommend upgrading to this version.', 'http://www.magentocommerce.com/blog/comments/magento-version-1311-now-available/', 0, 0);

DROP TABLE IF EXISTS `dxov_amazonpayments_api_debug`;
CREATE TABLE `dxov_amazonpayments_api_debug` (
  `debug_id` int(10) unsigned NOT NULL auto_increment,
  `transaction_id` varchar(255) NOT NULL default '',
  `debug_at` timestamp NOT NULL /*!40101 default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP */,
  `request_body` text,
  `response_body` text,
  PRIMARY KEY  (`debug_id`),
  KEY `debug_at` (`debug_at`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_api_assert`;
CREATE TABLE `dxov_api_assert` (
  `assert_id` int(10) unsigned NOT NULL auto_increment,
  `assert_type` varchar(20) NOT NULL default '',
  `assert_data` text,
  PRIMARY KEY  (`assert_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Api ACL Asserts';

DROP TABLE IF EXISTS `dxov_api_role`;
CREATE TABLE `dxov_api_role` (
  `role_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL default '0',
  `tree_level` tinyint(3) unsigned NOT NULL default '0',
  `sort_order` tinyint(3) unsigned NOT NULL default '0',
  `role_type` char(1) NOT NULL default '0',
  `user_id` int(11) unsigned NOT NULL default '0',
  `role_name` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`role_id`),
  KEY `parent_id` (`parent_id`,`sort_order`),
  KEY `tree_level` (`tree_level`)
) ENGINE=InnoDB AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Api ACL Roles';

INSERT INTO `dxov_api_role` VALUES
(1, 0, 1, 0, 'G', 0, 'Live Chat'),
(5, 1, 1, 0, 'U', 3, 'Alex');

DROP TABLE IF EXISTS `dxov_api_rule`;
CREATE TABLE `dxov_api_rule` (
  `rule_id` int(10) unsigned NOT NULL auto_increment,
  `role_id` int(10) unsigned NOT NULL default '0',
  `resource_id` varchar(255) NOT NULL default '',
  `privileges` varchar(20) NOT NULL default '',
  `assert_id` int(10) unsigned NOT NULL default '0',
  `role_type` char(1) default NULL,
  `permission` varchar(10) default NULL,
  PRIMARY KEY  (`rule_id`),
  KEY `resource` (`resource_id`,`role_id`),
  KEY `role_id` (`role_id`,`resource_id`),
  CONSTRAINT `FK_api_rule` FOREIGN KEY (`role_id`) REFERENCES `dxov_api_role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=293 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Api ACL Rules';

INSERT INTO `dxov_api_rule` VALUES
(220, 1, 'all', '', 0, 'G', 'deny'),
(221, 1, 'directory', '', 0, 'G', 'deny'),
(222, 1, 'directory/country', '', 0, 'G', 'deny'),
(223, 1, 'directory/region', '', 0, 'G', 'deny'),
(224, 1, 'customer', '', 0, 'G', 'deny'),
(225, 1, 'customer/create', '', 0, 'G', 'deny'),
(226, 1, 'customer/update', '', 0, 'G', 'deny'),
(227, 1, 'customer/delete', '', 0, 'G', 'deny'),
(228, 1, 'customer/info', '', 0, 'G', 'deny'),
(229, 1, 'customer/address', '', 0, 'G', 'deny'),
(230, 1, 'customer/address/create', '', 0, 'G', 'deny'),
(231, 1, 'customer/address/update', '', 0, 'G', 'deny'),
(232, 1, 'customer/address/delete', '', 0, 'G', 'deny'),
(233, 1, 'customer/address/info', '', 0, 'G', 'deny'),
(234, 1, 'catalog', '', 0, 'G', 'deny'),
(235, 1, 'catalog/category', '', 0, 'G', 'deny'),
(236, 1, 'catalog/category/create', '', 0, 'G', 'deny'),
(237, 1, 'catalog/category/update', '', 0, 'G', 'deny'),
(238, 1, 'catalog/category/move', '', 0, 'G', 'deny'),
(239, 1, 'catalog/category/delete', '', 0, 'G', 'deny'),
(240, 1, 'catalog/category/tree', '', 0, 'G', 'deny'),
(241, 1, 'catalog/category/info', '', 0, 'G', 'deny'),
(242, 1, 'catalog/category/product', '', 0, 'G', 'deny'),
(243, 1, 'catalog/category/product/assign', '', 0, 'G', 'deny'),
(244, 1, 'catalog/category/product/update', '', 0, 'G', 'deny'),
(245, 1, 'catalog/category/product/remove', '', 0, 'G', 'deny'),
(246, 1, 'catalog/product', '', 0, 'G', 'deny'),
(247, 1, 'catalog/product/create', '', 0, 'G', 'deny'),
(248, 1, 'catalog/product/update', '', 0, 'G', 'deny'),
(249, 1, 'catalog/product/delete', '', 0, 'G', 'deny'),
(250, 1, 'catalog/product/update_tier_price', '', 0, 'G', 'deny'),
(251, 1, 'catalog/product/info', '', 0, 'G', 'deny'),
(252, 1, 'catalog/product/attribute', '', 0, 'G', 'deny'),
(253, 1, 'catalog/product/attribute/read', '', 0, 'G', 'deny'),
(254, 1, 'catalog/product/attribute/write', '', 0, 'G', 'deny'),
(255, 1, 'catalog/product/link', '', 0, 'G', 'deny'),
(256, 1, 'catalog/product/link/assign', '', 0, 'G', 'deny'),
(257, 1, 'catalog/product/link/update', '', 0, 'G', 'deny'),
(258, 1, 'catalog/product/link/remove', '', 0, 'G', 'deny'),
(259, 1, 'catalog/product/media', '', 0, 'G', 'deny'),
(260, 1, 'catalog/product/media/create', '', 0, 'G', 'deny'),
(261, 1, 'catalog/product/media/update', '', 0, 'G', 'deny'),
(262, 1, 'catalog/product/media/remove', '', 0, 'G', 'deny'),
(263, 1, 'sales', '', 0, 'G', 'deny'),
(264, 1, 'sales/order', '', 0, 'G', 'deny'),
(265, 1, 'sales/order/change', '', 0, 'G', 'deny'),
(266, 1, 'sales/order/info', '', 0, 'G', 'deny'),
(267, 1, 'sales/order/shipment', '', 0, 'G', 'deny'),
(268, 1, 'sales/order/shipment/create', '', 0, 'G', 'deny'),
(269, 1, 'sales/order/shipment/comment', '', 0, 'G', 'deny'),
(270, 1, 'sales/order/shipment/track', '', 0, 'G', 'deny'),
(271, 1, 'sales/order/shipment/info', '', 0, 'G', 'deny'),
(272, 1, 'sales/order/invoice', '', 0, 'G', 'deny'),
(273, 1, 'sales/order/invoice/create', '', 0, 'G', 'deny'),
(274, 1, 'sales/order/invoice/comment', '', 0, 'G', 'deny'),
(275, 1, 'sales/order/invoice/capture', '', 0, 'G', 'deny'),
(276, 1, 'sales/order/invoice/void', '', 0, 'G', 'deny'),
(277, 1, 'sales/order/invoice/cancel', '', 0, 'G', 'deny'),
(278, 1, 'sales/order/invoice/info', '', 0, 'G', 'deny'),
(279, 1, 'cataloginventory', '', 0, 'G', 'deny'),
(280, 1, 'cataloginventory/update', '', 0, 'G', 'deny'),
(281, 1, 'cataloginventory/info', '', 0, 'G', 'deny'),
(282, 1, 'livechat', '', 0, 'G', 'allow'),
(283, 1, 'livechat/getsessions', '', 0, 'G', 'allow'),
(284, 1, 'livechat/getmessages', '', 0, 'G', 'allow'),
(285, 1, 'livechat/sendmessage', '', 0, 'G', 'allow'),
(286, 1, 'livechat/operatorconnect', '', 0, 'G', 'allow'),
(287, 1, 'livechat/operatordisconnect', '', 0, 'G', 'allow'),
(288, 1, 'livechat/refreshmessages', '', 0, 'G', 'allow'),
(289, 1, 'livechat/refreshsessions', '', 0, 'G', 'allow'),
(290, 1, 'livechat/getallowedstores', '', 0, 'G', 'allow'),
(291, 1, 'livechat/closesession', '', 0, 'G', 'allow'),
(292, 1, 'livechat/updatesessions', '', 0, 'G', 'allow');

DROP TABLE IF EXISTS `dxov_api_user`;
CREATE TABLE `dxov_api_user` (
  `user_id` mediumint(9) unsigned NOT NULL auto_increment,
  `firstname` varchar(32) NOT NULL default '',
  `lastname` varchar(32) NOT NULL default '',
  `email` varchar(128) NOT NULL default '',
  `username` varchar(40) NOT NULL default '',
  `api_key` varchar(40) NOT NULL default '',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified` datetime default NULL,
  `logdate` datetime default NULL,
  `lognum` smallint(5) unsigned NOT NULL default '0',
  `sessid` varchar(40) NOT NULL,
  `reload_acl_flag` tinyint(1) NOT NULL default '0',
  `is_active` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Api Users';

INSERT INTO `dxov_api_user` VALUES
(3, 'Alex', 'Lvovsky', 'info@thetennisdepot.com', 'Alex', 'c466c0bcb4ca412988515e4e5612330f:2k', '2009-05-25 18:57:14', '2009-05-25 18:57:14', NULL, 0, '', 0, 1);

DROP TABLE IF EXISTS `dxov_catalog_category_entity`;
CREATE TABLE `dxov_catalog_category_entity` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `parent_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `path` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `children_count` int(11) NOT NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_LEVEL` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Category Entities';

INSERT INTO `dxov_catalog_category_entity` VALUES
(1, 3, 0, 0, '0000-00-00 00:00:00', '2009-05-25 13:43:26', '1', 1, 0, 1),
(2, 3, 3, 0, '2009-05-25 13:43:26', '2009-05-25 13:43:26', '1/2', 1, 1, 0);

DROP TABLE IF EXISTS `dxov_catalog_category_entity_datetime`;
CREATE TABLE `dxov_catalog_category_entity_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_DATETIME_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_DATETIME_STORE` (`store_id`),
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DATETIME_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DATETIME_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DATETIME_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_category_entity_decimal`;
CREATE TABLE `dxov_catalog_category_entity_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_DECIMAL_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_DECIMAL_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_DECIMAL_STORE` (`store_id`),
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DECIMAL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DECIMAL_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DECIMAL_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_category_entity_int`;
CREATE TABLE `dxov_catalog_category_entity_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_INT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_EMTITY_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_EMTITY_INT_STORE` (`store_id`),
  CONSTRAINT `FK_CATALOG_CATEGORY_EMTITY_INT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_CATEGORY_EMTITY_INT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_CATEGORY_EMTITY_INT_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_catalog_category_entity_int` VALUES
(1, 3, 32, 0, 2, 1),
(2, 3, 32, 1, 2, 1);

DROP TABLE IF EXISTS `dxov_catalog_category_entity_text`;
CREATE TABLE `dxov_catalog_category_entity_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_TEXT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_TEXT_STORE` (`store_id`),
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_TEXT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_TEXT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_TEXT_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_category_entity_varchar`;
CREATE TABLE `dxov_catalog_category_entity_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` USING BTREE (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_VARCHAR_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_VARCHAR_STORE` (`store_id`),
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_VARCHAR_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_VARCHAR_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_VARCHAR_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_catalog_category_entity_varchar` VALUES
(1, 3, 31, 0, 1, 'Root Catalog'),
(2, 3, 31, 1, 1, 'Root Catalog'),
(3, 3, 33, 0, 1, 'root-catalog'),
(4, 3, 31, 0, 2, 'Default Category'),
(5, 3, 39, 0, 2, 'PRODUCTS'),
(6, 3, 33, 0, 2, 'default-category');

DROP TABLE IF EXISTS `dxov_catalog_category_flat`;
CREATE TABLE `dxov_catalog_category_flat` (
  `entity_id` int(10) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `parent_id` int(10) unsigned NOT NULL default '0',
  `path` varchar(255) NOT NULL default '',
  `level` int(11) NOT NULL default '0',
  `position` int(11) NOT NULL default '0',
  `children_count` int(11) NOT NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  KEY `CATEGORY_FLAT_CATEGORY_ID` (`entity_id`),
  KEY `CATEGORY_FLAT_STORE_ID` (`store_id`),
  KEY `path` (`path`),
  KEY `IDX_LEVEL` (`level`),
  CONSTRAINT `FK_CATEGORY_FLAT_CATEGORY_ID` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATEGORY_FLAT_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Flat Category';

DROP TABLE IF EXISTS `dxov_catalog_category_product`;
CREATE TABLE `dxov_catalog_category_product` (
  `category_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `position` int(10) unsigned NOT NULL default '0',
  UNIQUE KEY `UNQ_CATEGORY_PRODUCT` (`category_id`,`product_id`),
  KEY `CATALOG_CATEGORY_PRODUCT_CATEGORY` (`category_id`),
  KEY `CATALOG_CATEGORY_PRODUCT_PRODUCT` (`product_id`),
  CONSTRAINT `CATALOG_CATEGORY_PRODUCT_CATEGORY` FOREIGN KEY (`category_id`) REFERENCES `dxov_catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CATALOG_CATEGORY_PRODUCT_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_category_product_index`;
CREATE TABLE `dxov_catalog_category_product_index` (
  `category_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `position` int(10) unsigned NOT NULL default '0',
  `is_parent` tinyint(1) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `visibility` tinyint(3) unsigned NOT NULL,
  UNIQUE KEY `UNQ_CATEGORY_PRODUCT` (`category_id`,`product_id`,`is_parent`,`store_id`),
  KEY `FK_CATALOG_CATEGORY_PRODUCT_INDEX_CATEGORY_ENTITY` (`category_id`),
  KEY `IDX_JOIN` (`product_id`,`store_id`,`category_id`,`visibility`),
  KEY `IDX_BASE` (`store_id`,`category_id`,`visibility`,`is_parent`,`position`),
  CONSTRAINT `FK_CATALOG_CATEGORY_PRODUCT_INDEX_CATEGORY_ENTITY` FOREIGN KEY (`category_id`) REFERENCES `dxov_catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_CATEGORY_PRODUCT_INDEX_PRODUCT_ENTITY` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATEGORY_PRODUCT_INDEX_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_compare_item`;
CREATE TABLE `dxov_catalog_compare_item` (
  `catalog_compare_item_id` int(11) unsigned NOT NULL auto_increment,
  `visitor_id` int(11) unsigned NOT NULL default '0',
  `customer_id` int(11) unsigned default NULL,
  `product_id` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`catalog_compare_item_id`),
  KEY `FK_CATALOG_COMPARE_ITEM_CUSTOMER` (`customer_id`),
  KEY `FK_CATALOG_COMPARE_ITEM_PRODUCT` (`product_id`),
  KEY `IDX_VISITOR_PRODUCTS` (`visitor_id`,`product_id`),
  KEY `IDX_CUSTOMER_PRODUCTS` (`customer_id`,`product_id`),
  CONSTRAINT `FK_CATALOG_COMPARE_ITEM_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_COMPARE_ITEM_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_bundle_option`;
CREATE TABLE `dxov_catalog_product_bundle_option` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `required` tinyint(1) unsigned NOT NULL default '0',
  `position` int(10) unsigned NOT NULL default '0',
  `type` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`option_id`),
  KEY `FK_CATALOG_PRODUCT_BUNDLE_OPTION_PARENT` (`parent_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_BUNDLE_OPTION_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Bundle Options';

DROP TABLE IF EXISTS `dxov_catalog_product_bundle_option_value`;
CREATE TABLE `dxov_catalog_product_bundle_option_value` (
  `value_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  KEY `FK_CATALOG_PRODUCT_BUNDLE_OPTION_VALUE_OPTION` (`option_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_BUNDLE_OPTION_VALUE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `dxov_catalog_product_bundle_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Bundle Selections';

DROP TABLE IF EXISTS `dxov_catalog_product_bundle_selection`;
CREATE TABLE `dxov_catalog_product_bundle_selection` (
  `selection_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL,
  `parent_product_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `position` int(10) unsigned NOT NULL default '0',
  `is_default` tinyint(1) unsigned NOT NULL default '0',
  `selection_price_type` tinyint(1) unsigned NOT NULL default '0',
  `selection_price_value` decimal(12,4) NOT NULL default '0.0000',
  `selection_qty` decimal(12,4) NOT NULL default '0.0000',
  `selection_can_change_qty` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`selection_id`),
  KEY `FK_CATALOG_PRODUCT_BUNDLE_SELECTION_OPTION` (`option_id`),
  KEY `FK_CATALOG_PRODUCT_BUNDLE_SELECTION_PRODUCT` (`product_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_BUNDLE_SELECTION_OPTION` FOREIGN KEY (`option_id`) REFERENCES `dxov_catalog_product_bundle_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_BUNDLE_SELECTION_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Bundle Selections';

DROP TABLE IF EXISTS `dxov_catalog_product_enabled_index`;
CREATE TABLE `dxov_catalog_product_enabled_index` (
  `product_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `visibility` smallint(5) unsigned NOT NULL default '0',
  UNIQUE KEY `UNQ_PRODUCT_STORE` (`product_id`,`store_id`),
  KEY `IDX_PRODUCT_VISIBILITY_IN_STORE` (`product_id`,`store_id`,`visibility`),
  KEY `FK_CATALOG_PRODUCT_ENABLED_INDEX_STORE` (`store_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_ENABLED_INDEX_PRODUCT_ENTITY` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENABLED_INDEX_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_entity`;
CREATE TABLE `dxov_catalog_product_entity` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `type_id` varchar(32) NOT NULL default 'simple',
  `sku` varchar(64) default NULL,
  `category_ids` text,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `has_options` smallint(1) NOT NULL default '0',
  PRIMARY KEY  (`entity_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_ATTRIBUTE_SET_ID` (`attribute_set_id`),
  KEY `sku` (`sku`),
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_ATTRIBUTE_SET_ID` FOREIGN KEY (`attribute_set_id`) REFERENCES `dxov_eav_attribute_set` (`attribute_set_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Product Entities';

DROP TABLE IF EXISTS `dxov_catalog_product_entity_datetime`;
CREATE TABLE `dxov_catalog_product_entity_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DATETIME_STORE` (`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DATETIME_PRODUCT_ENTITY` (`entity_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_DATETIME_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_DATETIME_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_DATETIME_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_entity_decimal`;
CREATE TABLE `dxov_catalog_product_entity_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DECIMAL_STORE` (`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DECIMAL_PRODUCT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DECIMAL_ATTRIBUTE` (`attribute_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_DECIMAL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_DECIMAL_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_DECIMAL_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_entity_gallery`;
CREATE TABLE `dxov_catalog_product_entity_gallery` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `position` int(11) NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_GALLERY_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_GALLERY_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_GALLERY_STORE` (`store_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_GALLERY_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_GALLERY_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_GALLERY_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_entity_int`;
CREATE TABLE `dxov_catalog_product_entity_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` mediumint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_INT_STORE` (`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_INT_PRODUCT_ENTITY` (`entity_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_INT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_INT_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_INT_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_entity_media_gallery`;
CREATE TABLE `dxov_catalog_product_entity_media_gallery` (
  `value_id` int(11) unsigned NOT NULL auto_increment,
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`value_id`),
  KEY `FK_CATALOG_PRODUCT_MEDIA_GALLERY_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_PRODUCT_MEDIA_GALLERY_ENTITY` (`entity_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_MEDIA_GALLERY_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_MEDIA_GALLERY_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Catalog product media gallery';

DROP TABLE IF EXISTS `dxov_catalog_product_entity_media_gallery_value`;
CREATE TABLE `dxov_catalog_product_entity_media_gallery_value` (
  `value_id` int(11) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `label` varchar(255) default NULL,
  `position` int(11) unsigned default NULL,
  `disabled` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`value_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_MEDIA_GALLERY_VALUE_STORE` (`store_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_MEDIA_GALLERY_VALUE_GALLERY` FOREIGN KEY (`value_id`) REFERENCES `dxov_catalog_product_entity_media_gallery` (`value_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_MEDIA_GALLERY_VALUE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Catalog product media gallery values';

DROP TABLE IF EXISTS `dxov_catalog_product_entity_text`;
CREATE TABLE `dxov_catalog_product_entity_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` mediumint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_TEXT_STORE` (`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_TEXT_PRODUCT_ENTITY` (`entity_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_TEXT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_TEXT_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_TEXT_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_entity_tier_price`;
CREATE TABLE `dxov_catalog_product_entity_tier_price` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_id` int(10) unsigned NOT NULL default '0',
  `all_groups` tinyint(1) unsigned NOT NULL default '1',
  `customer_group_id` smallint(5) unsigned NOT NULL default '0',
  `qty` decimal(12,4) NOT NULL default '1.0000',
  `value` decimal(12,4) NOT NULL default '0.0000',
  `website_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`value_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_TIER_PRICE_PRODUCT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_TIER_PRICE_GROUP` (`customer_group_id`),
  KEY `FK_CATALOG_PRODUCT_TIER_WEBSITE` (`website_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_TIER_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_TIER_PRICE_GROUP` FOREIGN KEY (`customer_group_id`) REFERENCES `dxov_customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_TIER_PRICE_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_entity_varchar`;
CREATE TABLE `dxov_catalog_product_entity_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` mediumint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_VARCHAR_STORE` (`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_VARCHAR_PRODUCT_ENTITY` (`entity_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_VARCHAR_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_VARCHAR_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_VARCHAR_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=131 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_link`;
CREATE TABLE `dxov_catalog_product_link` (
  `link_id` int(11) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `linked_product_id` int(10) unsigned NOT NULL default '0',
  `link_type_id` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`link_id`),
  KEY `FK_LINK_PRODUCT` (`product_id`),
  KEY `FK_LINKED_PRODUCT` (`linked_product_id`),
  KEY `FK_PRODUCT_LINK_TYPE` (`link_type_id`),
  CONSTRAINT `FK_PRODUCT_LINK_LINKED_PRODUCT` FOREIGN KEY (`linked_product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PRODUCT_LINK_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PRODUCT_LINK_TYPE` FOREIGN KEY (`link_type_id`) REFERENCES `dxov_catalog_product_link_type` (`link_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Related products';

DROP TABLE IF EXISTS `dxov_catalog_product_link_attribute`;
CREATE TABLE `dxov_catalog_product_link_attribute` (
  `product_link_attribute_id` smallint(6) unsigned NOT NULL auto_increment,
  `link_type_id` tinyint(3) unsigned NOT NULL default '0',
  `product_link_attribute_code` varchar(32) NOT NULL default '',
  `data_type` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`product_link_attribute_id`),
  KEY `FK_ATTRIBUTE_PRODUCT_LINK_TYPE` (`link_type_id`),
  CONSTRAINT `FK_ATTRIBUTE_PRODUCT_LINK_TYPE` FOREIGN KEY (`link_type_id`) REFERENCES `dxov_catalog_product_link_type` (`link_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Attributes for product link';

INSERT INTO `dxov_catalog_product_link_attribute` VALUES
(1, 2, 'qty', 'decimal'),
(2, 1, 'position', 'int'),
(3, 4, 'position', 'int'),
(4, 5, 'position', 'int'),
(6, 1, 'qty', 'decimal'),
(7, 3, 'position', 'int'),
(8, 3, 'qty', 'decimal');

DROP TABLE IF EXISTS `dxov_catalog_product_link_attribute_decimal`;
CREATE TABLE `dxov_catalog_product_link_attribute_decimal` (
  `value_id` int(11) unsigned NOT NULL auto_increment,
  `product_link_attribute_id` smallint(6) unsigned default NULL,
  `link_id` int(11) unsigned default NULL,
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  KEY `FK_DECIMAL_PRODUCT_LINK_ATTRIBUTE` (`product_link_attribute_id`),
  KEY `FK_DECIMAL_LINK` (`link_id`),
  CONSTRAINT `FK_DECIMAL_LINK` FOREIGN KEY (`link_id`) REFERENCES `dxov_catalog_product_link` (`link_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_DECIMAL_PRODUCT_LINK_ATTRIBUTE` FOREIGN KEY (`product_link_attribute_id`) REFERENCES `dxov_catalog_product_link_attribute` (`product_link_attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Decimal attributes values';

DROP TABLE IF EXISTS `dxov_catalog_product_link_attribute_int`;
CREATE TABLE `dxov_catalog_product_link_attribute_int` (
  `value_id` int(11) unsigned NOT NULL auto_increment,
  `product_link_attribute_id` smallint(6) unsigned default NULL,
  `link_id` int(11) unsigned default NULL,
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  KEY `FK_INT_PRODUCT_LINK_ATTRIBUTE` (`product_link_attribute_id`),
  KEY `FK_INT_PRODUCT_LINK` (`link_id`),
  CONSTRAINT `FK_INT_PRODUCT_LINK` FOREIGN KEY (`link_id`) REFERENCES `dxov_catalog_product_link` (`link_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_INT_PRODUCT_LINK_ATTRIBUTE` FOREIGN KEY (`product_link_attribute_id`) REFERENCES `dxov_catalog_product_link_attribute` (`product_link_attribute_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_link_attribute_varchar`;
CREATE TABLE `dxov_catalog_product_link_attribute_varchar` (
  `value_id` int(11) unsigned NOT NULL auto_increment,
  `product_link_attribute_id` smallint(6) unsigned NOT NULL default '0',
  `link_id` int(11) unsigned default NULL,
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  KEY `FK_VARCHAR_PRODUCT_LINK_ATTRIBUTE` (`product_link_attribute_id`),
  KEY `FK_VARCHAR_LINK` (`link_id`),
  CONSTRAINT `FK_VARCHAR_LINK` FOREIGN KEY (`link_id`) REFERENCES `dxov_catalog_product_link` (`link_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_VARCHAR_PRODUCT_LINK_ATTRIBUTE` FOREIGN KEY (`product_link_attribute_id`) REFERENCES `dxov_catalog_product_link_attribute` (`product_link_attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Varchar attributes values';

DROP TABLE IF EXISTS `dxov_catalog_product_link_type`;
CREATE TABLE `dxov_catalog_product_link_type` (
  `link_type_id` tinyint(3) unsigned NOT NULL auto_increment,
  `code` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`link_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Types of product link(Related, superproduct, bundles)';

INSERT INTO `dxov_catalog_product_link_type` VALUES
(1, 'relation'),
(2, 'bundle'),
(3, 'super'),
(4, 'up_sell'),
(5, 'cross_sell');

DROP TABLE IF EXISTS `dxov_catalog_product_option`;
CREATE TABLE `dxov_catalog_product_option` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `type` varchar(50) NOT NULL default '',
  `is_require` tinyint(1) NOT NULL default '1',
  `sku` varchar(64) NOT NULL default '',
  `max_characters` int(10) unsigned default NULL,
  `file_extension` varchar(50) default NULL,
  `image_size_x` smallint(5) unsigned NOT NULL,
  `image_size_y` smallint(5) unsigned NOT NULL,
  `sort_order` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`option_id`),
  KEY `CATALOG_PRODUCT_OPTION_PRODUCT` (`product_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_option_price`;
CREATE TABLE `dxov_catalog_product_option_price` (
  `option_price_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `price_type` enum('fixed','percent') NOT NULL default 'fixed',
  PRIMARY KEY  (`option_price_id`),
  KEY `CATALOG_PRODUCT_OPTION_PRICE_OPTION` (`option_id`),
  KEY `CATALOG_PRODUCT_OPTION_TITLE_STORE` (`store_id`),
  KEY `IDX_CATALOG_PRODUCT_OPTION_PRICE_SI_OI` (`store_id`,`option_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_PRICE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `dxov_catalog_product_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_PRICE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_option_title`;
CREATE TABLE `dxov_catalog_product_option_title` (
  `option_title_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`option_title_id`),
  KEY `CATALOG_PRODUCT_OPTION_TITLE_OPTION` (`option_id`),
  KEY `CATALOG_PRODUCT_OPTION_TITLE_STORE` (`store_id`),
  KEY `IDX_CATALOG_PRODUCT_OPTION_TITLE_SI_OI` (`store_id`,`option_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TITLE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `dxov_catalog_product_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_option_type_price`;
CREATE TABLE `dxov_catalog_product_option_type_price` (
  `option_type_price_id` int(10) unsigned NOT NULL auto_increment,
  `option_type_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `price_type` enum('fixed','percent') NOT NULL default 'fixed',
  PRIMARY KEY  (`option_type_price_id`),
  KEY `CATALOG_PRODUCT_OPTION_TYPE_PRICE_OPTION_TYPE` (`option_type_id`),
  KEY `CATALOG_PRODUCT_OPTION_TYPE_PRICE_STORE` (`store_id`),
  KEY `IDX_CATALOG_PRODUCT_OPTION_TYPE_PRICE_SI_OTI` (`store_id`,`option_type_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TYPE_PRICE_OPTION` FOREIGN KEY (`option_type_id`) REFERENCES `dxov_catalog_product_option_type_value` (`option_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TYPE_PRICE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_option_type_title`;
CREATE TABLE `dxov_catalog_product_option_type_title` (
  `option_type_title_id` int(10) unsigned NOT NULL auto_increment,
  `option_type_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`option_type_title_id`),
  KEY `CATALOG_PRODUCT_OPTION_TYPE_TITLE_OPTION` (`option_type_id`),
  KEY `CATALOG_PRODUCT_OPTION_TYPE_TITLE_STORE` (`store_id`),
  KEY `IDX_CATALOG_PRODUCT_OPTION_TYPE_TITLE_SI_OTI` (`store_id`,`option_type_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TYPE_TITLE_OPTION` FOREIGN KEY (`option_type_id`) REFERENCES `dxov_catalog_product_option_type_value` (`option_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TYPE_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_option_type_value`;
CREATE TABLE `dxov_catalog_product_option_type_value` (
  `option_type_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL default '0',
  `sku` varchar(64) NOT NULL default '',
  `sort_order` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`option_type_id`),
  KEY `CATALOG_PRODUCT_OPTION_TYPE_VALUE_OPTION` (`option_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TYPE_VALUE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `dxov_catalog_product_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_super_attribute`;
CREATE TABLE `dxov_catalog_product_super_attribute` (
  `product_super_attribute_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `position` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`product_super_attribute_id`),
  KEY `FK_SUPER_PRODUCT_ATTRIBUTE_PRODUCT` (`product_id`),
  CONSTRAINT `FK_SUPER_PRODUCT_ATTRIBUTE_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_super_attribute_label`;
CREATE TABLE `dxov_catalog_product_super_attribute_label` (
  `value_id` int(10) unsigned NOT NULL auto_increment,
  `product_super_attribute_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  KEY `FK_SUPER_PRODUCT_ATTRIBUTE_LABEL` (`product_super_attribute_id`),
  KEY `IDX_CATALOG_PRODUCT_SUPER_ATTRIBUTE_STORE_PSAI_SI` (`product_super_attribute_id`,`store_id`),
  CONSTRAINT `FK_SUPER_PRODUCT_ATTRIBUTE_LABEL` FOREIGN KEY (`product_super_attribute_id`) REFERENCES `dxov_catalog_product_super_attribute` (`product_super_attribute_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `dxov_catalog_product_super_attribute_pricing`;
CREATE TABLE `dxov_catalog_product_super_attribute_pricing` (
  `value_id` int(10) unsigned NOT NULL auto_increment,
  `product_super_attribute_id` int(10) unsigned NOT NULL default '0',
  `value_index` varchar(255) NOT NULL default '',
  `is_percent` tinyint(1) unsigned default '0',
  `pricing_value` decimal(10,4) default NULL,
  `website_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  KEY `FK_SUPER_PRODUCT_ATTRIBUTE_PRICING` (`product_super_attribute_id`),
  KEY `FK_CATALOG_PRODUCT_SUPER_PRICE_WEBSITE` (`website_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_SUPER_PRICE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SUPER_PRODUCT_ATTRIBUTE_PRICING` FOREIGN KEY (`product_super_attribute_id`) REFERENCES `dxov_catalog_product_super_attribute` (`product_super_attribute_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_super_link`;
CREATE TABLE `dxov_catalog_product_super_link` (
  `link_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `parent_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`link_id`),
  KEY `FK_SUPER_PRODUCT_LINK_PARENT` (`parent_id`),
  KEY `FK_catalog_product_super_link` (`product_id`),
  CONSTRAINT `FK_SUPER_PRODUCT_LINK_ENTITY` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_SUPER_PRODUCT_LINK_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalog_product_website`;
CREATE TABLE `dxov_catalog_product_website` (
  `product_id` int(10) unsigned NOT NULL auto_increment,
  `website_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`product_id`,`website_id`),
  KEY `FK_CATALOG_PRODUCT_WEBSITE_WEBSITE` (`website_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_catalog_product_website` VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1);

DROP TABLE IF EXISTS `dxov_catalogindex_aggregation`;
CREATE TABLE `dxov_catalogindex_aggregation` (
  `aggregation_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `key` varchar(255) default NULL,
  `data` mediumtext,
  PRIMARY KEY  (`aggregation_id`),
  UNIQUE KEY `IDX_STORE_KEY` (`store_id`,`key`),
  CONSTRAINT `FK_CATALOGINDEX_AGGREGATION_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalogindex_aggregation_tag`;
CREATE TABLE `dxov_catalogindex_aggregation_tag` (
  `tag_id` int(10) unsigned NOT NULL auto_increment,
  `tag_code` varchar(255) NOT NULL,
  PRIMARY KEY  (`tag_id`),
  UNIQUE KEY `IDX_CODE` (`tag_code`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalogindex_aggregation_to_tag`;
CREATE TABLE `dxov_catalogindex_aggregation_to_tag` (
  `aggregation_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `IDX_AGGREGATION_TAG` (`aggregation_id`,`tag_id`),
  KEY `FK_CATALOGINDEX_AGGREGATION_TO_TAG_TAG` (`tag_id`),
  CONSTRAINT `FK_CATALOGINDEX_AGGREGATION_TO_TAG_AGGREGATION` FOREIGN KEY (`aggregation_id`) REFERENCES `dxov_catalogindex_aggregation` (`aggregation_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOGINDEX_AGGREGATION_TO_TAG_TAG` FOREIGN KEY (`tag_id`) REFERENCES `dxov_catalogindex_aggregation_tag` (`tag_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalogindex_eav`;
CREATE TABLE `dxov_catalogindex_eav` (
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`store_id`,`entity_id`,`attribute_id`,`value`),
  KEY `IDX_VALUE` (`value`),
  KEY `FK_CATALOGINDEX_EAV_ENTITY` (`entity_id`),
  KEY `FK_CATALOGINDEX_EAV_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOGINDEX_EAV_STORE` (`store_id`),
  CONSTRAINT `FK_CATALOGINDEX_EAV_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOGINDEX_EAV_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOGINDEX_EAV_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalogindex_minimal_price`;
CREATE TABLE `dxov_catalogindex_minimal_price` (
  `index_id` int(10) unsigned NOT NULL auto_increment,
  `entity_id` int(10) unsigned NOT NULL default '0',
  `customer_group_id` smallint(3) unsigned NOT NULL default '0',
  `qty` decimal(12,4) unsigned NOT NULL default '0.0000',
  `value` decimal(12,4) NOT NULL default '0.0000',
  `tax_class_id` smallint(6) NOT NULL default '0',
  `website_id` smallint(5) unsigned default NULL,
  PRIMARY KEY  (`index_id`),
  KEY `IDX_VALUE` (`value`),
  KEY `IDX_QTY` (`qty`),
  KEY `FK_CATALOGINDEX_MINIMAL_PRICE_CUSTOMER_GROUP` (`customer_group_id`),
  KEY `FK_CI_MINIMAL_PRICE_WEBSITE_ID` (`website_id`),
  KEY `IDX_FULL` (`entity_id`,`qty`,`customer_group_id`,`value`,`website_id`),
  CONSTRAINT `FK_CATALOGINDEX_MINIMAL_PRICE_CUSTOMER_GROUP` FOREIGN KEY (`customer_group_id`) REFERENCES `dxov_customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOGINDEX_MINIMAL_PRICE_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CI_MINIMAL_PRICE_WEBSITE_ID` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalogindex_price`;
CREATE TABLE `dxov_catalogindex_price` (
  `entity_id` int(10) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `customer_group_id` smallint(3) unsigned NOT NULL default '0',
  `qty` decimal(12,4) unsigned NOT NULL default '0.0000',
  `value` decimal(12,4) NOT NULL default '0.0000',
  `tax_class_id` smallint(6) NOT NULL default '0',
  `website_id` smallint(5) unsigned default NULL,
  KEY `IDX_VALUE` (`value`),
  KEY `IDX_QTY` (`qty`),
  KEY `FK_CATALOGINDEX_PRICE_ENTITY` (`entity_id`),
  KEY `FK_CATALOGINDEX_PRICE_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOGINDEX_PRICE_CUSTOMER_GROUP` (`customer_group_id`),
  KEY `IDX_RANGE_VALUE` (`entity_id`,`attribute_id`,`customer_group_id`,`value`),
  KEY `FK_CI_PRICE_WEBSITE_ID` (`website_id`),
  KEY `IDX_FULL` (`entity_id`,`attribute_id`,`customer_group_id`,`value`,`website_id`),
  CONSTRAINT `FK_CATALOGINDEX_PRICE_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOGINDEX_PRICE_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CI_PRICE_WEBSITE_ID` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_cataloginventory_stock`;
CREATE TABLE `dxov_cataloginventory_stock` (
  `stock_id` smallint(4) unsigned NOT NULL auto_increment,
  `stock_name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`stock_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Catalog inventory Stocks list';

INSERT INTO `dxov_cataloginventory_stock` VALUES
(1, 'Default');

DROP TABLE IF EXISTS `dxov_cataloginventory_stock_item`;
CREATE TABLE `dxov_cataloginventory_stock_item` (
  `item_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `stock_id` smallint(4) unsigned NOT NULL default '0',
  `qty` decimal(12,4) NOT NULL default '0.0000',
  `min_qty` decimal(12,4) NOT NULL default '0.0000',
  `use_config_min_qty` tinyint(1) unsigned NOT NULL default '1',
  `is_qty_decimal` tinyint(1) unsigned NOT NULL default '0',
  `backorders` tinyint(3) unsigned NOT NULL default '0',
  `use_config_backorders` tinyint(1) unsigned NOT NULL default '1',
  `min_sale_qty` decimal(12,4) NOT NULL default '1.0000',
  `use_config_min_sale_qty` tinyint(1) unsigned NOT NULL default '1',
  `max_sale_qty` decimal(12,4) NOT NULL default '0.0000',
  `use_config_max_sale_qty` tinyint(1) unsigned NOT NULL default '1',
  `is_in_stock` tinyint(1) unsigned NOT NULL default '0',
  `low_stock_date` datetime default NULL,
  `notify_stock_qty` decimal(12,4) default NULL,
  `use_config_notify_stock_qty` tinyint(1) unsigned NOT NULL default '1',
  `manage_stock` tinyint(1) unsigned NOT NULL default '0',
  `use_config_manage_stock` tinyint(1) unsigned NOT NULL default '1',
  `stock_status_changed_automatically` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`item_id`),
  UNIQUE KEY `IDX_STOCK_PRODUCT` (`product_id`,`stock_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_ITEM_PRODUCT` (`product_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_ITEM_STOCK` (`stock_id`),
  CONSTRAINT `FK_CATALOGINVENTORY_STOCK_ITEM_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOGINVENTORY_STOCK_ITEM_STOCK` FOREIGN KEY (`stock_id`) REFERENCES `dxov_cataloginventory_stock` (`stock_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Inventory Stock Item Data';

DROP TABLE IF EXISTS `dxov_cataloginventory_stock_status`;
CREATE TABLE `dxov_cataloginventory_stock_status` (
  `product_id` int(10) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `stock_id` smallint(4) unsigned NOT NULL,
  `qty` decimal(12,4) NOT NULL default '0.0000',
  `stock_status` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY  (`product_id`,`website_id`,`stock_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_STATUS_STOCK` (`stock_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_STATUS_WEBSITE` (`website_id`),
  CONSTRAINT `FK_CATALOGINVENTORY_STOCK_STATUS_STOCK` FOREIGN KEY (`stock_id`) REFERENCES `dxov_cataloginventory_stock` (`stock_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOGINVENTORY_STOCK_STATUS_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOGINVENTORY_STOCK_STATUS_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalogrule`;
CREATE TABLE `dxov_catalogrule` (
  `rule_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `from_date` date default NULL,
  `to_date` date default NULL,
  `customer_group_ids` varchar(255) NOT NULL default '',
  `is_active` tinyint(1) NOT NULL default '0',
  `conditions_serialized` mediumtext NOT NULL,
  `actions_serialized` mediumtext NOT NULL,
  `stop_rules_processing` tinyint(1) NOT NULL default '1',
  `sort_order` int(10) unsigned NOT NULL default '0',
  `simple_action` varchar(32) NOT NULL,
  `discount_amount` decimal(12,4) NOT NULL,
  `website_ids` text,
  PRIMARY KEY  (`rule_id`),
  KEY `sort_order` (`is_active`,`sort_order`,`to_date`,`from_date`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalogrule_affected_product`;
CREATE TABLE `dxov_catalogrule_affected_product` (
  `product_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`product_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalogrule_product`;
CREATE TABLE `dxov_catalogrule_product` (
  `rule_product_id` int(10) unsigned NOT NULL auto_increment,
  `rule_id` int(10) unsigned NOT NULL default '0',
  `from_time` int(10) unsigned NOT NULL default '0',
  `to_time` int(10) unsigned NOT NULL default '0',
  `customer_group_id` smallint(5) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `action_operator` enum('to_fixed','to_percent','by_fixed','by_percent') NOT NULL default 'to_fixed',
  `action_amount` decimal(12,4) NOT NULL default '0.0000',
  `action_stop` tinyint(1) NOT NULL default '0',
  `sort_order` int(10) unsigned NOT NULL default '0',
  `website_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`rule_product_id`),
  UNIQUE KEY `sort_order` (`rule_id`,`from_time`,`to_time`,`website_id`,`customer_group_id`,`product_id`,`sort_order`),
  KEY `FK_catalogrule_product_rule` (`rule_id`),
  KEY `FK_catalogrule_product_customergroup` (`customer_group_id`),
  KEY `FK_catalogrule_product_website` (`website_id`),
  KEY `FK_CATALOGRULE_PRODUCT_PRODUCT` (`product_id`),
  CONSTRAINT `FK_CATALOGRULE_PRODUCT_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_catalogrule_product_customergroup` FOREIGN KEY (`customer_group_id`) REFERENCES `dxov_customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_catalogrule_product_rule` FOREIGN KEY (`rule_id`) REFERENCES `dxov_catalogrule` (`rule_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_catalogrule_product_website` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalogrule_product_price`;
CREATE TABLE `dxov_catalogrule_product_price` (
  `rule_product_price_id` int(10) unsigned NOT NULL auto_increment,
  `rule_date` date NOT NULL default '0000-00-00',
  `customer_group_id` smallint(5) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `rule_price` decimal(12,4) NOT NULL default '0.0000',
  `website_id` smallint(5) unsigned NOT NULL,
  `latest_start_date` date default NULL,
  `earliest_end_date` date default NULL,
  PRIMARY KEY  (`rule_product_price_id`),
  UNIQUE KEY `rule_date` (`rule_date`,`website_id`,`customer_group_id`,`product_id`),
  KEY `FK_catalogrule_product_price_customergroup` (`customer_group_id`),
  KEY `FK_catalogrule_product_price_website` (`website_id`),
  KEY `FK_CATALOGRULE_PRODUCT_PRICE_PRODUCT` (`product_id`),
  CONSTRAINT `FK_CATALOGRULE_PRODUCT_PRICE_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_catalogrule_product_price_customergroup` FOREIGN KEY (`customer_group_id`) REFERENCES `dxov_customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_catalogrule_product_price_website` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalogsearch_fulltext`;
CREATE TABLE `dxov_catalogsearch_fulltext` (
  `product_id` int(10) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `data_index` longtext NOT NULL,
  PRIMARY KEY  (`product_id`,`store_id`),
  FULLTEXT KEY `data_index` (`data_index`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_catalogsearch_fulltext` VALUES
(1, 1, '  '),
(2, 1, '  '),
(3, 1, '  '),
(4, 1, '  '),
(5, 1, '  '),
(6, 1, '  '),
(7, 1, '  '),
(8, 1, '  '),
(9, 1, '  '),
(10, 1, '  ');

DROP TABLE IF EXISTS `dxov_catalogsearch_query`;
CREATE TABLE `dxov_catalogsearch_query` (
  `query_id` int(10) unsigned NOT NULL auto_increment,
  `query_text` varchar(255) NOT NULL default '',
  `num_results` int(10) unsigned NOT NULL default '0',
  `popularity` int(10) unsigned NOT NULL default '0',
  `redirect` varchar(255) NOT NULL default '',
  `synonim_for` varchar(255) NOT NULL default '',
  `store_id` smallint(5) unsigned NOT NULL,
  `display_in_terms` tinyint(1) NOT NULL default '1',
  `is_active` tinyint(1) default '1',
  `is_processed` tinyint(1) default '0',
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`query_id`),
  KEY `FK_CATALOGSEARCH_QUERY_STORE` (`store_id`),
  KEY `IDX_SEARCH_QUERY` (`query_text`,`store_id`,`popularity`),
  CONSTRAINT `FK_CATALOGSEARCH_QUERY_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_catalogsearch_result`;
CREATE TABLE `dxov_catalogsearch_result` (
  `query_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `relevance` decimal(6,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`query_id`,`product_id`),
  KEY `IDX_QUERY` (`query_id`),
  KEY `IDX_PRODUCT` (`product_id`),
  KEY `IDX_RELEVANCE` (`query_id`,`relevance`),
  CONSTRAINT `FK_CATALOGSEARCH_RESULT_QUERY` FOREIGN KEY (`query_id`) REFERENCES `dxov_catalogsearch_query` (`query_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOGSEARCH_RESULT_CATALOG_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_checkout_agreement`;
CREATE TABLE `dxov_checkout_agreement` (
  `agreement_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `content` text NOT NULL,
  `content_height` varchar(25) default NULL,
  `checkbox_text` text NOT NULL,
  `is_active` tinyint(4) NOT NULL default '0',
  `is_html` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`agreement_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_checkout_agreement_store`;
CREATE TABLE `dxov_checkout_agreement_store` (
  `agreement_id` int(10) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  UNIQUE KEY `agreement_id` (`agreement_id`,`store_id`),
  KEY `FK_CHECKOUT_AGREEMENT_STORE` (`store_id`),
  CONSTRAINT `FK_CHECKOUT_AGREEMENT` FOREIGN KEY (`agreement_id`) REFERENCES `dxov_checkout_agreement` (`agreement_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CHECKOUT_AGREEMENT_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_cms_block`;
CREATE TABLE `dxov_cms_block` (
  `block_id` smallint(6) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `identifier` varchar(255) NOT NULL default '',
  `content` text,
  `creation_time` datetime default NULL,
  `update_time` datetime default NULL,
  `is_active` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`block_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='CMS Blocks';

INSERT INTO `dxov_cms_block` VALUES
(5, 'Footer Links', 'footer_links', '<ul>\r\n<li><a href=\"{{store url=\"\"}}about-magento-demo-store\">About Us</a></li>\r\n<li class=\"last\"><a href=\"{{store url=\"\"}}customer-service\">Customer Service</a></li>\r\n</ul>', '2009-05-25 06:43:56', '2009-05-25 06:43:56', 1);

DROP TABLE IF EXISTS `dxov_cms_block_store`;
CREATE TABLE `dxov_cms_block_store` (
  `block_id` smallint(6) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`block_id`,`store_id`),
  KEY `FK_CMS_BLOCK_STORE_STORE` (`store_id`),
  CONSTRAINT `FK_CMS_BLOCK_STORE_BLOCK` FOREIGN KEY (`block_id`) REFERENCES `dxov_cms_block` (`block_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CMS_BLOCK_STORE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='CMS Blocks to Stores';

INSERT INTO `dxov_cms_block_store` VALUES
(5, 0);

DROP TABLE IF EXISTS `dxov_cms_page`;
CREATE TABLE `dxov_cms_page` (
  `page_id` smallint(6) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `root_template` varchar(255) NOT NULL default '',
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `identifier` varchar(100) NOT NULL default '',
  `content` text,
  `creation_time` datetime default NULL,
  `update_time` datetime default NULL,
  `is_active` tinyint(1) NOT NULL default '1',
  `sort_order` tinyint(4) NOT NULL default '0',
  `layout_update_xml` text,
  `custom_theme` varchar(100) default NULL,
  `custom_theme_from` date default NULL,
  `custom_theme_to` date default NULL,
  PRIMARY KEY  (`page_id`),
  KEY `identifier` (`identifier`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='CMS pages';

INSERT INTO `dxov_cms_page` VALUES
(1, '404 Not Found 1', 'two_columns_right', 'Page keywords', 'Page description', 'no-route', '<div class=\"page-head-alt\"><h3>Whoops, our bad...</h3></div>\r\n<dl>\r\n<dt>The page you requested was not found, and we have a fine guess why.</dt>\r\n<dd>\r\n<ul class=\"disc\">\r\n<li>If you typed the URL directly, please make sure the spelling is correct.</li>\r\n<li>If you clicked on a link to get here, the link is outdated.</li>\r\n</ul></dd>\r\n</dl>\r\n<br/>\r\n<dl>\r\n<dt>What can you do?</dt>\r\n<dd>Have no fear, help is near! There are many ways you can get back on track with Magento Demo Store.</dd>\r\n<dd>\r\n<ul class=\"disc\">\r\n<li><a href=\"#\" onclick=\"history.go(-1);\">Go back</a> to the previous page.</li>\r\n<li>Use the search bar at the top of the page to search for your products.</li>\r\n<li>Follow these links to get you back on track!<br/><a href=\"{{store url=\"\"}}\">Store Home</a><br/><a href=\"{{store url=\"customer/account\"}}\">My Account</a></li></ul></dd></dl><br/>\r\n<p><img src=\"{{skin url=\'images/media/404_callout1.jpg\'}}\" style=\"margin-right:15px;\"/><img src=\"{{skin url=\'images/media/404_callout2.jpg\'}}\" /></p>', '2007-06-20 18:38:32', '2007-08-26 19:11:13', 1, 0, NULL, NULL, NULL, NULL),
(2, 'Home page', 'two_columns_right', '', '', 'home', '<h1>Home Page</h1>\r\n', '2007-08-23 10:03:25', '2007-09-06 13:26:53', 1, 0, '<!--<reference name=\"content\">\n<block type=\"catalog/product_new\" name=\"home.catalog.product.new\" alias=\"product_new\" template=\"catalog/product/new.phtml\" after=\"cms_page\"><action method=\"addPriceBlockType\"><type>bundle</type><block>bundle/catalog_product_price</block><template>bundle/catalog/product/price.phtml</template></action></block>\n<block type=\"reports/product_viewed\" name=\"home.reports.product.viewed\" alias=\"product_viewed\" template=\"reports/home_product_viewed.phtml\" after=\"product_new\"><action method=\"addPriceBlockType\"><type>bundle</type><block>bundle/catalog_product_price</block><template>bundle/catalog/product/price.phtml</template></action></block>\n<block type=\"reports/product_compared\" name=\"home.reports.product.compared\" template=\"reports/home_product_compared.phtml\" after=\"product_viewed\"><action method=\"addPriceBlockType\"><type>bundle</type><block>bundle/catalog_product_price</block><template>bundle/catalog/product/price.phtml</template></action></block>\n</reference><reference name=\"right\">\n<action method=\"unsetChild\"><alias>right.reports.product.viewed</alias></action>\n<action method=\"unsetChild\"><alias>right.reports.product.compared</alias></action>\n</reference>-->', NULL, NULL, NULL),
(3, 'About  Us', 'one_column', '', '', 'about-magento-demo-store', '<div class=\"page-head\">\r\n<h3>About Magento  Demo Store</h3>\r\n</div>\r\n<div class=\"col3-set\">\r\n<div class=\"col-1\"><p><img src=\"{{skin url=\'images/media/about_us_img.jpg\'}}\" alt=\"Varien office pic\"/></p><p style=\"line-height:1.2em;\"><small>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede.</small></p>\r\n<p style=\"color:#888; font:1.2em/1.4em georgia, serif;\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta.</p></div>\r\n<div class=\"col-2\">\r\n<p><strong style=\"color:#de036f;\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit.</strong></p>\r\n<p>Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo. </p>\r\n<p>Maecenas ullamcorper, odio vel tempus egestas, dui orci faucibus orci, sit amet aliquet lectus dolor et quam. Pellentesque consequat luctus purus. Nunc et risus. Etiam a nibh. Phasellus dignissim metus eget nisi. Vestibulum sapien dolor, aliquet nec, porta ac, malesuada a, libero. Praesent feugiat purus eget est. Nulla facilisi. Vestibulum tincidunt sapien eu velit. Mauris purus. Maecenas eget mauris eu orci accumsan feugiat. Pellentesque eget velit. Nunc tincidunt.</p></div>\r\n<div class=\"col-3\">\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper </p>\r\n<p><strong style=\"color:#de036f;\">Maecenas ullamcorper, odio vel tempus egestas, dui orci faucibus orci, sit amet aliquet lectus dolor et quam. Pellentesque consequat luctus purus.</strong></p>\r\n<p>Nunc et risus. Etiam a nibh. Phasellus dignissim metus eget nisi.</p>\r\n<div class=\"divider\"></div>\r\n<p>To all of you, from all of us at Magento Demo Store - Thank you and Happy eCommerce!</p>\r\n<p style=\"line-height:1.2em;\"><strong style=\"font:italic 2em Georgia, serif;\">John Doe</strong><br/><small>Some important guy</small></p></div>\r\n</div>', '2007-08-30 14:01:18', '2007-08-30 14:01:18', 1, 0, NULL, NULL, NULL, NULL),
(4, 'Customer Service', 'three_columns', '', '', 'customer-service', '<div class=\"page-head\">\r\n<h3>Customer Service</h3>\r\n</div>\r\n<ul class=\"disc\" style=\"margin-bottom:15px;\">\r\n<li><a href=\"#answer1\">Shipping & Delivery</a></li>\r\n<li><a href=\"#answer2\">Privacy & Security</a></li>\r\n<li><a href=\"#answer3\">Returns & Replacements</a></li>\r\n<li><a href=\"#answer4\">Ordering</a></li>\r\n<li><a href=\"#answer5\">Payment, Pricing & Promotions</a></li>\r\n<li><a href=\"#answer6\">Viewing Orders</a></li>\r\n<li><a href=\"#answer7\">Updating Account Information</a></li>\r\n</ul>\r\n<dl>\r\n<dt id=\"answer1\">Shipping & Delivery</dt>\r\n<dd style=\"margin-bottom:10px;\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id=\"answer2\">Privacy & Security</dt>\r\n<dd style=\"margin-bottom:10px;\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id=\"answer3\">Returns & Replacements</dt>\r\n<dd style=\"margin-bottom:10px;\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id=\"answer4\">Ordering</dt>\r\n<dd style=\"margin-bottom:10px;\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id=\"answer5\">Payment, Pricing & Promotions</dt>\r\n<dd style=\"margin-bottom:10px;\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id=\"answer6\">Viewing Orders</dt>\r\n<dd style=\"margin-bottom:10px;\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id=\"answer7\">Updating Account Information</dt>\r\n<dd style=\"margin-bottom:10px;\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n</dl>', '2007-08-30 14:02:20', '2007-08-30 14:03:37', 1, 0, NULL, NULL, NULL, NULL);

DROP TABLE IF EXISTS `dxov_cms_page_store`;
CREATE TABLE `dxov_cms_page_store` (
  `page_id` smallint(6) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`page_id`,`store_id`),
  KEY `FK_CMS_PAGE_STORE_STORE` (`store_id`),
  CONSTRAINT `FK_CMS_PAGE_STORE_PAGE` FOREIGN KEY (`page_id`) REFERENCES `dxov_cms_page` (`page_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CMS_PAGE_STORE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='CMS Pages to Stores';

INSERT INTO `dxov_cms_page_store` VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0);

DROP TABLE IF EXISTS `dxov_core_config_data`;
CREATE TABLE `dxov_core_config_data` (
  `config_id` int(10) unsigned NOT NULL auto_increment,
  `scope` enum('default','websites','stores','config') NOT NULL default 'default',
  `scope_id` int(11) NOT NULL default '0',
  `path` varchar(255) NOT NULL default 'general',
  `value` text NOT NULL,
  PRIMARY KEY  (`config_id`),
  UNIQUE KEY `config_scope` (`scope`,`scope_id`,`path`)
) ENGINE=InnoDB AUTO_INCREMENT=116 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_core_config_data` VALUES
(1, 'default', 0, 'catalog/category/root_id', '2'),
(2, 'default', 0, 'web/seo/use_rewrites', '1'),
(3, 'default', 0, 'web/unsecure/base_url', 'http://www.thetennisdepot.com/'),
(4, 'default', 0, 'web/secure/base_url', 'http://www.thetennisdepot.com/'),
(5, 'default', 0, 'general/locale/code', 'en_US'),
(6, 'default', 0, 'general/locale/timezone', 'Etc/GMT+5'),
(7, 'default', 0, 'currency/options/base', 'USD'),
(8, 'default', 0, 'currency/options/default', 'USD'),
(9, 'default', 0, 'currency/options/allow', 'USD'),
(10, 'default', 0, 'admin/emails/forgot_email_template', 'admin_emails_forgot_email_template'),
(11, 'default', 0, 'admin/emails/forgot_email_identity', 'general'),
(12, 'default', 0, 'admin/startup/page', 'dashboard'),
(13, 'default', 0, 'admin/url/use_custom', '0'),
(14, 'default', 0, 'admin/url/custom', ''),
(15, 'default', 0, 'admin/security/use_form_key', '1'),
(16, 'default', 0, 'admin/security/session_cookie_lifetime', ''),
(17, 'default', 0, 'admin/fontis_wysiwyg/editor_type', 'fckeditor'),
(18, 'default', 0, 'admin/fontis_wysiwyg/editable_areas', 'description,short_description,page_content,block_content,_generaldescription,text'),
(19, 'default', 0, 'admin/fontis_wysiwyg/editable_areas_custom', 'a:0:{}'),
(20, 'default', 0, 'admin/fontis_wysiwyg/fckeditor_toolbarset', 'Default'),
(21, 'default', 0, 'admin/fontis_wysiwyg/fckeditor_skin', 'default'),
(22, 'default', 0, 'admin/fontis_wysiwyg/fckeditor_upload_path', 'media/upload'),
(23, 'default', 0, 'cataloginventory/options/can_back_in_stock', '1'),
(24, 'default', 0, 'cataloginventory/options/can_subtract', '0'),
(25, 'default', 0, 'cataloginventory/item_options/manage_stock', '0'),
(26, 'default', 0, 'cataloginventory/item_options/backorders', '0'),
(27, 'default', 0, 'cataloginventory/item_options/max_sale_qty', '10000'),
(28, 'default', 0, 'cataloginventory/item_options/min_qty', '0'),
(29, 'default', 0, 'cataloginventory/item_options/min_sale_qty', '1'),
(30, 'default', 0, 'cataloginventory/item_options/notify_stock_qty', '1'),
(31, 'default', 0, 'catalog/review/allow_guest', '0'),
(32, 'default', 0, 'catalog/frontend/list_mode', 'grid-list'),
(33, 'default', 0, 'catalog/frontend/grid_per_page_values', '9,15,30'),
(34, 'default', 0, 'catalog/frontend/grid_per_page', '9'),
(35, 'default', 0, 'catalog/frontend/list_per_page_values', '5,10,15,20,25'),
(36, 'default', 0, 'catalog/frontend/list_per_page', '10'),
(37, 'default', 0, 'catalog/frontend/default_sort_by', 'position'),
(38, 'default', 0, 'catalog/sitemap/tree_mode', '0'),
(39, 'default', 0, 'catalog/sitemap/lines_perpage', '30'),
(40, 'default', 0, 'catalog/productalert/allow_price', '1'),
(41, 'default', 0, 'catalog/productalert/email_price_template', 'catalog_productalert_email_price_template'),
(42, 'default', 0, 'catalog/productalert/allow_stock', '1'),
(43, 'default', 0, 'catalog/productalert/email_stock_template', 'catalog_productalert_email_stock_template'),
(44, 'default', 0, 'catalog/productalert/email_identity', 'general'),
(45, 'default', 0, 'catalog/productalert_cron/frequency', 'D'),
(46, 'default', 0, 'crontab/jobs/catalog_product_alert/schedule/cron_expr', '0 0 * * *'),
(47, 'default', 0, 'crontab/jobs/catalog_product_alert/run/model', 'productalert/observer::process'),
(48, 'default', 0, 'catalog/productalert_cron/time', '00,00,00'),
(49, 'default', 0, 'catalog/productalert_cron/error_email', ''),
(50, 'default', 0, 'catalog/productalert_cron/error_email_identity', 'general'),
(51, 'default', 0, 'catalog/productalert_cron/error_email_template', 'catalog_productalert_cron_error_email_template'),
(52, 'default', 0, 'catalog/recently_products/scope', 'website'),
(53, 'default', 0, 'catalog/recently_products/viewed_count', '5'),
(54, 'default', 0, 'catalog/recently_products/compared_count', '5'),
(55, 'default', 0, 'catalog/price/scope', '0'),
(56, 'default', 0, 'catalog/navigation/max_depth', '0'),
(57, 'default', 0, 'catalog/search/min_query_length', '1'),
(58, 'default', 0, 'catalog/search/max_query_length', '128'),
(59, 'default', 0, 'catalog/search/max_query_words', '10'),
(60, 'default', 0, 'catalog/search/search_type', '1'),
(61, 'default', 0, 'catalog/search/use_layered_navigation_count', '2000'),
(62, 'default', 0, 'catalog/seo/search_terms', '1'),
(63, 'default', 0, 'catalog/seo/site_map', '1'),
(64, 'default', 0, 'catalog/seo/product_url_suffix', '.html'),
(65, 'default', 0, 'catalog/seo/category_url_suffix', '.html'),
(66, 'default', 0, 'catalog/seo/product_use_categories', '1'),
(67, 'default', 0, 'catalog/seo/title_separator', '-'),
(68, 'default', 0, 'catalog/downloadable/order_item_status', '9'),
(69, 'default', 0, 'catalog/downloadable/downloads_number', '0'),
(70, 'default', 0, 'catalog/downloadable/shareable', '0'),
(71, 'default', 0, 'catalog/downloadable/samples_title', 'Samples'),
(72, 'default', 0, 'catalog/downloadable/links_title', 'Links'),
(73, 'default', 0, 'catalog/downloadable/links_target_new_window', '1'),
(74, 'default', 0, 'catalog/downloadable/content_disposition', 'inline'),
(75, 'default', 0, 'catalog/downloadable/disable_guest_checkout', '1'),
(76, 'default', 0, 'catalog/custom_options/use_calendar', '0'),
(77, 'default', 0, 'catalog/custom_options/date_fields_order', 'm,d,y'),
(78, 'default', 0, 'catalog/custom_options/time_format', '12h'),
(79, 'default', 0, 'catalog/custom_options/year_range', ','),
(80, 'default', 0, 'trans_email/ident_general/name', 'The Tennis Depot'),
(81, 'default', 0, 'trans_email/ident_general/email', 'info@thetennisdepot.com'),
(82, 'default', 0, 'trans_email/ident_sales/name', 'Sales'),
(83, 'default', 0, 'trans_email/ident_sales/email', 'sales@example.com'),
(84, 'default', 0, 'trans_email/ident_support/name', 'CustomerSupport'),
(85, 'default', 0, 'trans_email/ident_support/email', 'support@example.com'),
(86, 'default', 0, 'trans_email/ident_custom1/name', 'Custom 1'),
(87, 'default', 0, 'trans_email/ident_custom1/email', 'custom1@example.com'),
(88, 'default', 0, 'trans_email/ident_custom2/name', 'Custom 2'),
(89, 'default', 0, 'trans_email/ident_custom2/email', 'custom2@example.com'),
(90, 'default', 0, 'contacts/contacts/enabled', '1'),
(91, 'default', 0, 'contacts/email/recipient_email', 'info@thetennisdepot.com'),
(92, 'default', 0, 'contacts/email/sender_email_identity', 'general'),
(93, 'default', 0, 'contacts/email/email_template', 'contacts_email_email_template'),
(94, 'default', 0, 'shipping/origin/country_id', 'US'),
(95, 'default', 0, 'shipping/origin/region_id', '18'),
(96, 'default', 0, 'shipping/origin/postcode', '33004'),
(97, 'default', 0, 'shipping/origin/city', ''),
(98, 'default', 0, 'shipping/option/checkout_multiple', '1'),
(99, 'default', 0, 'shipping/option/checkout_multiple_maximum_qty', '100'),
(100, 'default', 0, 'livechatconfiguration/general/active', '1'),
(101, 'default', 0, 'livechatconfiguration/general/refreshfrequency', '10'),
(102, 'default', 0, 'livechatconfiguration/general/refreshdecay', '1'),
(103, 'default', 0, 'livechatconfiguration/general/adminrefreshrate', '300'),
(104, 'default', 0, 'livechatconfiguration/general/sessioncreation', '0'),
(105, 'default', 0, 'livechatconfiguration/general/nbmaxlines', '15'),
(106, 'default', 0, 'livechatconfiguration/general/displayadmintab', '1'),
(107, 'default', 0, 'livechatconfiguration/display/titlelabel', 'Live Chat!'),
(108, 'default', 0, 'livechatconfiguration/display/chatlabel', 'Chat Live With An Associate!'),
(109, 'default', 0, 'livechatconfiguration/display/imagestyle', '1'),
(110, 'default', 0, 'livechatconfiguration/display/unavailablelabel', 'Sorry, there are currently no operators online.'),
(111, 'default', 0, 'livechatconfiguration/display/defaultcustomername', 'Customer'),
(112, 'default', 0, 'livechatconfiguration/display/systemname', 'System'),
(113, 'default', 0, 'livechatconfiguration/display/systemwaitmessage', 'Your message has been sent, an operator will answer you soon'),
(114, 'default', 0, 'livechatconfiguration/display/systemautosessionmessage', 'Welcome, you can now discuss with an operator'),
(115, 'default', 0, 'livechatconfiguration/display/limitregisteredusers', '0');

DROP TABLE IF EXISTS `dxov_core_email_template`;
CREATE TABLE `dxov_core_email_template` (
  `template_id` int(7) unsigned NOT NULL auto_increment,
  `template_code` varchar(150) default NULL,
  `template_text` text,
  `template_type` int(3) unsigned default NULL,
  `template_subject` varchar(200) default NULL,
  `template_sender_name` varchar(200) default NULL,
  `template_sender_email` varchar(200) /*!40101 character set latin1 */ /*!40101 collate latin1_general_ci */ default NULL,
  `added_at` datetime default NULL,
  `modified_at` datetime default NULL,
  PRIMARY KEY  (`template_id`),
  UNIQUE KEY `template_code` (`template_code`),
  KEY `added_at` (`added_at`),
  KEY `modified_at` (`modified_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Email templates';

INSERT INTO `dxov_core_email_template` VALUES
(1, 'Send product to a friend', 'Welcome, {{var name}}<br /><br />Please look at <a href=\"{{var product.getProductUrl()}}\">{{var product.name}}</a><br /><br />Here is message: <br />{{var message}}<br /><br />', 2, 'Welcome, {{var name}}', NULL, NULL, '2009-05-25 06:43:24', '2009-05-25 06:43:24');

DROP TABLE IF EXISTS `dxov_core_flag`;
CREATE TABLE `dxov_core_flag` (
  `flag_id` smallint(5) unsigned NOT NULL auto_increment,
  `flag_code` varchar(255) NOT NULL,
  `state` smallint(5) unsigned NOT NULL default '0',
  `flag_data` text,
  `last_update` datetime NOT NULL,
  PRIMARY KEY  (`flag_id`),
  KEY `last_update` (`last_update`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_core_flag` VALUES
(1, 'catalog_product_flat', 0, 'a:1:{s:8:\"is_built\";b:0;}', '2009-05-25 13:43:35');

DROP TABLE IF EXISTS `dxov_core_layout_link`;
CREATE TABLE `dxov_core_layout_link` (
  `layout_link_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `package` varchar(64) NOT NULL default '',
  `theme` varchar(64) NOT NULL default '',
  `layout_update_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`layout_link_id`),
  UNIQUE KEY `store_id` (`store_id`,`package`,`theme`,`layout_update_id`),
  KEY `FK_core_layout_link_update` (`layout_update_id`),
  CONSTRAINT `FK_CORE_LAYOUT_LINK_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CORE_LAYOUT_LINK_UPDATE` FOREIGN KEY (`layout_update_id`) REFERENCES `dxov_core_layout_update` (`layout_update_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_core_layout_update`;
CREATE TABLE `dxov_core_layout_update` (
  `layout_update_id` int(10) unsigned NOT NULL auto_increment,
  `handle` varchar(255) default NULL,
  `xml` text,
  PRIMARY KEY  (`layout_update_id`),
  KEY `handle` (`handle`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_core_resource`;
CREATE TABLE `dxov_core_resource` (
  `code` varchar(50) NOT NULL default '',
  `version` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`code`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Resource version registry';

INSERT INTO `dxov_core_resource` VALUES
('adminnotification_setup', '1.0.0'),
('admin_setup', '0.7.1'),
('amazonpayments_setup', '0.1.2'),
('api_setup', '0.8.0'),
('backup_setup', '0.7.0'),
('bundle_setup', '0.1.6'),
('catalogindex_setup', '0.7.10'),
('cataloginventory_setup', '0.7.5'),
('catalogrule_setup', '0.7.7'),
('catalogsearch_setup', '0.7.6'),
('catalog_setup', '0.7.66'),
('checkout_setup', '0.9.3'),
('cms_setup', '0.7.6'),
('contacts_setup', '0.8.0'),
('core_setup', '0.8.12'),
('cron_setup', '0.7.1'),
('customer_setup', '0.8.10'),
('dataflow_setup', '0.7.4'),
('directory_setup', '0.8.4'),
('downloadable_setup', '0.1.14'),
('eav_setup', '0.7.12'),
('giftmessage_setup', '0.7.2'),
('googlebase_setup', '0.1.1'),
('googlecheckout_setup', '0.7.3'),
('googleoptimizer_setup', '0.1.2'),
('livechat_setup', '1.5.3'),
('log_setup', '0.7.6'),
('newsletter_setup', '0.8.0'),
('paygate_setup', '0.7.0'),
('payment_setup', '0.7.0'),
('paypaluk_setup', '0.7.0'),
('paypal_setup', '0.7.1'),
('poll_setup', '0.7.2'),
('productalert_setup', '0.7.1'),
('rating_setup', '0.7.2'),
('reports_setup', '0.7.7'),
('review_setup', '0.7.3'),
('salesrule_setup', '0.7.7'),
('sales_setup', '0.9.35'),
('sendfriend_setup', '0.7.2'),
('shipping_setup', '0.7.0'),
('sitemap_setup', '0.7.2'),
('tag_setup', '0.7.1'),
('tax_setup', '0.7.8'),
('usa_setup', '0.7.0'),
('weee_setup', '0.13'),
('wishlist_setup', '0.7.4');

DROP TABLE IF EXISTS `dxov_core_session`;
CREATE TABLE `dxov_core_session` (
  `session_id` varchar(255) NOT NULL default '',
  `website_id` smallint(5) unsigned default NULL,
  `session_expires` int(10) unsigned NOT NULL default '0',
  `session_data` mediumblob NOT NULL,
  PRIMARY KEY  (`session_id`),
  KEY `FK_SESSION_WEBSITE` (`website_id`),
  CONSTRAINT `FK_SESSION_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Session data store';

INSERT INTO `dxov_core_session` VALUES
('51adbdcb3cb0e37a44c4a2ad94e751f7', NULL, 1243358630, 'core|a:4:{s:23:\"_session_validator_data\";a:4:{s:11:\"remote_addr\";s:12:\"174.48.3.153\";s:8:\"http_via\";s:0:\"\";s:20:\"http_x_forwarded_for\";s:0:\"\";s:15:\"http_user_agent\";s:92:\"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10\";}s:13:\"session_hosts\";a:1:{s:22:\"www.thetennisdepot.com\";b:1;}s:8:\"messages\";O:34:\"Mage_Core_Model_Message_Collection\":2:{s:12:\"\0*\0_messages\";a:0:{}s:20:\"\0*\0_lastAddedMessage\";N;}s:9:\"_form_key\";s:16:\"w3u5GRZq66PIPHbd\";}_cookie_revalidate|d:1243358052;adminhtml|a:4:{s:23:\"_session_validator_data\";a:4:{s:11:\"remote_addr\";s:12:\"174.48.3.153\";s:8:\"http_via\";s:0:\"\";s:20:\"http_x_forwarded_for\";s:0:\"\";s:15:\"http_user_agent\";s:92:\"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10\";}s:13:\"session_hosts\";a:1:{s:22:\"www.thetennisdepot.com\";b:1;}s:6:\"locale\";s:5:\"en_US\";s:8:\"messages\";O:34:\"Mage_Core_Model_Message_Collection\":2:{s:12:\"\0*\0_messages\";a:0:{}s:20:\"\0*\0_lastAddedMessage\";O:29:\"Mage_Core_Model_Message_Error\":6:{s:8:\"\0*\0_type\";s:5:\"error\";s:8:\"\0*\0_code\";s:29:\"Invalid Username or Password.\";s:9:\"\0*\0_class\";s:0:\"\";s:10:\"\0*\0_method\";s:0:\"\";s:14:\"\0*\0_identifier\";N;s:12:\"\0*\0_isSticky\";b:0;}}}admin|a:6:{s:23:\"_session_validator_data\";a:4:{s:11:\"remote_addr\";s:12:\"174.48.3.153\";s:8:\"http_via\";s:0:\"\";s:20:\"http_x_forwarded_for\";s:0:\"\";s:15:\"http_user_agent\";s:92:\"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10\";}s:13:\"session_hosts\";a:1:{s:22:\"www.thetennisdepot.com\";b:1;}s:4:\"user\";O:21:\"Mage_Admin_Model_User\":12:{s:15:\"\0*\0_eventPrefix\";s:10:\"admin_user\";s:8:\"\0*\0_role\";N;s:15:\"\0*\0_eventObject\";s:6:\"object\";s:16:\"\0*\0_resourceName\";s:10:\"admin/user\";s:12:\"\0*\0_resource\";N;s:26:\"\0*\0_resourceCollectionName\";s:21:\"admin/user_collection\";s:12:\"\0*\0_cacheTag\";b:0;s:19:\"\0*\0_dataSaveAllowed\";b:1;s:8:\"\0*\0_data\";a:13:{s:7:\"user_id\";s:1:\"2\";s:9:\"firstname\";s:5:\"Lance\";s:8:\"lastname\";s:7:\"Lvovsky\";s:5:\"email\";s:26:\"stringsdepotplus@yahoo.com\";s:8:\"username\";s:9:\"ttdepot92\";s:8:\"password\";s:35:\"79dd7227d7e8dbfcda6258acf6e5b2d6:k5\";s:7:\"created\";s:19:\"2009-05-25 13:46:14\";s:8:\"modified\";s:19:\"2009-05-25 13:46:14\";s:7:\"logdate\";s:19:\"2009-05-26 16:59:28\";s:6:\"lognum\";s:1:\"7\";s:15:\"reload_acl_flag\";s:1:\"0\";s:9:\"is_active\";s:1:\"1\";s:5:\"extra\";a:1:{s:11:\"configState\";a:31:{s:12:\"admin_emails\";s:1:\"0\";s:13:\"admin_startup\";s:1:\"0\";s:9:\"admin_url\";s:1:\"0\";s:14:\"admin_security\";s:1:\"0\";s:20:\"admin_fontis_wysiwyg\";s:1:\"1\";s:24:\"cataloginventory_options\";s:1:\"0\";s:29:\"cataloginventory_item_options\";s:1:\"1\";s:14:\"catalog_review\";s:1:\"0\";s:16:\"catalog_frontend\";s:1:\"0\";s:15:\"catalog_sitemap\";s:1:\"0\";s:20:\"catalog_productalert\";s:1:\"0\";s:25:\"catalog_productalert_cron\";s:1:\"0\";s:19:\"catalog_placeholder\";s:1:\"0\";s:25:\"catalog_recently_products\";s:1:\"0\";s:13:\"catalog_price\";s:1:\"0\";s:18:\"catalog_navigation\";s:1:\"0\";s:14:\"catalog_search\";s:1:\"0\";s:11:\"catalog_seo\";s:1:\"0\";s:20:\"catalog_downloadable\";s:1:\"0\";s:22:\"catalog_custom_options\";s:1:\"1\";s:25:\"trans_email_ident_general\";s:1:\"1\";s:23:\"trans_email_ident_sales\";s:1:\"1\";s:25:\"trans_email_ident_support\";s:1:\"1\";s:25:\"trans_email_ident_custom1\";s:1:\"1\";s:25:\"trans_email_ident_custom2\";s:1:\"1\";s:17:\"contacts_contacts\";s:1:\"1\";s:14:\"contacts_email\";s:1:\"1\";s:15:\"shipping_origin\";s:1:\"1\";s:15:\"shipping_option\";s:1:\"0\";s:29:\"livechatconfiguration_general\";s:1:\"1\";s:29:\"livechatconfiguration_display\";s:1:\"1\";}}}s:12:\"\0*\0_origData\";a:13:{s:7:\"user_id\";s:1:\"2\";s:9:\"firstname\";s:5:\"Lance\";s:8:\"lastname\";s:7:\"Lvovsky\";s:5:\"email\";s:26:\"stringsdepotplus@yahoo.com\";s:8:\"username\";s:9:\"ttdepot92\";s:8:\"password\";s:35:\"79dd7227d7e8dbfcda6258acf6e5b2d6:k5\";s:7:\"created\";s:19:\"2009-05-25 13:46:14\";s:8:\"modified\";s:19:\"2009-05-25 13:46:14\";s:7:\"logdate\";s:19:\"2009-05-26 16:59:28\";s:6:\"lognum\";s:1:\"7\";s:15:\"reload_acl_flag\";s:1:\"0\";s:9:\"is_active\";s:1:\"1\";s:5:\"extra\";a:1:{s:11:\"configState\";a:31:{s:12:\"admin_emails\";s:1:\"0\";s:13:\"admin_startup\";s:1:\"0\";s:9:\"admin_url\";s:1:\"0\";s:14:\"admin_security\";s:1:\"0\";s:20:\"admin_fontis_wysiwyg\";s:1:\"1\";s:24:\"cataloginventory_options\";s:1:\"0\";s:29:\"cataloginventory_item_options\";s:1:\"1\";s:14:\"catalog_review\";s:1:\"0\";s:16:\"catalog_frontend\";s:1:\"0\";s:15:\"catalog_sitemap\";s:1:\"0\";s:20:\"catalog_productalert\";s:1:\"0\";s:25:\"catalog_productalert_cron\";s:1:\"0\";s:19:\"catalog_placeholder\";s:1:\"0\";s:25:\"catalog_recently_products\";s:1:\"0\";s:13:\"catalog_price\";s:1:\"0\";s:18:\"catalog_navigation\";s:1:\"0\";s:14:\"catalog_search\";s:1:\"0\";s:11:\"catalog_seo\";s:1:\"0\";s:20:\"catalog_downloadable\";s:1:\"0\";s:22:\"catalog_custom_options\";s:1:\"1\";s:25:\"trans_email_ident_general\";s:1:\"1\";s:23:\"trans_email_ident_sales\";s:1:\"1\";s:25:\"trans_email_ident_support\";s:1:\"1\";s:25:\"trans_email_ident_custom1\";s:1:\"1\";s:25:\"trans_email_ident_custom2\";s:1:\"1\";s:17:\"contacts_contacts\";s:1:\"1\";s:14:\"contacts_email\";s:1:\"1\";s:15:\"shipping_origin\";s:1:\"1\";s:15:\"shipping_option\";s:1:\"0\";s:29:\"livechatconfiguration_general\";s:1:\"1\";s:29:\"livechatconfiguration_display\";s:1:\"1\";}}}s:15:\"\0*\0_idFieldName\";s:7:\"user_id\";s:13:\"\0*\0_isDeleted\";b:0;}s:3:\"acl\";O:20:\"Mage_Admin_Model_Acl\":3:{s:16:\"\0*\0_roleRegistry\";O:34:\"Mage_Admin_Model_Acl_Role_Registry\":1:{s:9:\"\0*\0_roles\";a:2:{s:2:\"G1\";a:3:{s:8:\"instance\";O:31:\"Mage_Admin_Model_Acl_Role_Group\":1:{s:10:\"\0*\0_roleId\";s:2:\"G1\";}s:7:\"parents\";a:0:{}s:8:\"children\";a:1:{s:2:\"U2\";O:30:\"Mage_Admin_Model_Acl_Role_User\":1:{s:10:\"\0*\0_roleId\";s:2:\"U2\";}}}s:2:\"U2\";a:3:{s:8:\"instance\";r:151;s:7:\"parents\";a:1:{s:2:\"G1\";r:147;}s:8:\"children\";a:0:{}}}}s:13:\"\0*\0_resources\";a:159:{s:3:\"all\";a:3:{s:8:\"instance\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:3:\"all\";}s:6:\"parent\";N;s:8:\"children\";a:0:{}}s:5:\"admin\";a:3:{s:8:\"instance\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:5:\"admin\";}s:6:\"parent\";N;s:8:\"children\";a:10:{s:15:\"admin/dashboard\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:15:\"admin/dashboard\";}s:12:\"admin/system\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:12:\"admin/system\";}s:19:\"admin/global_search\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:19:\"admin/global_search\";}s:14:\"admin/customer\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:14:\"admin/customer\";}s:13:\"admin/catalog\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:13:\"admin/catalog\";}s:11:\"admin/promo\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:11:\"admin/promo\";}s:11:\"admin/sales\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:11:\"admin/sales\";}s:9:\"admin/cms\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:9:\"admin/cms\";}s:12:\"admin/report\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:12:\"admin/report\";}s:16:\"admin/newsletter\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:16:\"admin/newsletter\";}}}s:15:\"admin/dashboard\";a:3:{s:8:\"instance\";r:169;s:6:\"parent\";r:165;s:8:\"children\";a:0:{}}s:12:\"admin/system\";a:3:{s:8:\"instance\";r:171;s:6:\"parent\";r:165;s:8:\"children\";a:13:{s:16:\"admin/system/acl\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:16:\"admin/system/acl\";}s:18:\"admin/system/store\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:18:\"admin/system/store\";}s:19:\"admin/system/design\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:19:\"admin/system/design\";}s:19:\"admin/system/config\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:19:\"admin/system/config\";}s:21:\"admin/system/currency\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:21:\"admin/system/currency\";}s:27:\"admin/system/email_template\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:27:\"admin/system/email_template\";}s:22:\"admin/system/myaccount\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:22:\"admin/system/myaccount\";}s:18:\"admin/system/tools\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:18:\"admin/system/tools\";}s:20:\"admin/system/convert\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:20:\"admin/system/convert\";}s:18:\"admin/system/cache\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:18:\"admin/system/cache\";}s:23:\"admin/system/extensions\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:23:\"admin/system/extensions\";}s:30:\"admin/system/adminnotification\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/system/adminnotification\";}s:16:\"admin/system/api\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:16:\"admin/system/api\";}}}s:16:\"admin/system/acl\";a:3:{s:8:\"instance\";r:197;s:6:\"parent\";r:171;s:8:\"children\";a:2:{s:22:\"admin/system/acl/roles\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:22:\"admin/system/acl/roles\";}s:22:\"admin/system/acl/users\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:22:\"admin/system/acl/users\";}}}s:22:\"admin/system/acl/roles\";a:3:{s:8:\"instance\";r:227;s:6:\"parent\";r:197;s:8:\"children\";a:0:{}}s:22:\"admin/system/acl/users\";a:3:{s:8:\"instance\";r:229;s:6:\"parent\";r:197;s:8:\"children\";a:0:{}}s:18:\"admin/system/store\";a:3:{s:8:\"instance\";r:199;s:6:\"parent\";r:171;s:8:\"children\";a:0:{}}s:19:\"admin/system/design\";a:3:{s:8:\"instance\";r:201;s:6:\"parent\";r:171;s:8:\"children\";a:0:{}}s:19:\"admin/system/config\";a:3:{s:8:\"instance\";r:203;s:6:\"parent\";r:171;s:8:\"children\";a:32:{s:27:\"admin/system/config/general\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:27:\"admin/system/config/general\";}s:23:\"admin/system/config/web\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:23:\"admin/system/config/web\";}s:26:\"admin/system/config/design\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:26:\"admin/system/config/design\";}s:26:\"admin/system/config/system\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:26:\"admin/system/config/system\";}s:28:\"admin/system/config/advanced\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:28:\"admin/system/config/advanced\";}s:31:\"admin/system/config/trans_email\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:31:\"admin/system/config/trans_email\";}s:23:\"admin/system/config/dev\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:23:\"admin/system/config/dev\";}s:28:\"admin/system/config/currency\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:28:\"admin/system/config/currency\";}s:30:\"admin/system/config/sendfriend\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/system/config/sendfriend\";}s:25:\"admin/system/config/admin\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:25:\"admin/system/config/admin\";}s:28:\"admin/system/config/customer\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:28:\"admin/system/config/customer\";}s:27:\"admin/system/config/catalog\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:27:\"admin/system/config/catalog\";}s:25:\"admin/system/config/sales\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:25:\"admin/system/config/sales\";}s:31:\"admin/system/config/sales_email\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:31:\"admin/system/config/sales_email\";}s:29:\"admin/system/config/sales_pdf\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:29:\"admin/system/config/sales_pdf\";}s:28:\"admin/system/config/checkout\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:28:\"admin/system/config/checkout\";}s:28:\"admin/system/config/shipping\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:28:\"admin/system/config/shipping\";}s:28:\"admin/system/config/carriers\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:28:\"admin/system/config/carriers\";}s:27:\"admin/system/config/payment\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:27:\"admin/system/config/payment\";}s:26:\"admin/system/config/paypal\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:26:\"admin/system/config/paypal\";}s:26:\"admin/system/config/google\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:26:\"admin/system/config/google\";}s:30:\"admin/system/config/newsletter\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/system/config/newsletter\";}s:23:\"admin/system/config/tax\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:23:\"admin/system/config/tax\";}s:28:\"admin/system/config/wishlist\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:28:\"admin/system/config/wishlist\";}s:36:\"admin/system/config/cataloginventory\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:36:\"admin/system/config/cataloginventory\";}s:28:\"admin/system/config/contacts\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:28:\"admin/system/config/contacts\";}s:27:\"admin/system/config/sitemap\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:27:\"admin/system/config/sitemap\";}s:23:\"admin/system/config/rss\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:23:\"admin/system/config/rss\";}s:23:\"admin/system/config/api\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:23:\"admin/system/config/api\";}s:32:\"admin/system/config/downloadable\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:32:\"admin/system/config/downloadable\";}s:41:\"admin/system/config/livechatconfiguration\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:41:\"admin/system/config/livechatconfiguration\";}s:34:\"admin/system/config/livechatevents\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:34:\"admin/system/config/livechatevents\";}}}s:27:\"admin/system/config/general\";a:3:{s:8:\"instance\";r:251;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:23:\"admin/system/config/web\";a:3:{s:8:\"instance\";r:253;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:26:\"admin/system/config/design\";a:3:{s:8:\"instance\";r:255;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:26:\"admin/system/config/system\";a:3:{s:8:\"instance\";r:257;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:28:\"admin/system/config/advanced\";a:3:{s:8:\"instance\";r:259;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:31:\"admin/system/config/trans_email\";a:3:{s:8:\"instance\";r:261;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:23:\"admin/system/config/dev\";a:3:{s:8:\"instance\";r:263;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:28:\"admin/system/config/currency\";a:3:{s:8:\"instance\";r:265;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:30:\"admin/system/config/sendfriend\";a:3:{s:8:\"instance\";r:267;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:25:\"admin/system/config/admin\";a:3:{s:8:\"instance\";r:269;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:28:\"admin/system/config/customer\";a:3:{s:8:\"instance\";r:271;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:27:\"admin/system/config/catalog\";a:3:{s:8:\"instance\";r:273;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:25:\"admin/system/config/sales\";a:3:{s:8:\"instance\";r:275;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:31:\"admin/system/config/sales_email\";a:3:{s:8:\"instance\";r:277;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:29:\"admin/system/config/sales_pdf\";a:3:{s:8:\"instance\";r:279;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:28:\"admin/system/config/checkout\";a:3:{s:8:\"instance\";r:281;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:28:\"admin/system/config/shipping\";a:3:{s:8:\"instance\";r:283;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:28:\"admin/system/config/carriers\";a:3:{s:8:\"instance\";r:285;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:27:\"admin/system/config/payment\";a:3:{s:8:\"instance\";r:287;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:26:\"admin/system/config/paypal\";a:3:{s:8:\"instance\";r:289;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:26:\"admin/system/config/google\";a:3:{s:8:\"instance\";r:291;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:30:\"admin/system/config/newsletter\";a:3:{s:8:\"instance\";r:293;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:23:\"admin/system/config/tax\";a:3:{s:8:\"instance\";r:295;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:28:\"admin/system/config/wishlist\";a:3:{s:8:\"instance\";r:297;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:36:\"admin/system/config/cataloginventory\";a:3:{s:8:\"instance\";r:299;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:28:\"admin/system/config/contacts\";a:3:{s:8:\"instance\";r:301;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:27:\"admin/system/config/sitemap\";a:3:{s:8:\"instance\";r:303;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:23:\"admin/system/config/rss\";a:3:{s:8:\"instance\";r:305;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:23:\"admin/system/config/api\";a:3:{s:8:\"instance\";r:307;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:32:\"admin/system/config/downloadable\";a:3:{s:8:\"instance\";r:309;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:41:\"admin/system/config/livechatconfiguration\";a:3:{s:8:\"instance\";r:311;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:34:\"admin/system/config/livechatevents\";a:3:{s:8:\"instance\";r:313;s:6:\"parent\";r:203;s:8:\"children\";a:0:{}}s:21:\"admin/system/currency\";a:3:{s:8:\"instance\";r:205;s:6:\"parent\";r:171;s:8:\"children\";a:0:{}}s:27:\"admin/system/email_template\";a:3:{s:8:\"instance\";r:207;s:6:\"parent\";r:171;s:8:\"children\";a:0:{}}s:22:\"admin/system/myaccount\";a:3:{s:8:\"instance\";r:209;s:6:\"parent\";r:171;s:8:\"children\";a:0:{}}s:18:\"admin/system/tools\";a:3:{s:8:\"instance\";r:211;s:6:\"parent\";r:171;s:8:\"children\";a:1:{s:25:\"admin/system/tools/backup\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:25:\"admin/system/tools/backup\";}}}s:25:\"admin/system/tools/backup\";a:3:{s:8:\"instance\";r:459;s:6:\"parent\";r:211;s:8:\"children\";a:0:{}}s:20:\"admin/system/convert\";a:3:{s:8:\"instance\";r:213;s:6:\"parent\";r:171;s:8:\"children\";a:2:{s:24:\"admin/system/convert/gui\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:24:\"admin/system/convert/gui\";}s:29:\"admin/system/convert/profiles\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:29:\"admin/system/convert/profiles\";}}}s:24:\"admin/system/convert/gui\";a:3:{s:8:\"instance\";r:469;s:6:\"parent\";r:213;s:8:\"children\";a:0:{}}s:29:\"admin/system/convert/profiles\";a:3:{s:8:\"instance\";r:471;s:6:\"parent\";r:213;s:8:\"children\";a:0:{}}s:18:\"admin/system/cache\";a:3:{s:8:\"instance\";r:215;s:6:\"parent\";r:171;s:8:\"children\";a:0:{}}s:23:\"admin/system/extensions\";a:3:{s:8:\"instance\";r:217;s:6:\"parent\";r:171;s:8:\"children\";a:2:{s:29:\"admin/system/extensions/local\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:29:\"admin/system/extensions/local\";}s:30:\"admin/system/extensions/custom\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/system/extensions/custom\";}}}s:29:\"admin/system/extensions/local\";a:3:{s:8:\"instance\";r:489;s:6:\"parent\";r:217;s:8:\"children\";a:0:{}}s:30:\"admin/system/extensions/custom\";a:3:{s:8:\"instance\";r:491;s:6:\"parent\";r:217;s:8:\"children\";a:0:{}}s:30:\"admin/system/adminnotification\";a:3:{s:8:\"instance\";r:219;s:6:\"parent\";r:171;s:8:\"children\";a:4:{s:43:\"admin/system/adminnotification/show_toolbar\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:43:\"admin/system/adminnotification/show_toolbar\";}s:40:\"admin/system/adminnotification/show_list\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:40:\"admin/system/adminnotification/show_list\";}s:43:\"admin/system/adminnotification/mark_as_read\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:43:\"admin/system/adminnotification/mark_as_read\";}s:37:\"admin/system/adminnotification/remove\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:37:\"admin/system/adminnotification/remove\";}}}s:43:\"admin/system/adminnotification/show_toolbar\";a:3:{s:8:\"instance\";r:505;s:6:\"parent\";r:219;s:8:\"children\";a:0:{}}s:40:\"admin/system/adminnotification/show_list\";a:3:{s:8:\"instance\";r:507;s:6:\"parent\";r:219;s:8:\"children\";a:0:{}}s:43:\"admin/system/adminnotification/mark_as_read\";a:3:{s:8:\"instance\";r:509;s:6:\"parent\";r:219;s:8:\"children\";a:0:{}}s:37:\"admin/system/adminnotification/remove\";a:3:{s:8:\"instance\";r:511;s:6:\"parent\";r:219;s:8:\"children\";a:0:{}}s:16:\"admin/system/api\";a:3:{s:8:\"instance\";r:221;s:6:\"parent\";r:171;s:8:\"children\";a:2:{s:22:\"admin/system/api/users\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:22:\"admin/system/api/users\";}s:22:\"admin/system/api/roles\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:22:\"admin/system/api/roles\";}}}s:22:\"admin/system/api/users\";a:3:{s:8:\"instance\";r:533;s:6:\"parent\";r:221;s:8:\"children\";a:0:{}}s:22:\"admin/system/api/roles\";a:3:{s:8:\"instance\";r:535;s:6:\"parent\";r:221;s:8:\"children\";a:0:{}}s:19:\"admin/global_search\";a:3:{s:8:\"instance\";r:173;s:6:\"parent\";r:165;s:8:\"children\";a:0:{}}s:14:\"admin/customer\";a:3:{s:8:\"instance\";r:175;s:6:\"parent\";r:165;s:8:\"children\";a:4:{s:20:\"admin/customer/group\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:20:\"admin/customer/group\";}s:21:\"admin/customer/manage\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:21:\"admin/customer/manage\";}s:21:\"admin/customer/online\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:21:\"admin/customer/online\";}s:23:\"admin/customer/livechat\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:23:\"admin/customer/livechat\";}}}s:20:\"admin/customer/group\";a:3:{s:8:\"instance\";r:553;s:6:\"parent\";r:175;s:8:\"children\";a:0:{}}s:21:\"admin/customer/manage\";a:3:{s:8:\"instance\";r:555;s:6:\"parent\";r:175;s:8:\"children\";a:0:{}}s:21:\"admin/customer/online\";a:3:{s:8:\"instance\";r:557;s:6:\"parent\";r:175;s:8:\"children\";a:0:{}}s:23:\"admin/customer/livechat\";a:3:{s:8:\"instance\";r:559;s:6:\"parent\";r:175;s:8:\"children\";a:4:{s:35:\"admin/customer/livechat/sessionlist\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:35:\"admin/customer/livechat/sessionlist\";}s:35:\"admin/customer/livechat/sessionlive\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:35:\"admin/customer/livechat/sessionlive\";}s:36:\"admin/customer/livechat/operatorlist\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:36:\"admin/customer/livechat/operatorlist\";}s:33:\"admin/customer/livechat/reporting\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:33:\"admin/customer/livechat/reporting\";}}}s:35:\"admin/customer/livechat/sessionlist\";a:3:{s:8:\"instance\";r:577;s:6:\"parent\";r:559;s:8:\"children\";a:0:{}}s:35:\"admin/customer/livechat/sessionlive\";a:3:{s:8:\"instance\";r:579;s:6:\"parent\";r:559;s:8:\"children\";a:0:{}}s:36:\"admin/customer/livechat/operatorlist\";a:3:{s:8:\"instance\";r:581;s:6:\"parent\";r:559;s:8:\"children\";a:0:{}}s:33:\"admin/customer/livechat/reporting\";a:3:{s:8:\"instance\";r:583;s:6:\"parent\";r:559;s:8:\"children\";a:0:{}}s:13:\"admin/catalog\";a:3:{s:8:\"instance\";r:177;s:6:\"parent\";r:165;s:8:\"children\";a:10:{s:24:\"admin/catalog/attributes\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:24:\"admin/catalog/attributes\";}s:24:\"admin/catalog/categories\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:24:\"admin/catalog/categories\";}s:22:\"admin/catalog/products\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:22:\"admin/catalog/products\";}s:31:\"admin/catalog/update_attributes\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:31:\"admin/catalog/update_attributes\";}s:20:\"admin/catalog/search\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:20:\"admin/catalog/search\";}s:24:\"admin/catalog/urlrewrite\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:24:\"admin/catalog/urlrewrite\";}s:29:\"admin/catalog/reviews_ratings\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:29:\"admin/catalog/reviews_ratings\";}s:17:\"admin/catalog/tag\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:17:\"admin/catalog/tag\";}s:21:\"admin/catalog/sitemap\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:21:\"admin/catalog/sitemap\";}s:24:\"admin/catalog/googlebase\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:24:\"admin/catalog/googlebase\";}}}s:24:\"admin/catalog/attributes\";a:3:{s:8:\"instance\";r:605;s:6:\"parent\";r:177;s:8:\"children\";a:2:{s:35:\"admin/catalog/attributes/attributes\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:35:\"admin/catalog/attributes/attributes\";}s:29:\"admin/catalog/attributes/sets\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:29:\"admin/catalog/attributes/sets\";}}}s:35:\"admin/catalog/attributes/attributes\";a:3:{s:8:\"instance\";r:629;s:6:\"parent\";r:605;s:8:\"children\";a:0:{}}s:29:\"admin/catalog/attributes/sets\";a:3:{s:8:\"instance\";r:631;s:6:\"parent\";r:605;s:8:\"children\";a:0:{}}s:24:\"admin/catalog/categories\";a:3:{s:8:\"instance\";r:607;s:6:\"parent\";r:177;s:8:\"children\";a:0:{}}s:22:\"admin/catalog/products\";a:3:{s:8:\"instance\";r:609;s:6:\"parent\";r:177;s:8:\"children\";a:0:{}}s:31:\"admin/catalog/update_attributes\";a:3:{s:8:\"instance\";r:611;s:6:\"parent\";r:177;s:8:\"children\";a:0:{}}s:20:\"admin/catalog/search\";a:3:{s:8:\"instance\";r:613;s:6:\"parent\";r:177;s:8:\"children\";a:0:{}}s:24:\"admin/catalog/urlrewrite\";a:3:{s:8:\"instance\";r:615;s:6:\"parent\";r:177;s:8:\"children\";a:0:{}}s:29:\"admin/catalog/reviews_ratings\";a:3:{s:8:\"instance\";r:617;s:6:\"parent\";r:177;s:8:\"children\";a:2:{s:37:\"admin/catalog/reviews_ratings/ratings\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:37:\"admin/catalog/reviews_ratings/ratings\";}s:37:\"admin/catalog/reviews_ratings/reviews\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:37:\"admin/catalog/reviews_ratings/reviews\";}}}s:37:\"admin/catalog/reviews_ratings/ratings\";a:3:{s:8:\"instance\";r:665;s:6:\"parent\";r:617;s:8:\"children\";a:0:{}}s:37:\"admin/catalog/reviews_ratings/reviews\";a:3:{s:8:\"instance\";r:667;s:6:\"parent\";r:617;s:8:\"children\";a:2:{s:41:\"admin/catalog/reviews_ratings/reviews/all\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:41:\"admin/catalog/reviews_ratings/reviews/all\";}s:45:\"admin/catalog/reviews_ratings/reviews/pending\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:45:\"admin/catalog/reviews_ratings/reviews/pending\";}}}s:41:\"admin/catalog/reviews_ratings/reviews/all\";a:3:{s:8:\"instance\";r:677;s:6:\"parent\";r:667;s:8:\"children\";a:0:{}}s:45:\"admin/catalog/reviews_ratings/reviews/pending\";a:3:{s:8:\"instance\";r:679;s:6:\"parent\";r:667;s:8:\"children\";a:0:{}}s:17:\"admin/catalog/tag\";a:3:{s:8:\"instance\";r:619;s:6:\"parent\";r:177;s:8:\"children\";a:2:{s:21:\"admin/catalog/tag/all\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:21:\"admin/catalog/tag/all\";}s:25:\"admin/catalog/tag/pending\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:25:\"admin/catalog/tag/pending\";}}}s:21:\"admin/catalog/tag/all\";a:3:{s:8:\"instance\";r:693;s:6:\"parent\";r:619;s:8:\"children\";a:0:{}}s:25:\"admin/catalog/tag/pending\";a:3:{s:8:\"instance\";r:695;s:6:\"parent\";r:619;s:8:\"children\";a:0:{}}s:21:\"admin/catalog/sitemap\";a:3:{s:8:\"instance\";r:621;s:6:\"parent\";r:177;s:8:\"children\";a:0:{}}s:24:\"admin/catalog/googlebase\";a:3:{s:8:\"instance\";r:623;s:6:\"parent\";r:177;s:8:\"children\";a:2:{s:30:\"admin/catalog/googlebase/types\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/catalog/googlebase/types\";}s:30:\"admin/catalog/googlebase/items\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/catalog/googlebase/items\";}}}s:30:\"admin/catalog/googlebase/types\";a:3:{s:8:\"instance\";r:713;s:6:\"parent\";r:623;s:8:\"children\";a:0:{}}s:30:\"admin/catalog/googlebase/items\";a:3:{s:8:\"instance\";r:715;s:6:\"parent\";r:623;s:8:\"children\";a:0:{}}s:11:\"admin/promo\";a:3:{s:8:\"instance\";r:179;s:6:\"parent\";r:165;s:8:\"children\";a:2:{s:19:\"admin/promo/catalog\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:19:\"admin/promo/catalog\";}s:17:\"admin/promo/quote\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:17:\"admin/promo/quote\";}}}s:19:\"admin/promo/catalog\";a:3:{s:8:\"instance\";r:729;s:6:\"parent\";r:179;s:8:\"children\";a:0:{}}s:17:\"admin/promo/quote\";a:3:{s:8:\"instance\";r:731;s:6:\"parent\";r:179;s:8:\"children\";a:0:{}}s:11:\"admin/sales\";a:3:{s:8:\"instance\";r:181;s:6:\"parent\";r:165;s:8:\"children\";a:6:{s:17:\"admin/sales/order\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:17:\"admin/sales/order\";}s:19:\"admin/sales/invoice\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:19:\"admin/sales/invoice\";}s:20:\"admin/sales/shipment\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:20:\"admin/sales/shipment\";}s:22:\"admin/sales/creditmemo\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:22:\"admin/sales/creditmemo\";}s:29:\"admin/sales/checkoutagreement\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:29:\"admin/sales/checkoutagreement\";}s:15:\"admin/sales/tax\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:15:\"admin/sales/tax\";}}}s:17:\"admin/sales/order\";a:3:{s:8:\"instance\";r:745;s:6:\"parent\";r:181;s:8:\"children\";a:1:{s:25:\"admin/sales/order/actions\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:25:\"admin/sales/order/actions\";}}}s:25:\"admin/sales/order/actions\";a:3:{s:8:\"instance\";r:761;s:6:\"parent\";r:745;s:8:\"children\";a:12:{s:32:\"admin/sales/order/actions/create\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:32:\"admin/sales/order/actions/create\";}s:30:\"admin/sales/order/actions/view\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/sales/order/actions/view\";}s:33:\"admin/sales/order/actions/reorder\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:33:\"admin/sales/order/actions/reorder\";}s:30:\"admin/sales/order/actions/edit\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/sales/order/actions/edit\";}s:32:\"admin/sales/order/actions/cancel\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:32:\"admin/sales/order/actions/cancel\";}s:33:\"admin/sales/order/actions/capture\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:33:\"admin/sales/order/actions/capture\";}s:33:\"admin/sales/order/actions/invoice\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:33:\"admin/sales/order/actions/invoice\";}s:36:\"admin/sales/order/actions/creditmemo\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:36:\"admin/sales/order/actions/creditmemo\";}s:30:\"admin/sales/order/actions/hold\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/sales/order/actions/hold\";}s:32:\"admin/sales/order/actions/unhold\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:32:\"admin/sales/order/actions/unhold\";}s:30:\"admin/sales/order/actions/ship\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/sales/order/actions/ship\";}s:33:\"admin/sales/order/actions/comment\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:33:\"admin/sales/order/actions/comment\";}}}s:32:\"admin/sales/order/actions/create\";a:3:{s:8:\"instance\";r:767;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:30:\"admin/sales/order/actions/view\";a:3:{s:8:\"instance\";r:769;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:33:\"admin/sales/order/actions/reorder\";a:3:{s:8:\"instance\";r:771;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:30:\"admin/sales/order/actions/edit\";a:3:{s:8:\"instance\";r:773;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:32:\"admin/sales/order/actions/cancel\";a:3:{s:8:\"instance\";r:775;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:33:\"admin/sales/order/actions/capture\";a:3:{s:8:\"instance\";r:777;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:33:\"admin/sales/order/actions/invoice\";a:3:{s:8:\"instance\";r:779;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:36:\"admin/sales/order/actions/creditmemo\";a:3:{s:8:\"instance\";r:781;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:30:\"admin/sales/order/actions/hold\";a:3:{s:8:\"instance\";r:783;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:32:\"admin/sales/order/actions/unhold\";a:3:{s:8:\"instance\";r:785;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:30:\"admin/sales/order/actions/ship\";a:3:{s:8:\"instance\";r:787;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:33:\"admin/sales/order/actions/comment\";a:3:{s:8:\"instance\";r:789;s:6:\"parent\";r:761;s:8:\"children\";a:0:{}}s:19:\"admin/sales/invoice\";a:3:{s:8:\"instance\";r:747;s:6:\"parent\";r:181;s:8:\"children\";a:0:{}}s:20:\"admin/sales/shipment\";a:3:{s:8:\"instance\";r:749;s:6:\"parent\";r:181;s:8:\"children\";a:0:{}}s:22:\"admin/sales/creditmemo\";a:3:{s:8:\"instance\";r:751;s:6:\"parent\";r:181;s:8:\"children\";a:0:{}}s:29:\"admin/sales/checkoutagreement\";a:3:{s:8:\"instance\";r:753;s:6:\"parent\";r:181;s:8:\"children\";a:0:{}}s:15:\"admin/sales/tax\";a:3:{s:8:\"instance\";r:755;s:6:\"parent\";r:181;s:8:\"children\";a:5:{s:32:\"admin/sales/tax/classes_customer\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:32:\"admin/sales/tax/classes_customer\";}s:31:\"admin/sales/tax/classes_product\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:31:\"admin/sales/tax/classes_product\";}s:29:\"admin/sales/tax/import_export\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:29:\"admin/sales/tax/import_export\";}s:21:\"admin/sales/tax/rates\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:21:\"admin/sales/tax/rates\";}s:21:\"admin/sales/tax/rules\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:21:\"admin/sales/tax/rules\";}}}s:32:\"admin/sales/tax/classes_customer\";a:3:{s:8:\"instance\";r:859;s:6:\"parent\";r:755;s:8:\"children\";a:0:{}}s:31:\"admin/sales/tax/classes_product\";a:3:{s:8:\"instance\";r:861;s:6:\"parent\";r:755;s:8:\"children\";a:0:{}}s:29:\"admin/sales/tax/import_export\";a:3:{s:8:\"instance\";r:863;s:6:\"parent\";r:755;s:8:\"children\";a:0:{}}s:21:\"admin/sales/tax/rates\";a:3:{s:8:\"instance\";r:865;s:6:\"parent\";r:755;s:8:\"children\";a:0:{}}s:21:\"admin/sales/tax/rules\";a:3:{s:8:\"instance\";r:867;s:6:\"parent\";r:755;s:8:\"children\";a:0:{}}s:9:\"admin/cms\";a:3:{s:8:\"instance\";r:183;s:6:\"parent\";r:165;s:8:\"children\";a:3:{s:15:\"admin/cms/block\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:15:\"admin/cms/block\";}s:14:\"admin/cms/page\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:14:\"admin/cms/page\";}s:14:\"admin/cms/poll\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:14:\"admin/cms/poll\";}}}s:15:\"admin/cms/block\";a:3:{s:8:\"instance\";r:893;s:6:\"parent\";r:183;s:8:\"children\";a:0:{}}s:14:\"admin/cms/page\";a:3:{s:8:\"instance\";r:895;s:6:\"parent\";r:183;s:8:\"children\";a:0:{}}s:14:\"admin/cms/poll\";a:3:{s:8:\"instance\";r:897;s:6:\"parent\";r:183;s:8:\"children\";a:0:{}}s:12:\"admin/report\";a:3:{s:8:\"instance\";r:185;s:6:\"parent\";r:165;s:8:\"children\";a:7:{s:22:\"admin/report/salesroot\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:22:\"admin/report/salesroot\";}s:21:\"admin/report/shopcart\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:21:\"admin/report/shopcart\";}s:21:\"admin/report/products\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:21:\"admin/report/products\";}s:22:\"admin/report/customers\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:22:\"admin/report/customers\";}s:19:\"admin/report/review\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:19:\"admin/report/review\";}s:17:\"admin/report/tags\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:17:\"admin/report/tags\";}s:19:\"admin/report/search\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:19:\"admin/report/search\";}}}s:22:\"admin/report/salesroot\";a:3:{s:8:\"instance\";r:915;s:6:\"parent\";r:185;s:8:\"children\";a:6:{s:28:\"admin/report/salesroot/sales\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:28:\"admin/report/salesroot/sales\";}s:26:\"admin/report/salesroot/tax\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:26:\"admin/report/salesroot/tax\";}s:31:\"admin/report/salesroot/shipping\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:31:\"admin/report/salesroot/shipping\";}s:31:\"admin/report/salesroot/invoiced\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:31:\"admin/report/salesroot/invoiced\";}s:31:\"admin/report/salesroot/refunded\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:31:\"admin/report/salesroot/refunded\";}s:30:\"admin/report/salesroot/coupons\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/report/salesroot/coupons\";}}}s:28:\"admin/report/salesroot/sales\";a:3:{s:8:\"instance\";r:933;s:6:\"parent\";r:915;s:8:\"children\";a:0:{}}s:26:\"admin/report/salesroot/tax\";a:3:{s:8:\"instance\";r:935;s:6:\"parent\";r:915;s:8:\"children\";a:0:{}}s:31:\"admin/report/salesroot/shipping\";a:3:{s:8:\"instance\";r:937;s:6:\"parent\";r:915;s:8:\"children\";a:0:{}}s:31:\"admin/report/salesroot/invoiced\";a:3:{s:8:\"instance\";r:939;s:6:\"parent\";r:915;s:8:\"children\";a:0:{}}s:31:\"admin/report/salesroot/refunded\";a:3:{s:8:\"instance\";r:941;s:6:\"parent\";r:915;s:8:\"children\";a:0:{}}s:30:\"admin/report/salesroot/coupons\";a:3:{s:8:\"instance\";r:943;s:6:\"parent\";r:915;s:8:\"children\";a:0:{}}s:21:\"admin/report/shopcart\";a:3:{s:8:\"instance\";r:917;s:6:\"parent\";r:185;s:8:\"children\";a:2:{s:29:\"admin/report/shopcart/product\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:29:\"admin/report/shopcart/product\";}s:31:\"admin/report/shopcart/abandoned\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:31:\"admin/report/shopcart/abandoned\";}}}s:29:\"admin/report/shopcart/product\";a:3:{s:8:\"instance\";r:973;s:6:\"parent\";r:917;s:8:\"children\";a:0:{}}s:31:\"admin/report/shopcart/abandoned\";a:3:{s:8:\"instance\";r:975;s:6:\"parent\";r:917;s:8:\"children\";a:0:{}}s:21:\"admin/report/products\";a:3:{s:8:\"instance\";r:919;s:6:\"parent\";r:185;s:8:\"children\";a:5:{s:29:\"admin/report/products/ordered\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:29:\"admin/report/products/ordered\";}s:26:\"admin/report/products/sold\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:26:\"admin/report/products/sold\";}s:28:\"admin/report/products/viewed\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:28:\"admin/report/products/viewed\";}s:30:\"admin/report/products/lowstock\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:30:\"admin/report/products/lowstock\";}s:31:\"admin/report/products/downloads\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:31:\"admin/report/products/downloads\";}}}s:29:\"admin/report/products/ordered\";a:3:{s:8:\"instance\";r:989;s:6:\"parent\";r:919;s:8:\"children\";a:0:{}}s:26:\"admin/report/products/sold\";a:3:{s:8:\"instance\";r:991;s:6:\"parent\";r:919;s:8:\"children\";a:0:{}}s:28:\"admin/report/products/viewed\";a:3:{s:8:\"instance\";r:993;s:6:\"parent\";r:919;s:8:\"children\";a:0:{}}s:30:\"admin/report/products/lowstock\";a:3:{s:8:\"instance\";r:995;s:6:\"parent\";r:919;s:8:\"children\";a:0:{}}s:31:\"admin/report/products/downloads\";a:3:{s:8:\"instance\";r:997;s:6:\"parent\";r:919;s:8:\"children\";a:0:{}}s:22:\"admin/report/customers\";a:3:{s:8:\"instance\";r:921;s:6:\"parent\";r:185;s:8:\"children\";a:3:{s:31:\"admin/report/customers/accounts\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:31:\"admin/report/customers/accounts\";}s:29:\"admin/report/customers/totals\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:29:\"admin/report/customers/totals\";}s:29:\"admin/report/customers/orders\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:29:\"admin/report/customers/orders\";}}}s:31:\"admin/report/customers/accounts\";a:3:{s:8:\"instance\";r:1023;s:6:\"parent\";r:921;s:8:\"children\";a:0:{}}s:29:\"admin/report/customers/totals\";a:3:{s:8:\"instance\";r:1025;s:6:\"parent\";r:921;s:8:\"children\";a:0:{}}s:29:\"admin/report/customers/orders\";a:3:{s:8:\"instance\";r:1027;s:6:\"parent\";r:921;s:8:\"children\";a:0:{}}s:19:\"admin/report/review\";a:3:{s:8:\"instance\";r:923;s:6:\"parent\";r:185;s:8:\"children\";a:2:{s:28:\"admin/report/review/customer\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:28:\"admin/report/review/customer\";}s:27:\"admin/report/review/product\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:27:\"admin/report/review/product\";}}}s:28:\"admin/report/review/customer\";a:3:{s:8:\"instance\";r:1045;s:6:\"parent\";r:923;s:8:\"children\";a:0:{}}s:27:\"admin/report/review/product\";a:3:{s:8:\"instance\";r:1047;s:6:\"parent\";r:923;s:8:\"children\";a:0:{}}s:17:\"admin/report/tags\";a:3:{s:8:\"instance\";r:925;s:6:\"parent\";r:185;s:8:\"children\";a:3:{s:26:\"admin/report/tags/customer\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:26:\"admin/report/tags/customer\";}s:25:\"admin/report/tags/popular\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:25:\"admin/report/tags/popular\";}s:25:\"admin/report/tags/product\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:25:\"admin/report/tags/product\";}}}s:26:\"admin/report/tags/customer\";a:3:{s:8:\"instance\";r:1061;s:6:\"parent\";r:925;s:8:\"children\";a:0:{}}s:25:\"admin/report/tags/popular\";a:3:{s:8:\"instance\";r:1063;s:6:\"parent\";r:925;s:8:\"children\";a:0:{}}s:25:\"admin/report/tags/product\";a:3:{s:8:\"instance\";r:1065;s:6:\"parent\";r:925;s:8:\"children\";a:0:{}}s:19:\"admin/report/search\";a:3:{s:8:\"instance\";r:927;s:6:\"parent\";r:185;s:8:\"children\";a:0:{}}s:16:\"admin/newsletter\";a:3:{s:8:\"instance\";r:187;s:6:\"parent\";r:165;s:8:\"children\";a:4:{s:24:\"admin/newsletter/problem\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:24:\"admin/newsletter/problem\";}s:22:\"admin/newsletter/queue\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:22:\"admin/newsletter/queue\";}s:27:\"admin/newsletter/subscriber\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:27:\"admin/newsletter/subscriber\";}s:25:\"admin/newsletter/template\";O:29:\"Mage_Admin_Model_Acl_Resource\":1:{s:14:\"\0*\0_resourceId\";s:25:\"admin/newsletter/template\";}}}s:24:\"admin/newsletter/problem\";a:3:{s:8:\"instance\";r:1087;s:6:\"parent\";r:187;s:8:\"children\";a:0:{}}s:22:\"admin/newsletter/queue\";a:3:{s:8:\"instance\";r:1089;s:6:\"parent\";r:187;s:8:\"children\";a:0:{}}s:27:\"admin/newsletter/subscriber\";a:3:{s:8:\"instance\";r:1091;s:6:\"parent\";r:187;s:8:\"children\";a:0:{}}s:25:\"admin/newsletter/template\";a:3:{s:8:\"instance\";r:1093;s:6:\"parent\";r:187;s:8:\"children\";a:0:{}}}s:9:\"\0*\0_rules\";a:2:{s:12:\"allResources\";a:2:{s:8:\"allRoles\";a:2:{s:13:\"allPrivileges\";a:2:{s:4:\"type\";s:9:\"TYPE_DENY\";s:6:\"assert\";N;}s:13:\"byPrivilegeId\";a:0:{}}s:8:\"byRoleId\";a:0:{}}s:12:\"byResourceId\";a:1:{s:3:\"all\";a:1:{s:8:\"byRoleId\";a:1:{s:2:\"G1\";a:2:{s:13:\"byPrivilegeId\";a:0:{}s:13:\"allPrivileges\";a:2:{s:4:\"type\";s:10:\"TYPE_ALLOW\";s:6:\"assert\";N;}}}}}}}s:17:\"last_viewed_store\";N;s:20:\"last_edited_category\";N;}livechat|a:2:{s:23:\"_session_validator_data\";a:4:{s:11:\"remote_addr\";s:12:\"174.48.3.153\";s:8:\"http_via\";s:0:\"\";s:20:\"http_x_forwarded_for\";s:0:\"\";s:15:\"http_user_agent\";s:92:\"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10\";}s:13:\"session_hosts\";a:1:{s:22:\"www.thetennisdepot.com\";b:1;}}'),
('df6e645602b6d21aa8fdd17702a081be', NULL, 1243357766, 'core|a:5:{s:23:\"_session_validator_data\";a:4:{s:11:\"remote_addr\";s:14:\"207.241.227.91\";s:8:\"http_via\";s:0:\"\";s:20:\"http_x_forwarded_for\";s:0:\"\";s:15:\"http_user_agent\";s:27:\"ia_archiver-web.archive.org\";}s:13:\"session_hosts\";a:1:{s:18:\"thetennisdepot.com\";b:1;}s:8:\"messages\";O:34:\"Mage_Core_Model_Message_Collection\":2:{s:12:\"\0*\0_messages\";a:0:{}s:20:\"\0*\0_lastAddedMessage\";N;}s:12:\"visitor_data\";a:17:{s:0:\"\";N;s:11:\"server_addr\";i:1138544690;s:11:\"remote_addr\";i:3488736091;s:11:\"http_secure\";b:0;s:9:\"http_host\";s:18:\"thetennisdepot.com\";s:15:\"http_user_agent\";s:27:\"ia_archiver-web.archive.org\";s:20:\"http_accept_language\";s:0:\"\";s:19:\"http_accept_charset\";s:0:\"\";s:11:\"request_uri\";s:11:\"/robots.txt\";s:10:\"session_id\";s:32:\"df6e645602b6d21aa8fdd17702a081be\";s:12:\"http_referer\";s:0:\"\";s:14:\"first_visit_at\";s:19:\"2009-05-26 16:45:26\";s:14:\"is_new_visitor\";b:0;s:13:\"last_visit_at\";s:19:\"2009-05-26 16:45:26\";s:10:\"visitor_id\";s:2:\"27\";s:27:\"catalog_compare_items_count\";i:0;s:11:\"last_url_id\";s:3:\"194\";}s:8:\"last_url\";s:85:\"http://www.thetennisdepot.com/cms/index/noRoute/?SID=df6e645602b6d21aa8fdd17702a081be\";}_cookie_revalidate|d:1243357226;customer_base|a:2:{s:23:\"_session_validator_data\";a:4:{s:11:\"remote_addr\";s:14:\"207.241.227.91\";s:8:\"http_via\";s:0:\"\";s:20:\"http_x_forwarded_for\";s:0:\"\";s:15:\"http_user_agent\";s:27:\"ia_archiver-web.archive.org\";}s:13:\"session_hosts\";a:1:{s:18:\"thetennisdepot.com\";b:1;}}checkout|a:3:{s:23:\"_session_validator_data\";a:4:{s:11:\"remote_addr\";s:14:\"207.241.227.91\";s:8:\"http_via\";s:0:\"\";s:20:\"http_x_forwarded_for\";s:0:\"\";s:15:\"http_user_agent\";s:27:\"ia_archiver-web.archive.org\";}s:13:\"session_hosts\";a:1:{s:18:\"thetennisdepot.com\";b:1;}s:8:\"messages\";O:34:\"Mage_Core_Model_Message_Collection\":2:{s:12:\"\0*\0_messages\";a:0:{}s:20:\"\0*\0_lastAddedMessage\";N;}}catalog|a:3:{s:23:\"_session_validator_data\";a:4:{s:11:\"remote_addr\";s:14:\"207.241.227.91\";s:8:\"http_via\";s:0:\"\";s:20:\"http_x_forwarded_for\";s:0:\"\";s:15:\"http_user_agent\";s:27:\"ia_archiver-web.archive.org\";}s:13:\"session_hosts\";a:1:{s:18:\"thetennisdepot.com\";b:1;}s:8:\"messages\";O:34:\"Mage_Core_Model_Message_Collection\":2:{s:12:\"\0*\0_messages\";a:0:{}s:20:\"\0*\0_lastAddedMessage\";N;}}reports|a:2:{s:23:\"_session_validator_data\";a:4:{s:11:\"remote_addr\";s:14:\"207.241.227.91\";s:8:\"http_via\";s:0:\"\";s:20:\"http_x_forwarded_for\";s:0:\"\";s:15:\"http_user_agent\";s:27:\"ia_archiver-web.archive.org\";}s:13:\"session_hosts\";a:1:{s:18:\"thetennisdepot.com\";b:1;}}');

DROP TABLE IF EXISTS `dxov_core_store`;
CREATE TABLE `dxov_core_store` (
  `store_id` smallint(5) unsigned NOT NULL auto_increment,
  `code` varchar(32) NOT NULL default '',
  `website_id` smallint(5) unsigned default '0',
  `group_id` smallint(5) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `sort_order` smallint(5) unsigned NOT NULL default '0',
  `is_active` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`store_id`),
  UNIQUE KEY `code` (`code`),
  KEY `FK_STORE_WEBSITE` (`website_id`),
  KEY `is_active` (`is_active`,`sort_order`),
  KEY `FK_STORE_GROUP` (`group_id`),
  CONSTRAINT `FK_STORE_GROUP_STORE` FOREIGN KEY (`group_id`) REFERENCES `dxov_core_store_group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_STORE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Stores';

INSERT INTO `dxov_core_store` VALUES
(0, 'admin', 0, 0, 'Admin', 0, 1),
(1, 'default', 1, 1, 'Default Store View', 0, 1);

DROP TABLE IF EXISTS `dxov_core_store_group`;
CREATE TABLE `dxov_core_store_group` (
  `group_id` smallint(5) unsigned NOT NULL auto_increment,
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `root_category_id` int(10) unsigned NOT NULL default '0',
  `default_store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`group_id`),
  KEY `FK_STORE_GROUP_WEBSITE` (`website_id`),
  KEY `default_store_id` (`default_store_id`),
  CONSTRAINT `FK_STORE_GROUP_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_core_store_group` VALUES
(0, 0, 'Default', 0, 0),
(1, 1, 'The Tennis Depot', 2, 1),
(2, 1, 'Demo 01', 2, 0);

DROP TABLE IF EXISTS `dxov_core_translate`;
CREATE TABLE `dxov_core_translate` (
  `key_id` int(10) unsigned NOT NULL auto_increment,
  `string` varchar(255) NOT NULL default '',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `translate` varchar(255) NOT NULL default '',
  `locale` varchar(20) NOT NULL default 'en_US',
  PRIMARY KEY  (`key_id`),
  UNIQUE KEY `IDX_CODE` (`store_id`,`locale`,`string`),
  KEY `FK_CORE_TRANSLATE_STORE` (`store_id`),
  CONSTRAINT `FK_CORE_TRANSLATE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Translation data';

DROP TABLE IF EXISTS `dxov_core_url_rewrite`;
CREATE TABLE `dxov_core_url_rewrite` (
  `url_rewrite_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `category_id` int(10) unsigned default NULL,
  `product_id` int(10) unsigned default NULL,
  `id_path` varchar(255) NOT NULL default '',
  `request_path` varchar(255) NOT NULL default '',
  `target_path` varchar(255) NOT NULL default '',
  `is_system` tinyint(1) unsigned default '1',
  `options` varchar(255) NOT NULL default '',
  `description` varchar(255) default NULL,
  PRIMARY KEY  (`url_rewrite_id`),
  UNIQUE KEY `UNQ_REQUEST_PATH` (`store_id`,`request_path`),
  UNIQUE KEY `UNQ_PATH` (`store_id`,`id_path`,`is_system`),
  KEY `FK_CORE_URL_REWRITE_STORE` (`store_id`),
  KEY `IDX_TARGET_PATH` (`store_id`,`target_path`),
  KEY `IDX_ID_PATH` (`id_path`),
  KEY `FK_CORE_URL_REWRITE_PRODUCT` (`product_id`),
  KEY `IDX_CATEGORY_REWRITE` (`category_id`,`is_system`,`product_id`,`store_id`,`id_path`),
  CONSTRAINT `FK_CORE_URL_REWRITE_CATEGORY` FOREIGN KEY (`category_id`) REFERENCES `dxov_catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CORE_URL_REWRITE_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CORE_URL_REWRITE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_core_website`;
CREATE TABLE `dxov_core_website` (
  `website_id` smallint(5) unsigned NOT NULL auto_increment,
  `code` varchar(32) NOT NULL default '',
  `name` varchar(64) NOT NULL default '',
  `sort_order` smallint(5) unsigned NOT NULL default '0',
  `default_group_id` smallint(5) unsigned NOT NULL default '0',
  `is_default` tinyint(1) unsigned default '0',
  PRIMARY KEY  (`website_id`),
  UNIQUE KEY `code` (`code`),
  KEY `sort_order` (`sort_order`),
  KEY `default_group_id` (`default_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Websites';

INSERT INTO `dxov_core_website` VALUES
(0, 'admin', 'Admin', 0, 0, 0),
(1, 'base', 'Main Website', 0, 1, 1);

DROP TABLE IF EXISTS `dxov_cron_schedule`;
CREATE TABLE `dxov_cron_schedule` (
  `schedule_id` int(10) unsigned NOT NULL auto_increment,
  `job_code` varchar(255) NOT NULL default '0',
  `status` enum('pending','running','success','missed','error') NOT NULL default 'pending',
  `messages` text,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `scheduled_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `executed_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `finished_at` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`schedule_id`),
  KEY `task_name` (`job_code`),
  KEY `scheduled_at` (`scheduled_at`,`status`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_customer_address_entity`;
CREATE TABLE `dxov_customer_address_entity` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `increment_id` varchar(50) NOT NULL default '',
  `parent_id` int(10) unsigned default NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `is_active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`entity_id`),
  KEY `FK_CUSTOMER_ADDRESS_CUSTOMER_ID` (`parent_id`),
  CONSTRAINT `FK_CUSTOMER_ADDRESS_CUSTOMER_ID` FOREIGN KEY (`parent_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 /*!40101 DEFAULT CHARSET=utf8 */ ROW_FORMAT=DYNAMIC COMMENT='Customer Address Entities';

DROP TABLE IF EXISTS `dxov_customer_address_entity_datetime`;
CREATE TABLE `dxov_customer_address_entity_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_DATETIME_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_ADDRESS_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_DATETIME_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`),
  CONSTRAINT `FK_CUSTOMER_ADDRESS_DATETIME_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_ADDRESS_DATETIME_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_customer_address_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_ADDRESS_DATETIME_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_customer_address_entity_decimal`;
CREATE TABLE `dxov_customer_address_entity_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_DECIMAL_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_ADDRESS_DECIMAL_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_DECIMAL_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`),
  CONSTRAINT `FK_CUSTOMER_ADDRESS_DECIMAL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_ADDRESS_DECIMAL_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_customer_address_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_ADDRESS_DECIMAL_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_customer_address_entity_int`;
CREATE TABLE `dxov_customer_address_entity_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_INT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_ADDRESS_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_INT_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`),
  CONSTRAINT `FK_CUSTOMER_ADDRESS_INT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_ADDRESS_INT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_customer_address_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_ADDRESS_INT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_customer_address_entity_text`;
CREATE TABLE `dxov_customer_address_entity_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_TEXT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_ADDRESS_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_TEXT_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`),
  CONSTRAINT `FK_CUSTOMER_ADDRESS_TEXT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_ADDRESS_TEXT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_customer_address_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_ADDRESS_TEXT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_customer_address_entity_varchar`;
CREATE TABLE `dxov_customer_address_entity_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_VARCHAR_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_ADDRESS_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_VARCHAR_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`),
  CONSTRAINT `FK_CUSTOMER_ADDRESS_VARCHAR_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_ADDRESS_VARCHAR_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_customer_address_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_ADDRESS_VARCHAR_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=157 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_customer_entity`;
CREATE TABLE `dxov_customer_entity` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `website_id` smallint(5) unsigned default NULL,
  `email` varchar(255) NOT NULL default '',
  `group_id` smallint(3) unsigned NOT NULL default '0',
  `increment_id` varchar(50) NOT NULL default '',
  `store_id` smallint(5) unsigned default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `is_active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`entity_id`),
  KEY `FK_CUSTOMER_ENTITY_STORE` (`store_id`),
  KEY `IDX_ENTITY_TYPE` (`entity_type_id`),
  KEY `IDX_AUTH` (`email`,`website_id`),
  KEY `FK_CUSTOMER_WEBSITE` (`website_id`),
  CONSTRAINT `FK_CUSTOMER_ENTITY_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8 */ ROW_FORMAT=DYNAMIC COMMENT='Customer Entityies';

DROP TABLE IF EXISTS `dxov_customer_entity_datetime`;
CREATE TABLE `dxov_customer_entity_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_DATETIME_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_DATETIME_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`),
  CONSTRAINT `FK_CUSTOMER_DATETIME_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_DATETIME_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_DATETIME_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_customer_entity_decimal`;
CREATE TABLE `dxov_customer_entity_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_DECIMAL_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_DECIMAL_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_DECIMAL_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`),
  CONSTRAINT `FK_CUSTOMER_DECIMAL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_DECIMAL_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_DECIMAL_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_customer_entity_int`;
CREATE TABLE `dxov_customer_entity_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_INT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_INT_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`),
  CONSTRAINT `FK_CUSTOMER_INT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_INT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_INT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_customer_entity_text`;
CREATE TABLE `dxov_customer_entity_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_TEXT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_TEXT_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`),
  CONSTRAINT `FK_CUSTOMER_TEXT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_TEXT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_TEXT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_customer_entity_varchar`;
CREATE TABLE `dxov_customer_entity_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_VARCHAR_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_VARCHAR_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`),
  CONSTRAINT `FK_CUSTOMER_VARCHAR_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_VARCHAR_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CUSTOMER_VARCHAR_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=181 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_customer_group`;
CREATE TABLE `dxov_customer_group` (
  `customer_group_id` smallint(3) unsigned NOT NULL auto_increment,
  `customer_group_code` varchar(32) NOT NULL default '',
  `tax_class_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`customer_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Customer groups';

INSERT INTO `dxov_customer_group` VALUES
(0, 'NOT LOGGED IN', 3),
(1, 'General', 3),
(2, 'Wholesale', 3),
(3, 'Retailer', 3);

DROP TABLE IF EXISTS `dxov_dataflow_batch`;
CREATE TABLE `dxov_dataflow_batch` (
  `batch_id` int(10) unsigned NOT NULL auto_increment,
  `profile_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `adapter` varchar(128) default NULL,
  `params` text,
  `created_at` datetime default NULL,
  PRIMARY KEY  (`batch_id`),
  KEY `FK_DATAFLOW_BATCH_PROFILE` (`profile_id`),
  KEY `FK_DATAFLOW_BATCH_STORE` (`store_id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  CONSTRAINT `FK_DATAFLOW_BATCH_PROFILE` FOREIGN KEY (`profile_id`) REFERENCES `dxov_dataflow_profile` (`profile_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_DATAFLOW_BATCH_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_dataflow_batch_export`;
CREATE TABLE `dxov_dataflow_batch_export` (
  `batch_export_id` bigint(20) unsigned NOT NULL auto_increment,
  `batch_id` int(10) unsigned NOT NULL default '0',
  `batch_data` longtext,
  `status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`batch_export_id`),
  KEY `FK_DATAFLOW_BATCH_EXPORT_BATCH` (`batch_id`),
  CONSTRAINT `FK_DATAFLOW_BATCH_EXPORT_BATCH` FOREIGN KEY (`batch_id`) REFERENCES `dxov_dataflow_batch` (`batch_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_dataflow_batch_import`;
CREATE TABLE `dxov_dataflow_batch_import` (
  `batch_import_id` bigint(20) unsigned NOT NULL auto_increment,
  `batch_id` int(10) unsigned NOT NULL default '0',
  `batch_data` longtext,
  `status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`batch_import_id`),
  KEY `FK_DATAFLOW_BATCH_IMPORT_BATCH` (`batch_id`),
  CONSTRAINT `FK_DATAFLOW_BATCH_IMPORT_BATCH` FOREIGN KEY (`batch_id`) REFERENCES `dxov_dataflow_batch` (`batch_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_dataflow_import_data`;
CREATE TABLE `dxov_dataflow_import_data` (
  `import_id` int(11) NOT NULL auto_increment,
  `session_id` int(11) default NULL,
  `serial_number` int(11) NOT NULL default '0',
  `value` text,
  `status` int(1) NOT NULL default '0',
  PRIMARY KEY  (`import_id`),
  KEY `FK_dataflow_import_data` (`session_id`),
  CONSTRAINT `FK_dataflow_import_data` FOREIGN KEY (`session_id`) REFERENCES `dxov_dataflow_session` (`session_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_dataflow_profile`;
CREATE TABLE `dxov_dataflow_profile` (
  `profile_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `actions_xml` text,
  `gui_data` text,
  `direction` enum('import','export') default NULL,
  `entity_type` varchar(64) NOT NULL default '',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `data_transfer` enum('file','interactive') default NULL,
  PRIMARY KEY  (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_dataflow_profile` VALUES
(1, 'Export All Products', '2009-05-25 06:43:20', '2009-05-25 06:43:20', '<action type=\"catalog/convert_adapter_product\" method=\"load\">\r\n    <var name=\"store\"><![CDATA[0]]></var>\r\n</action>\r\n\r\n<action type=\"catalog/convert_parser_product\" method=\"unparse\">\r\n    <var name=\"store\"><![CDATA[0]]></var>\r\n</action>\r\n\r\n<action type=\"dataflow/convert_mapper_column\" method=\"map\">\r\n</action>\r\n\r\n<action type=\"dataflow/convert_parser_csv\" method=\"unparse\">\r\n    <var name=\"delimiter\"><![CDATA[,]]></var>\r\n    <var name=\"enclose\"><![CDATA[\"]]></var>\r\n    <var name=\"fieldnames\">true</var>\r\n</action>\r\n\r\n<action type=\"dataflow/convert_adapter_io\" method=\"save\">\r\n    <var name=\"type\">file</var>\r\n    <var name=\"path\">var/export</var>\r\n    <var name=\"filename\"><![CDATA[export_all_products.csv]]></var>\r\n</action>\r\n\r\n', 'a:5:{s:4:\"file\";a:7:{s:4:\"type\";s:4:\"file\";s:8:\"filename\";s:23:\"export_all_products.csv\";s:4:\"path\";s:10:\"var/export\";s:4:\"host\";s:0:\"\";s:4:\"user\";s:0:\"\";s:8:\"password\";s:0:\"\";s:7:\"passive\";s:0:\"\";}s:5:\"parse\";a:5:{s:4:\"type\";s:3:\"csv\";s:12:\"single_sheet\";s:0:\"\";s:9:\"delimiter\";s:1:\",\";s:7:\"enclose\";s:1:\"\"\";s:10:\"fieldnames\";s:4:\"true\";}s:3:\"map\";a:3:{s:14:\"only_specified\";s:0:\"\";s:7:\"product\";a:2:{s:2:\"db\";a:0:{}s:4:\"file\";a:0:{}}s:8:\"customer\";a:2:{s:2:\"db\";a:0:{}s:4:\"file\";a:0:{}}}s:7:\"product\";a:1:{s:6:\"filter\";a:8:{s:4:\"name\";s:0:\"\";s:3:\"sku\";s:0:\"\";s:4:\"type\";s:1:\"0\";s:13:\"attribute_set\";s:0:\"\";s:5:\"price\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:3:\"qty\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:10:\"visibility\";s:1:\"0\";s:6:\"status\";s:1:\"0\";}}s:8:\"customer\";a:1:{s:6:\"filter\";a:10:{s:9:\"firstname\";s:0:\"\";s:8:\"lastname\";s:0:\"\";s:5:\"email\";s:0:\"\";s:5:\"group\";s:1:\"0\";s:10:\"adressType\";s:15:\"default_billing\";s:9:\"telephone\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:0:\"\";s:6:\"region\";s:0:\"\";s:10:\"created_at\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}}}}', 'export', 'product', 0, 'file'),
(2, 'Export Product Stocks', '2009-05-25 06:43:20', '2009-05-25 06:43:20', '<action type=\"catalog/convert_adapter_product\" method=\"load\">\r\n    <var name=\"store\"><![CDATA[0]]></var>\r\n</action>\r\n\r\n<action type=\"catalog/convert_parser_product\" method=\"unparse\">\r\n    <var name=\"store\"><![CDATA[0]]></var>\r\n</action>\r\n\r\n<action type=\"dataflow/convert_mapper_column\" method=\"map\">\r\n    <var name=\"map\">\r\n        <map name=\"store\"><![CDATA[store]]></map>\r\n        <map name=\"sku\"><![CDATA[sku]]></map>\r\n        <map name=\"qty\"><![CDATA[qty]]></map>\r\n        <map name=\"is_in_stock\"><![CDATA[is_in_stock]]></map>\r\n    </var>\r\n    <var name=\"_only_specified\">true</var>\r\n</action>\r\n\r\n<action type=\"dataflow/convert_parser_csv\" method=\"unparse\">\r\n    <var name=\"delimiter\"><![CDATA[,]]></var>\r\n    <var name=\"enclose\"><![CDATA[\"]]></var>\r\n    <var name=\"fieldnames\">true</var>\r\n</action>\r\n\r\n<action type=\"dataflow/convert_adapter_io\" method=\"save\">\r\n    <var name=\"type\">file</var>\r\n    <var name=\"path\">var/export</var>\r\n    <var name=\"filename\"><![CDATA[export_product_stocks.csv]]></var>\r\n</action>\r\n\r\n', 'a:5:{s:4:\"file\";a:7:{s:4:\"type\";s:4:\"file\";s:8:\"filename\";s:25:\"export_product_stocks.csv\";s:4:\"path\";s:10:\"var/export\";s:4:\"host\";s:0:\"\";s:4:\"user\";s:0:\"\";s:8:\"password\";s:0:\"\";s:7:\"passive\";s:0:\"\";}s:5:\"parse\";a:5:{s:4:\"type\";s:3:\"csv\";s:12:\"single_sheet\";s:0:\"\";s:9:\"delimiter\";s:1:\",\";s:7:\"enclose\";s:1:\"\"\";s:10:\"fieldnames\";s:4:\"true\";}s:3:\"map\";a:3:{s:14:\"only_specified\";s:4:\"true\";s:7:\"product\";a:2:{s:2:\"db\";a:4:{i:1;s:5:\"store\";i:2;s:3:\"sku\";i:3;s:3:\"qty\";i:4;s:11:\"is_in_stock\";}s:4:\"file\";a:4:{i:1;s:5:\"store\";i:2;s:3:\"sku\";i:3;s:3:\"qty\";i:4;s:11:\"is_in_stock\";}}s:8:\"customer\";a:2:{s:2:\"db\";a:0:{}s:4:\"file\";a:0:{}}}s:7:\"product\";a:1:{s:6:\"filter\";a:8:{s:4:\"name\";s:0:\"\";s:3:\"sku\";s:0:\"\";s:4:\"type\";s:1:\"0\";s:13:\"attribute_set\";s:0:\"\";s:5:\"price\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:3:\"qty\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:10:\"visibility\";s:1:\"0\";s:6:\"status\";s:1:\"0\";}}s:8:\"customer\";a:1:{s:6:\"filter\";a:10:{s:9:\"firstname\";s:0:\"\";s:8:\"lastname\";s:0:\"\";s:5:\"email\";s:0:\"\";s:5:\"group\";s:1:\"0\";s:10:\"adressType\";s:15:\"default_billing\";s:9:\"telephone\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:0:\"\";s:6:\"region\";s:0:\"\";s:10:\"created_at\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}}}}', 'export', 'product', 0, 'file'),
(3, 'Import All Products', '2009-05-25 06:43:20', '2009-05-25 06:43:20', '<action type=\"dataflow/convert_parser_csv\" method=\"parse\">\r\n    <var name=\"delimiter\"><![CDATA[,]]></var>\r\n    <var name=\"enclose\"><![CDATA[\"]]></var>\r\n    <var name=\"fieldnames\">true</var>\r\n    <var name=\"store\"><![CDATA[0]]></var>\r\n    <var name=\"adapter\">catalog/convert_adapter_product</var>\r\n    <var name=\"method\">parse</var>\r\n</action>', 'a:5:{s:4:\"file\";a:7:{s:4:\"type\";s:4:\"file\";s:8:\"filename\";s:23:\"export_all_products.csv\";s:4:\"path\";s:10:\"var/export\";s:4:\"host\";s:0:\"\";s:4:\"user\";s:0:\"\";s:8:\"password\";s:0:\"\";s:7:\"passive\";s:0:\"\";}s:5:\"parse\";a:5:{s:4:\"type\";s:3:\"csv\";s:12:\"single_sheet\";s:0:\"\";s:9:\"delimiter\";s:1:\",\";s:7:\"enclose\";s:1:\"\"\";s:10:\"fieldnames\";s:4:\"true\";}s:3:\"map\";a:3:{s:14:\"only_specified\";s:0:\"\";s:7:\"product\";a:2:{s:2:\"db\";a:0:{}s:4:\"file\";a:0:{}}s:8:\"customer\";a:2:{s:2:\"db\";a:0:{}s:4:\"file\";a:0:{}}}s:7:\"product\";a:1:{s:6:\"filter\";a:8:{s:4:\"name\";s:0:\"\";s:3:\"sku\";s:0:\"\";s:4:\"type\";s:1:\"0\";s:13:\"attribute_set\";s:0:\"\";s:5:\"price\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:3:\"qty\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:10:\"visibility\";s:1:\"0\";s:6:\"status\";s:1:\"0\";}}s:8:\"customer\";a:1:{s:6:\"filter\";a:10:{s:9:\"firstname\";s:0:\"\";s:8:\"lastname\";s:0:\"\";s:5:\"email\";s:0:\"\";s:5:\"group\";s:1:\"0\";s:10:\"adressType\";s:15:\"default_billing\";s:9:\"telephone\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:0:\"\";s:6:\"region\";s:0:\"\";s:10:\"created_at\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}}}}', 'import', 'product', 0, 'interactive'),
(4, 'Import Product Stocks', '2009-05-25 06:43:20', '2009-05-25 06:43:20', '<action type=\"dataflow/convert_parser_csv\" method=\"parse\">\r\n    <var name=\"delimiter\"><![CDATA[,]]></var>\r\n    <var name=\"enclose\"><![CDATA[\"]]></var>\r\n    <var name=\"fieldnames\">true</var>\r\n    <var name=\"store\"><![CDATA[0]]></var>\r\n    <var name=\"adapter\">catalog/convert_adapter_product</var>\r\n    <var name=\"method\">parse</var>\r\n</action>', 'a:5:{s:4:\"file\";a:7:{s:4:\"type\";s:4:\"file\";s:8:\"filename\";s:18:\"export_product.csv\";s:4:\"path\";s:10:\"var/export\";s:4:\"host\";s:0:\"\";s:4:\"user\";s:0:\"\";s:8:\"password\";s:0:\"\";s:7:\"passive\";s:0:\"\";}s:5:\"parse\";a:5:{s:4:\"type\";s:3:\"csv\";s:12:\"single_sheet\";s:0:\"\";s:9:\"delimiter\";s:1:\",\";s:7:\"enclose\";s:1:\"\"\";s:10:\"fieldnames\";s:4:\"true\";}s:3:\"map\";a:3:{s:14:\"only_specified\";s:0:\"\";s:7:\"product\";a:2:{s:2:\"db\";a:0:{}s:4:\"file\";a:0:{}}s:8:\"customer\";a:2:{s:2:\"db\";a:0:{}s:4:\"file\";a:0:{}}}s:7:\"product\";a:1:{s:6:\"filter\";a:8:{s:4:\"name\";s:0:\"\";s:3:\"sku\";s:0:\"\";s:4:\"type\";s:1:\"0\";s:13:\"attribute_set\";s:0:\"\";s:5:\"price\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:3:\"qty\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:10:\"visibility\";s:1:\"0\";s:6:\"status\";s:1:\"0\";}}s:8:\"customer\";a:1:{s:6:\"filter\";a:10:{s:9:\"firstname\";s:0:\"\";s:8:\"lastname\";s:0:\"\";s:5:\"email\";s:0:\"\";s:5:\"group\";s:1:\"0\";s:10:\"adressType\";s:15:\"default_billing\";s:9:\"telephone\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:0:\"\";s:6:\"region\";s:0:\"\";s:10:\"created_at\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}}}}', 'import', 'product', 0, 'interactive'),
(5, 'Export Customers', '2009-05-25 06:43:20', '2009-05-25 06:43:20', '<action type=\"customer/convert_adapter_customer\" method=\"load\">\r\n    <var name=\"store\"><![CDATA[0]]></var>\r\n    <var name=\"filter/adressType\"><![CDATA[default_billing]]></var>\r\n</action>\r\n\r\n<action type=\"customer/convert_parser_customer\" method=\"unparse\">\r\n    <var name=\"store\"><![CDATA[0]]></var>\r\n</action>\r\n\r\n<action type=\"dataflow/convert_mapper_column\" method=\"map\">\r\n</action>\r\n\r\n<action type=\"dataflow/convert_parser_csv\" method=\"unparse\">\r\n    <var name=\"delimiter\"><![CDATA[,]]></var>\r\n    <var name=\"enclose\"><![CDATA[\"]]></var>\r\n    <var name=\"fieldnames\">true</var>\r\n</action>\r\n\r\n<action type=\"dataflow/convert_adapter_io\" method=\"save\">\r\n    <var name=\"type\">file</var>\r\n    <var name=\"path\">var/export</var>\r\n    <var name=\"filename\"><![CDATA[export_customers.csv]]></var>\r\n</action>\r\n\r\n', 'a:5:{s:4:\"file\";a:7:{s:4:\"type\";s:4:\"file\";s:8:\"filename\";s:20:\"export_customers.csv\";s:4:\"path\";s:10:\"var/export\";s:4:\"host\";s:0:\"\";s:4:\"user\";s:0:\"\";s:8:\"password\";s:0:\"\";s:7:\"passive\";s:0:\"\";}s:5:\"parse\";a:5:{s:4:\"type\";s:3:\"csv\";s:12:\"single_sheet\";s:0:\"\";s:9:\"delimiter\";s:1:\",\";s:7:\"enclose\";s:1:\"\"\";s:10:\"fieldnames\";s:4:\"true\";}s:3:\"map\";a:3:{s:14:\"only_specified\";s:0:\"\";s:7:\"product\";a:2:{s:2:\"db\";a:0:{}s:4:\"file\";a:0:{}}s:8:\"customer\";a:2:{s:2:\"db\";a:0:{}s:4:\"file\";a:0:{}}}s:7:\"product\";a:1:{s:6:\"filter\";a:8:{s:4:\"name\";s:0:\"\";s:3:\"sku\";s:0:\"\";s:4:\"type\";s:1:\"0\";s:13:\"attribute_set\";s:0:\"\";s:5:\"price\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:3:\"qty\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:10:\"visibility\";s:1:\"0\";s:6:\"status\";s:1:\"0\";}}s:8:\"customer\";a:1:{s:6:\"filter\";a:10:{s:9:\"firstname\";s:0:\"\";s:8:\"lastname\";s:0:\"\";s:5:\"email\";s:0:\"\";s:5:\"group\";s:1:\"0\";s:10:\"adressType\";s:15:\"default_billing\";s:9:\"telephone\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:0:\"\";s:6:\"region\";s:0:\"\";s:10:\"created_at\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}}}}', 'export', 'customer', 0, 'file'),
(6, 'Import Customers', '2009-05-25 06:43:20', '2009-05-25 06:43:20', '<action type=\"dataflow/convert_parser_csv\" method=\"parse\">\r\n    <var name=\"delimiter\"><![CDATA[,]]></var>\r\n    <var name=\"enclose\"><![CDATA[\"]]></var>\r\n    <var name=\"fieldnames\">true</var>\r\n    <var name=\"store\"><![CDATA[0]]></var>\r\n    <var name=\"adapter\">customer/convert_adapter_customer</var>\r\n    <var name=\"method\">parse</var>\r\n</action>', 'a:5:{s:4:\"file\";a:7:{s:4:\"type\";s:4:\"file\";s:8:\"filename\";s:19:\"export_customer.csv\";s:4:\"path\";s:10:\"var/export\";s:4:\"host\";s:0:\"\";s:4:\"user\";s:0:\"\";s:8:\"password\";s:0:\"\";s:7:\"passive\";s:0:\"\";}s:5:\"parse\";a:5:{s:4:\"type\";s:3:\"csv\";s:12:\"single_sheet\";s:0:\"\";s:9:\"delimiter\";s:1:\",\";s:7:\"enclose\";s:1:\"\"\";s:10:\"fieldnames\";s:4:\"true\";}s:3:\"map\";a:3:{s:14:\"only_specified\";s:0:\"\";s:7:\"product\";a:2:{s:2:\"db\";a:0:{}s:4:\"file\";a:0:{}}s:8:\"customer\";a:2:{s:2:\"db\";a:0:{}s:4:\"file\";a:0:{}}}s:7:\"product\";a:1:{s:6:\"filter\";a:8:{s:4:\"name\";s:0:\"\";s:3:\"sku\";s:0:\"\";s:4:\"type\";s:1:\"0\";s:13:\"attribute_set\";s:0:\"\";s:5:\"price\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:3:\"qty\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}s:10:\"visibility\";s:1:\"0\";s:6:\"status\";s:1:\"0\";}}s:8:\"customer\";a:1:{s:6:\"filter\";a:10:{s:9:\"firstname\";s:0:\"\";s:8:\"lastname\";s:0:\"\";s:5:\"email\";s:0:\"\";s:5:\"group\";s:1:\"0\";s:10:\"adressType\";s:15:\"default_billing\";s:9:\"telephone\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:0:\"\";s:6:\"region\";s:0:\"\";s:10:\"created_at\";a:2:{s:4:\"from\";s:0:\"\";s:2:\"to\";s:0:\"\";}}}}', 'import', 'customer', 0, 'interactive');

DROP TABLE IF EXISTS `dxov_dataflow_profile_history`;
CREATE TABLE `dxov_dataflow_profile_history` (
  `history_id` int(10) unsigned NOT NULL auto_increment,
  `profile_id` int(10) unsigned NOT NULL default '0',
  `action_code` varchar(64) default NULL,
  `user_id` int(10) unsigned NOT NULL default '0',
  `performed_at` datetime default NULL,
  PRIMARY KEY  (`history_id`),
  KEY `FK_dataflow_profile_history` (`profile_id`),
  CONSTRAINT `FK_dataflow_profile_history` FOREIGN KEY (`profile_id`) REFERENCES `dxov_dataflow_profile` (`profile_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_dataflow_session`;
CREATE TABLE `dxov_dataflow_session` (
  `session_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `created_date` datetime default NULL,
  `file` varchar(255) default NULL,
  `type` varchar(32) default NULL,
  `direction` varchar(32) default NULL,
  `comment` varchar(255) default NULL,
  PRIMARY KEY  (`session_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_design_change`;
CREATE TABLE `dxov_design_change` (
  `design_change_id` int(11) NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `design` varchar(255) NOT NULL default '',
  `date_from` date default NULL,
  `date_to` date default NULL,
  PRIMARY KEY  (`design_change_id`),
  KEY `FK_DESIGN_CHANGE_STORE` (`store_id`),
  CONSTRAINT `FK_DESIGN_CHANGE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_directory_country`;
CREATE TABLE `dxov_directory_country` (
  `country_id` varchar(2) NOT NULL default '',
  `iso2_code` varchar(2) NOT NULL default '',
  `iso3_code` varchar(3) NOT NULL default '',
  PRIMARY KEY  (`country_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Countries';

INSERT INTO `dxov_directory_country` VALUES
('AD', 'AD', 'AND'),
('AE', 'AE', 'ARE'),
('AF', 'AF', 'AFG'),
('AG', 'AG', 'ATG'),
('AI', 'AI', 'AIA'),
('AL', 'AL', 'ALB'),
('AM', 'AM', 'ARM'),
('AN', 'AN', 'ANT'),
('AO', 'AO', 'AGO'),
('AQ', 'AQ', 'ATA'),
('AR', 'AR', 'ARG'),
('AS', 'AS', 'ASM'),
('AT', 'AT', 'AUT'),
('AU', 'AU', 'AUS'),
('AW', 'AW', 'ABW'),
('AX', 'AX', 'ALA'),
('AZ', 'AZ', 'AZE'),
('BA', 'BA', 'BIH'),
('BB', 'BB', 'BRB'),
('BD', 'BD', 'BGD'),
('BE', 'BE', 'BEL'),
('BF', 'BF', 'BFA'),
('BG', 'BG', 'BGR'),
('BH', 'BH', 'BHR'),
('BI', 'BI', 'BDI'),
('BJ', 'BJ', 'BEN'),
('BL', 'BL', 'BLM'),
('BM', 'BM', 'BMU'),
('BN', 'BN', 'BRN'),
('BO', 'BO', 'BOL'),
('BR', 'BR', 'BRA'),
('BS', 'BS', 'BHS'),
('BT', 'BT', 'BTN'),
('BV', 'BV', 'BVT'),
('BW', 'BW', 'BWA'),
('BY', 'BY', 'BLR'),
('BZ', 'BZ', 'BLZ'),
('CA', 'CA', 'CAN'),
('CC', 'CC', 'CCK'),
('CD', 'CD', 'COD'),
('CF', 'CF', 'CAF'),
('CG', 'CG', 'COG'),
('CH', 'CH', 'CHE'),
('CI', 'CI', 'CIV'),
('CK', 'CK', 'COK'),
('CL', 'CL', 'CHL'),
('CM', 'CM', 'CMR'),
('CN', 'CN', 'CHN'),
('CO', 'CO', 'COL'),
('CR', 'CR', 'CRI'),
('CS', 'CS', 'SCG'),
('CU', 'CU', 'CUB'),
('CV', 'CV', 'CPV'),
('CX', 'CX', 'CXR'),
('CY', 'CY', 'CYP'),
('CZ', 'CZ', 'CZE'),
('DE', 'DE', 'DEU'),
('DJ', 'DJ', 'DJI'),
('DK', 'DK', 'DNK'),
('DM', 'DM', 'DMA'),
('DO', 'DO', 'DOM'),
('DZ', 'DZ', 'DZA'),
('EC', 'EC', 'ECU'),
('EE', 'EE', 'EST'),
('EG', 'EG', 'EGY'),
('EH', 'EH', 'ESH'),
('ER', 'ER', 'ERI'),
('ES', 'ES', 'ESP'),
('ET', 'ET', 'ETH'),
('FI', 'FI', 'FIN'),
('FJ', 'FJ', 'FJI'),
('FK', 'FK', 'FLK'),
('FM', 'FM', 'FSM'),
('FO', 'FO', 'FRO'),
('FR', 'FR', 'FRA'),
('FX', 'FX', 'FXX'),
('GA', 'GA', 'GAB'),
('GB', 'GB', 'GBR'),
('GD', 'GD', 'GRD'),
('GE', 'GE', 'GEO'),
('GF', 'GF', 'GUF'),
('GG', 'GG', 'GGY'),
('GH', 'GH', 'GHA'),
('GI', 'GI', 'GIB'),
('GL', 'GL', 'GRL'),
('GM', 'GM', 'GMB'),
('GN', 'GN', 'GIN'),
('GP', 'GP', 'GLP'),
('GQ', 'GQ', 'GNQ'),
('GR', 'GR', 'GRC'),
('GS', 'GS', 'SGS'),
('GT', 'GT', 'GTM'),
('GU', 'GU', 'GUM'),
('GW', 'GW', 'GNB'),
('GY', 'GY', 'GUY'),
('HK', 'HK', 'HKG'),
('HM', 'HM', 'HMD'),
('HN', 'HN', 'HND'),
('HR', 'HR', 'HRV'),
('HT', 'HT', 'HTI'),
('HU', 'HU', 'HUN'),
('ID', 'ID', 'IDN'),
('IE', 'IE', 'IRL'),
('IL', 'IL', 'ISR'),
('IM', 'IM', 'IMN'),
('IN', 'IN', 'IND'),
('IO', 'IO', 'IOT'),
('IQ', 'IQ', 'IRQ'),
('IR', 'IR', 'IRN'),
('IS', 'IS', 'ISL'),
('IT', 'IT', 'ITA'),
('JE', 'JE', 'JEY'),
('JM', 'JM', 'JAM'),
('JO', 'JO', 'JOR'),
('JP', 'JP', 'JPN'),
('KE', 'KE', 'KEN'),
('KG', 'KG', 'KGZ'),
('KH', 'KH', 'KHM'),
('KI', 'KI', 'KIR'),
('KM', 'KM', 'COM'),
('KN', 'KN', 'KNA'),
('KP', 'KP', 'PRK'),
('KR', 'KR', 'KOR'),
('KW', 'KW', 'KWT'),
('KY', 'KY', 'CYM'),
('KZ', 'KZ', 'KAZ'),
('LA', 'LA', 'LAO'),
('LB', 'LB', 'LBN'),
('LC', 'LC', 'LCA'),
('LI', 'LI', 'LIE'),
('LK', 'LK', 'LKA'),
('LR', 'LR', 'LBR'),
('LS', 'LS', 'LSO'),
('LT', 'LT', 'LTU'),
('LU', 'LU', 'LUX'),
('LV', 'LV', 'LVA'),
('LY', 'LY', 'LBY'),
('MA', 'MA', 'MAR'),
('MC', 'MC', 'MCO'),
('MD', 'MD', 'MDA'),
('ME', 'ME', 'MNE'),
('MF', 'MF', 'MAF'),
('MG', 'MG', 'MDG'),
('MH', 'MH', 'MHL'),
('MK', 'MK', 'MKD'),
('ML', 'ML', 'MLI'),
('MM', 'MM', 'MMR'),
('MN', 'MN', 'MNG'),
('MO', 'MO', 'MAC'),
('MP', 'MP', 'MNP'),
('MQ', 'MQ', 'MTQ'),
('MR', 'MR', 'MRT'),
('MS', 'MS', 'MSR'),
('MT', 'MT', 'MLT'),
('MU', 'MU', 'MUS'),
('MV', 'MV', 'MDV'),
('MW', 'MW', 'MWI'),
('MX', 'MX', 'MEX'),
('MY', 'MY', 'MYS'),
('MZ', 'MZ', 'MOZ'),
('NA', 'NA', 'NAM'),
('NC', 'NC', 'NCL'),
('NE', 'NE', 'NER'),
('NF', 'NF', 'NFK'),
('NG', 'NG', 'NGA'),
('NI', 'NI', 'NIC'),
('NL', 'NL', 'NLD'),
('NO', 'NO', 'NOR'),
('NP', 'NP', 'NPL'),
('NR', 'NR', 'NRU'),
('NU', 'NU', 'NIU'),
('NZ', 'NZ', 'NZL'),
('OM', 'OM', 'OMN'),
('PA', 'PA', 'PAN'),
('PE', 'PE', 'PER'),
('PF', 'PF', 'PYF'),
('PG', 'PG', 'PNG'),
('PH', 'PH', 'PHL'),
('PK', 'PK', 'PAK'),
('PL', 'PL', 'POL'),
('PM', 'PM', 'SPM'),
('PN', 'PN', 'PCN'),
('PR', 'PR', 'PRI'),
('PS', 'PS', 'PSE'),
('PT', 'PT', 'PRT'),
('PW', 'PW', 'PLW'),
('PY', 'PY', 'PRY'),
('QA', 'QA', 'QAT'),
('RE', 'RE', 'REU'),
('RO', 'RO', 'ROM'),
('RS', 'RS', 'SRB'),
('RU', 'RU', 'RUS'),
('RW', 'RW', 'RWA'),
('SA', 'SA', 'SAU'),
('SB', 'SB', 'SLB'),
('SC', 'SC', 'SYC'),
('SD', 'SD', 'SDN'),
('SE', 'SE', 'SWE'),
('SG', 'SG', 'SGP'),
('SH', 'SH', 'SHN'),
('SI', 'SI', 'SVN'),
('SJ', 'SJ', 'SJM'),
('SK', 'SK', 'SVK'),
('SL', 'SL', 'SLE'),
('SM', 'SM', 'SMR'),
('SN', 'SN', 'SEN'),
('SO', 'SO', 'SOM'),
('SR', 'SR', 'SUR'),
('ST', 'ST', 'STP'),
('SV', 'SV', 'SLV'),
('SY', 'SY', 'SYR'),
('SZ', 'SZ', 'SWZ'),
('TC', 'TC', 'TCA'),
('TD', 'TD', 'TCD'),
('TF', 'TF', 'ATF'),
('TG', 'TG', 'TGO'),
('TH', 'TH', 'THA'),
('TJ', 'TJ', 'TJK'),
('TK', 'TK', 'TKL'),
('TL', 'TL', 'TLS'),
('TM', 'TM', 'TKM'),
('TN', 'TN', 'TUN'),
('TO', 'TO', 'TON'),
('TR', 'TR', 'TUR'),
('TT', 'TT', 'TTO'),
('TV', 'TV', 'TUV'),
('TW', 'TW', 'TWN'),
('TZ', 'TZ', 'TZA'),
('UA', 'UA', 'UKR'),
('UG', 'UG', 'UGA'),
('UM', 'UM', 'UMI'),
('US', 'US', 'USA'),
('UY', 'UY', 'URY'),
('UZ', 'UZ', 'UZB'),
('VA', 'VA', 'VAT'),
('VC', 'VC', 'VCT'),
('VE', 'VE', 'VEN'),
('VG', 'VG', 'VGB'),
('VI', 'VI', 'VIR'),
('VN', 'VN', 'VNM'),
('VU', 'VU', 'VUT'),
('WF', 'WF', 'WLF'),
('WS', 'WS', 'WSM'),
('YE', 'YE', 'YEM'),
('YT', 'YT', 'MYT'),
('ZA', 'ZA', 'ZAF'),
('ZM', 'ZM', 'ZMB'),
('ZW', 'ZW', 'ZWE');

DROP TABLE IF EXISTS `dxov_directory_country_format`;
CREATE TABLE `dxov_directory_country_format` (
  `country_format_id` int(10) unsigned NOT NULL auto_increment,
  `country_id` varchar(2) NOT NULL default '',
  `type` varchar(30) NOT NULL default '',
  `format` text NOT NULL,
  PRIMARY KEY  (`country_format_id`),
  UNIQUE KEY `country_type` (`country_id`,`type`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Countries format';

DROP TABLE IF EXISTS `dxov_directory_country_region`;
CREATE TABLE `dxov_directory_country_region` (
  `region_id` mediumint(8) unsigned NOT NULL auto_increment,
  `country_id` varchar(4) NOT NULL default '0',
  `code` varchar(32) NOT NULL default '',
  `default_name` varchar(255) default NULL,
  PRIMARY KEY  (`region_id`),
  KEY `FK_REGION_COUNTRY` (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=278 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Country regions';

INSERT INTO `dxov_directory_country_region` VALUES
(1, 'US', 'AL', 'Alabama'),
(2, 'US', 'AK', 'Alaska'),
(3, 'US', 'AS', 'American Samoa'),
(4, 'US', 'AZ', 'Arizona'),
(5, 'US', 'AR', 'Arkansas'),
(6, 'US', 'AF', 'Armed Forces Africa'),
(7, 'US', 'AA', 'Armed Forces Americas'),
(8, 'US', 'AC', 'Armed Forces Canada'),
(9, 'US', 'AE', 'Armed Forces Europe'),
(10, 'US', 'AM', 'Armed Forces Middle East'),
(11, 'US', 'AP', 'Armed Forces Pacific'),
(12, 'US', 'CA', 'California'),
(13, 'US', 'CO', 'Colorado'),
(14, 'US', 'CT', 'Connecticut'),
(15, 'US', 'DE', 'Delaware'),
(16, 'US', 'DC', 'District of Columbia'),
(17, 'US', 'FM', 'Federated States Of Micronesia'),
(18, 'US', 'FL', 'Florida'),
(19, 'US', 'GA', 'Georgia'),
(20, 'US', 'GU', 'Guam'),
(21, 'US', 'HI', 'Hawaii'),
(22, 'US', 'ID', 'Idaho'),
(23, 'US', 'IL', 'Illinois'),
(24, 'US', 'IN', 'Indiana'),
(25, 'US', 'IA', 'Iowa'),
(26, 'US', 'KS', 'Kansas'),
(27, 'US', 'KY', 'Kentucky'),
(28, 'US', 'LA', 'Louisiana'),
(29, 'US', 'ME', 'Maine'),
(30, 'US', 'MH', 'Marshall Islands'),
(31, 'US', 'MD', 'Maryland'),
(32, 'US', 'MA', 'Massachusetts'),
(33, 'US', 'MI', 'Michigan'),
(34, 'US', 'MN', 'Minnesota'),
(35, 'US', 'MS', 'Mississippi'),
(36, 'US', 'MO', 'Missouri'),
(37, 'US', 'MT', 'Montana'),
(38, 'US', 'NE', 'Nebraska'),
(39, 'US', 'NV', 'Nevada'),
(40, 'US', 'NH', 'New Hampshire'),
(41, 'US', 'NJ', 'New Jersey'),
(42, 'US', 'NM', 'New Mexico'),
(43, 'US', 'NY', 'New York'),
(44, 'US', 'NC', 'North Carolina'),
(45, 'US', 'ND', 'North Dakota'),
(46, 'US', 'MP', 'Northern Mariana Islands'),
(47, 'US', 'OH', 'Ohio'),
(48, 'US', 'OK', 'Oklahoma'),
(49, 'US', 'OR', 'Oregon'),
(50, 'US', 'PW', 'Palau'),
(51, 'US', 'PA', 'Pennsylvania'),
(52, 'US', 'PR', 'Puerto Rico'),
(53, 'US', 'RI', 'Rhode Island'),
(54, 'US', 'SC', 'South Carolina'),
(55, 'US', 'SD', 'South Dakota'),
(56, 'US', 'TN', 'Tennessee'),
(57, 'US', 'TX', 'Texas'),
(58, 'US', 'UT', 'Utah'),
(59, 'US', 'VT', 'Vermont'),
(60, 'US', 'VI', 'Virgin Islands'),
(61, 'US', 'VA', 'Virginia'),
(62, 'US', 'WA', 'Washington'),
(63, 'US', 'WV', 'West Virginia'),
(64, 'US', 'WI', 'Wisconsin'),
(65, 'US', 'WY', 'Wyoming'),
(66, 'CA', 'AB', 'Alberta'),
(67, 'CA', 'BC', 'British Columbia'),
(68, 'CA', 'MB', 'Manitoba'),
(69, 'CA', 'NF', 'Newfoundland'),
(70, 'CA', 'NB', 'New Brunswick'),
(71, 'CA', 'NS', 'Nova Scotia'),
(72, 'CA', 'NT', 'Northwest Territories'),
(73, 'CA', 'NU', 'Nunavut'),
(74, 'CA', 'ON', 'Ontario'),
(75, 'CA', 'PE', 'Prince Edward Island'),
(76, 'CA', 'QC', 'Quebec'),
(77, 'CA', 'SK', 'Saskatchewan'),
(78, 'CA', 'YT', 'Yukon Territory'),
(79, 'DE', 'NDS', 'Niedersachsen'),
(80, 'DE', 'BAW', 'Baden-Württemberg'),
(81, 'DE', 'BAY', 'Bayern'),
(82, 'DE', 'BER', 'Berlin'),
(83, 'DE', 'BRG', 'Brandenburg'),
(84, 'DE', 'BRE', 'Bremen'),
(85, 'DE', 'HAM', 'Hamburg'),
(86, 'DE', 'HES', 'Hessen'),
(87, 'DE', 'MEC', 'Mecklenburg-Vorpommern'),
(88, 'DE', 'NRW', 'Nordrhein-Westfalen'),
(89, 'DE', 'RHE', 'Rheinland-Pfalz'),
(90, 'DE', 'SAR', 'Saarland'),
(91, 'DE', 'SAS', 'Sachsen'),
(92, 'DE', 'SAC', 'Sachsen-Anhalt'),
(93, 'DE', 'SCN', 'Schleswig-Holstein'),
(94, 'DE', 'THE', 'Thüringen'),
(95, 'AT', 'WI', 'Wien'),
(96, 'AT', 'NO', 'Niederösterreich'),
(97, 'AT', 'OO', 'Oberösterreich'),
(98, 'AT', 'SB', 'Salzburg'),
(99, 'AT', 'KN', 'Kärnten'),
(100, 'AT', 'ST', 'Steiermark'),
(101, 'AT', 'TI', 'Tirol'),
(102, 'AT', 'BL', 'Burgenland'),
(103, 'AT', 'VB', 'Voralberg'),
(104, 'CH', 'AG', 'Aargau'),
(105, 'CH', 'AI', 'Appenzell Innerrhoden'),
(106, 'CH', 'AR', 'Appenzell Ausserrhoden'),
(107, 'CH', 'BE', 'Bern'),
(108, 'CH', 'BL', 'Basel-Landschaft'),
(109, 'CH', 'BS', 'Basel-Stadt'),
(110, 'CH', 'FR', 'Freiburg'),
(111, 'CH', 'GE', 'Genf'),
(112, 'CH', 'GL', 'Glarus'),
(113, 'CH', 'JU', 'Graubünden'),
(114, 'CH', 'JU', 'Jura'),
(115, 'CH', 'LU', 'Luzern'),
(116, 'CH', 'NE', 'Neuenburg'),
(117, 'CH', 'NW', 'Nidwalden'),
(118, 'CH', 'OW', 'Obwalden'),
(119, 'CH', 'SG', 'St. Gallen'),
(120, 'CH', 'SH', 'Schaffhausen'),
(121, 'CH', 'SO', 'Solothurn'),
(122, 'CH', 'SZ', 'Schwyz'),
(123, 'CH', 'TG', 'Thurgau'),
(124, 'CH', 'TI', 'Tessin'),
(125, 'CH', 'UR', 'Uri'),
(126, 'CH', 'VD', 'Waadt'),
(127, 'CH', 'VS', 'Wallis'),
(128, 'CH', 'ZG', 'Zug'),
(129, 'CH', 'ZH', 'Zürich'),
(130, 'ES', 'A Coruсa', 'A Coruña'),
(131, 'ES', 'Alava', 'Alava'),
(132, 'ES', 'Albacete', 'Albacete'),
(133, 'ES', 'Alicante', 'Alicante'),
(134, 'ES', 'Almeria', 'Almeria'),
(135, 'ES', 'Asturias', 'Asturias'),
(136, 'ES', 'Avila', 'Avila'),
(137, 'ES', 'Badajoz', 'Badajoz'),
(138, 'ES', 'Baleares', 'Baleares'),
(139, 'ES', 'Barcelona', 'Barcelona'),
(140, 'ES', 'Burgos', 'Burgos'),
(141, 'ES', 'Caceres', 'Caceres'),
(142, 'ES', 'Cadiz', 'Cadiz'),
(143, 'ES', 'Cantabria', 'Cantabria'),
(144, 'ES', 'Castellon', 'Castellon'),
(145, 'ES', 'Ceuta', 'Ceuta'),
(146, 'ES', 'Ciudad Real', 'Ciudad Real'),
(147, 'ES', 'Cordoba', 'Cordoba'),
(148, 'ES', 'Cuenca', 'Cuenca'),
(149, 'ES', 'Girona', 'Girona'),
(150, 'ES', 'Granada', 'Granada'),
(151, 'ES', 'Guadalajara', 'Guadalajara'),
(152, 'ES', 'Guipuzcoa', 'Guipuzcoa'),
(153, 'ES', 'Huelva', 'Huelva'),
(154, 'ES', 'Huesca', 'Huesca'),
(155, 'ES', 'Jaen', 'Jaen'),
(156, 'ES', 'La Rioja', 'La Rioja'),
(157, 'ES', 'Las Palmas', 'Las Palmas'),
(158, 'ES', 'Leon', 'Leon'),
(159, 'ES', 'Lleida', 'Lleida'),
(160, 'ES', 'Lugo', 'Lugo'),
(161, 'ES', 'Madrid', 'Madrid'),
(162, 'ES', 'Malaga', 'Malaga'),
(163, 'ES', 'Melilla', 'Melilla'),
(164, 'ES', 'Murcia', 'Murcia'),
(165, 'ES', 'Navarra', 'Navarra'),
(166, 'ES', 'Ourense', 'Ourense'),
(167, 'ES', 'Palencia', 'Palencia'),
(168, 'ES', 'Pontevedra', 'Pontevedra'),
(169, 'ES', 'Salamanca', 'Salamanca'),
(170, 'ES', 'Santa Cruz de Tenerife', 'Santa Cruz de Tenerife'),
(171, 'ES', 'Segovia', 'Segovia'),
(172, 'ES', 'Sevilla', 'Sevilla'),
(173, 'ES', 'Soria', 'Soria'),
(174, 'ES', 'Tarragona', 'Tarragona'),
(175, 'ES', 'Teruel', 'Teruel'),
(176, 'ES', 'Toledo', 'Toledo'),
(177, 'ES', 'Valencia', 'Valencia'),
(178, 'ES', 'Valladolid', 'Valladolid'),
(179, 'ES', 'Vizcaya', 'Vizcaya'),
(180, 'ES', 'Zamora', 'Zamora'),
(181, 'ES', 'Zaragoza', 'Zaragoza'),
(182, 'FR', '01', 'Ain'),
(183, 'FR', '02', 'Aisne'),
(184, 'FR', '03', 'Allier'),
(185, 'FR', '04', 'Alpes-de-Haute-Provence'),
(186, 'FR', '05', 'Hautes-Alpes'),
(187, 'FR', '06', 'Alpes-Maritimes'),
(188, 'FR', '07', 'Ardèche'),
(189, 'FR', '08', 'Ardennes'),
(190, 'FR', '09', 'Ariège'),
(191, 'FR', '10', 'Aube'),
(192, 'FR', '11', 'Aude'),
(193, 'FR', '12', 'Aveyron'),
(194, 'FR', '13', 'Bouches-du-Rhône'),
(195, 'FR', '14', 'Calvados'),
(196, 'FR', '15', 'Cantal'),
(197, 'FR', '16', 'Charente'),
(198, 'FR', '17', 'Charente-Maritime'),
(199, 'FR', '18', 'Cher'),
(200, 'FR', '19', 'Corrèze'),
(201, 'FR', '2A', 'Corse-du-Sud'),
(202, 'FR', '2B', 'Haute-Corse'),
(203, 'FR', '21', 'Côte-d\'Or'),
(204, 'FR', '22', 'Côtes-d\'Armor'),
(205, 'FR', '23', 'Creuse'),
(206, 'FR', '24', 'Dordogne'),
(207, 'FR', '25', 'Doubs'),
(208, 'FR', '26', 'Drôme'),
(209, 'FR', '27', 'Eure'),
(210, 'FR', '28', 'Eure-et-Loir'),
(211, 'FR', '29', 'Finistère'),
(212, 'FR', '30', 'Gard'),
(213, 'FR', '31', 'Haute-Garonne'),
(214, 'FR', '32', 'Gers'),
(215, 'FR', '33', 'Gironde'),
(216, 'FR', '34', 'Hérault'),
(217, 'FR', '35', 'Ille-et-Vilaine'),
(218, 'FR', '36', 'Indre'),
(219, 'FR', '37', 'Indre-et-Loire'),
(220, 'FR', '38', 'Isère'),
(221, 'FR', '39', 'Jura'),
(222, 'FR', '40', 'Landes'),
(223, 'FR', '41', 'Loir-et-Cher'),
(224, 'FR', '42', 'Loire'),
(225, 'FR', '43', 'Haute-Loire'),
(226, 'FR', '44', 'Loire-Atlantique'),
(227, 'FR', '45', 'Loiret'),
(228, 'FR', '46', 'Lot'),
(229, 'FR', '47', 'Lot-et-Garonne'),
(230, 'FR', '48', 'Lozère'),
(231, 'FR', '49', 'Maine-et-Loire'),
(232, 'FR', '50', 'Manche'),
(233, 'FR', '51', 'Marne'),
(234, 'FR', '52', 'Haute-Marne'),
(235, 'FR', '53', 'Mayenne'),
(236, 'FR', '54', 'Meurthe-et-Moselle'),
(237, 'FR', '55', 'Meuse'),
(238, 'FR', '56', 'Morbihan'),
(239, 'FR', '57', 'Moselle'),
(240, 'FR', '58', 'Nièvre'),
(241, 'FR', '59', 'Nord'),
(242, 'FR', '60', 'Oise'),
(243, 'FR', '61', 'Orne'),
(244, 'FR', '62', 'Pas-de-Calais'),
(245, 'FR', '63', 'Puy-de-Dôme'),
(246, 'FR', '64', 'Pyrénées-Atlantiques'),
(247, 'FR', '65', 'Hautes-Pyrénées'),
(248, 'FR', '66', 'Pyrénées-Orientales'),
(249, 'FR', '67', 'Bas-Rhin'),
(250, 'FR', '68', 'Haut-Rhin'),
(251, 'FR', '69', 'Rhône'),
(252, 'FR', '70', 'Haute-Saône'),
(253, 'FR', '71', 'Saône-et-Loire'),
(254, 'FR', '72', 'Sarthe'),
(255, 'FR', '73', 'Savoie'),
(256, 'FR', '74', 'Haute-Savoie'),
(257, 'FR', '75', 'Paris'),
(258, 'FR', '76', 'Seine-Maritime'),
(259, 'FR', '77', 'Seine-et-Marne'),
(260, 'FR', '78', 'Yvelines'),
(261, 'FR', '79', 'Deux-Sèvres'),
(262, 'FR', '80', 'Somme'),
(263, 'FR', '81', 'Tarn'),
(264, 'FR', '82', 'Tarn-et-Garonne'),
(265, 'FR', '83', 'Var'),
(266, 'FR', '84', 'Vaucluse'),
(267, 'FR', '85', 'Vendée'),
(268, 'FR', '86', 'Vienne'),
(269, 'FR', '87', 'Haute-Vienne'),
(270, 'FR', '88', 'Vosges'),
(271, 'FR', '89', 'Yonne'),
(272, 'FR', '90', 'Territoire-de-Belfort'),
(273, 'FR', '91', 'Essonne'),
(274, 'FR', '92', 'Hauts-de-Seine'),
(275, 'FR', '93', 'Seine-Saint-Denis'),
(276, 'FR', '94', 'Val-de-Marne'),
(277, 'FR', '95', 'Val-d\'Oise');

DROP TABLE IF EXISTS `dxov_directory_country_region_name`;
CREATE TABLE `dxov_directory_country_region_name` (
  `locale` varchar(8) NOT NULL default '',
  `region_id` mediumint(8) unsigned NOT NULL default '0',
  `name` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`locale`,`region_id`),
  KEY `FK_DIRECTORY_REGION_NAME_REGION` (`region_id`),
  CONSTRAINT `FK_DIRECTORY_REGION_NAME_REGION` FOREIGN KEY (`region_id`) REFERENCES `dxov_directory_country_region` (`region_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Regions names';

INSERT INTO `dxov_directory_country_region_name` VALUES
('en_US', 1, 'Alabama'),
('en_US', 2, 'Alaska'),
('en_US', 3, 'American Samoa'),
('en_US', 4, 'Arizona'),
('en_US', 5, 'Arkansas'),
('en_US', 6, 'Armed Forces Africa'),
('en_US', 7, 'Armed Forces Americas'),
('en_US', 8, 'Armed Forces Canada'),
('en_US', 9, 'Armed Forces Europe'),
('en_US', 10, 'Armed Forces Middle East'),
('en_US', 11, 'Armed Forces Pacific'),
('en_US', 12, 'California'),
('en_US', 13, 'Colorado'),
('en_US', 14, 'Connecticut'),
('en_US', 15, 'Delaware'),
('en_US', 16, 'District of Columbia'),
('en_US', 17, 'Federated States Of Micronesia'),
('en_US', 18, 'Florida'),
('en_US', 19, 'Georgia'),
('en_US', 20, 'Guam'),
('en_US', 21, 'Hawaii'),
('en_US', 22, 'Idaho'),
('en_US', 23, 'Illinois'),
('en_US', 24, 'Indiana'),
('en_US', 25, 'Iowa'),
('en_US', 26, 'Kansas'),
('en_US', 27, 'Kentucky'),
('en_US', 28, 'Louisiana'),
('en_US', 29, 'Maine'),
('en_US', 30, 'Marshall Islands'),
('en_US', 31, 'Maryland'),
('en_US', 32, 'Massachusetts'),
('en_US', 33, 'Michigan'),
('en_US', 34, 'Minnesota'),
('en_US', 35, 'Mississippi'),
('en_US', 36, 'Missouri'),
('en_US', 37, 'Montana'),
('en_US', 38, 'Nebraska'),
('en_US', 39, 'Nevada'),
('en_US', 40, 'New Hampshire'),
('en_US', 41, 'New Jersey'),
('en_US', 42, 'New Mexico'),
('en_US', 43, 'New York'),
('en_US', 44, 'North Carolina'),
('en_US', 45, 'North Dakota'),
('en_US', 46, 'Northern Mariana Islands'),
('en_US', 47, 'Ohio'),
('en_US', 48, 'Oklahoma'),
('en_US', 49, 'Oregon'),
('en_US', 50, 'Palau'),
('en_US', 51, 'Pennsylvania'),
('en_US', 52, 'Puerto Rico'),
('en_US', 53, 'Rhode Island'),
('en_US', 54, 'South Carolina'),
('en_US', 55, 'South Dakota'),
('en_US', 56, 'Tennessee'),
('en_US', 57, 'Texas'),
('en_US', 58, 'Utah'),
('en_US', 59, 'Vermont'),
('en_US', 60, 'Virgin Islands'),
('en_US', 61, 'Virginia'),
('en_US', 62, 'Washington'),
('en_US', 63, 'West Virginia'),
('en_US', 64, 'Wisconsin'),
('en_US', 65, 'Wyoming'),
('en_US', 66, 'Alberta'),
('en_US', 67, 'British Columbia'),
('en_US', 68, 'Manitoba'),
('en_US', 69, 'Newfoundland'),
('en_US', 70, 'New Brunswick'),
('en_US', 71, 'Nova Scotia'),
('en_US', 72, 'Northwest Territories'),
('en_US', 73, 'Nunavut'),
('en_US', 74, 'Ontario'),
('en_US', 75, 'Prince Edward Island'),
('en_US', 76, 'Quebec'),
('en_US', 77, 'Saskatchewan'),
('en_US', 78, 'Yukon Territory'),
('en_US', 79, 'Niedersachsen'),
('en_US', 80, 'Baden-Württemberg'),
('en_US', 81, 'Bayern'),
('en_US', 82, 'Berlin'),
('en_US', 83, 'Brandenburg'),
('en_US', 84, 'Bremen'),
('en_US', 85, 'Hamburg'),
('en_US', 86, 'Hessen'),
('en_US', 87, 'Mecklenburg-Vorpommern'),
('en_US', 88, 'Nordrhein-Westfalen'),
('en_US', 89, 'Rheinland-Pfalz'),
('en_US', 90, 'Saarland'),
('en_US', 91, 'Sachsen'),
('en_US', 92, 'Sachsen-Anhalt'),
('en_US', 93, 'Schleswig-Holstein'),
('en_US', 94, 'Thüringen'),
('en_US', 95, 'Wien'),
('en_US', 96, 'Niederösterreich'),
('en_US', 97, 'Oberösterreich'),
('en_US', 98, 'Salzburg'),
('en_US', 99, 'Kärnten'),
('en_US', 100, 'Steiermark'),
('en_US', 101, 'Tirol'),
('en_US', 102, 'Burgenland'),
('en_US', 103, 'Voralberg'),
('en_US', 104, 'Aargau'),
('en_US', 105, 'Appenzell Innerrhoden'),
('en_US', 106, 'Appenzell Ausserrhoden'),
('en_US', 107, 'Bern'),
('en_US', 108, 'Basel-Landschaft'),
('en_US', 109, 'Basel-Stadt'),
('en_US', 110, 'Freiburg'),
('en_US', 111, 'Genf'),
('en_US', 112, 'Glarus'),
('en_US', 113, 'Graubünden'),
('en_US', 114, 'Jura'),
('en_US', 115, 'Luzern'),
('en_US', 116, 'Neuenburg'),
('en_US', 117, 'Nidwalden'),
('en_US', 118, 'Obwalden'),
('en_US', 119, 'St. Gallen'),
('en_US', 120, 'Schaffhausen'),
('en_US', 121, 'Solothurn'),
('en_US', 122, 'Schwyz'),
('en_US', 123, 'Thurgau'),
('en_US', 124, 'Tessin'),
('en_US', 125, 'Uri'),
('en_US', 126, 'Waadt'),
('en_US', 127, 'Wallis'),
('en_US', 128, 'Zug'),
('en_US', 129, 'Zürich'),
('en_US', 130, 'A Coruña'),
('en_US', 131, 'Alava'),
('en_US', 132, 'Albacete'),
('en_US', 133, 'Alicante'),
('en_US', 134, 'Almeria'),
('en_US', 135, 'Asturias'),
('en_US', 136, 'Avila'),
('en_US', 137, 'Badajoz'),
('en_US', 138, 'Baleares'),
('en_US', 139, 'Barcelona'),
('en_US', 140, 'Burgos'),
('en_US', 141, 'Caceres'),
('en_US', 142, 'Cadiz'),
('en_US', 143, 'Cantabria'),
('en_US', 144, 'Castellon'),
('en_US', 145, 'Ceuta'),
('en_US', 146, 'Ciudad Real'),
('en_US', 147, 'Cordoba'),
('en_US', 148, 'Cuenca'),
('en_US', 149, 'Girona'),
('en_US', 150, 'Granada'),
('en_US', 151, 'Guadalajara'),
('en_US', 152, 'Guipuzcoa'),
('en_US', 153, 'Huelva'),
('en_US', 154, 'Huesca'),
('en_US', 155, 'Jaen'),
('en_US', 156, 'La Rioja'),
('en_US', 157, 'Las Palmas'),
('en_US', 158, 'Leon'),
('en_US', 159, 'Lleida'),
('en_US', 160, 'Lugo'),
('en_US', 161, 'Madrid'),
('en_US', 162, 'Malaga'),
('en_US', 163, 'Melilla'),
('en_US', 164, 'Murcia'),
('en_US', 165, 'Navarra'),
('en_US', 166, 'Ourense'),
('en_US', 167, 'Palencia'),
('en_US', 168, 'Pontevedra'),
('en_US', 169, 'Salamanca'),
('en_US', 170, 'Santa Cruz de Tenerife'),
('en_US', 171, 'Segovia'),
('en_US', 172, 'Sevilla'),
('en_US', 173, 'Soria'),
('en_US', 174, 'Tarragona'),
('en_US', 175, 'Teruel'),
('en_US', 176, 'Toledo'),
('en_US', 177, 'Valencia'),
('en_US', 178, 'Valladolid'),
('en_US', 179, 'Vizcaya'),
('en_US', 180, 'Zamora'),
('en_US', 181, 'Zaragoza'),
('en_US', 182, 'Ain'),
('en_US', 183, 'Aisne'),
('en_US', 184, 'Allier'),
('en_US', 185, 'Alpes-de-Haute-Provence'),
('en_US', 186, 'Hautes-Alpes'),
('en_US', 187, 'Alpes-Maritimes'),
('en_US', 188, 'Ardèche'),
('en_US', 189, 'Ardennes'),
('en_US', 190, 'Ariège'),
('en_US', 191, 'Aube'),
('en_US', 192, 'Aude'),
('en_US', 193, 'Aveyron'),
('en_US', 194, 'Bouches-du-Rhône'),
('en_US', 195, 'Calvados'),
('en_US', 196, 'Cantal'),
('en_US', 197, 'Charente'),
('en_US', 198, 'Charente-Maritime'),
('en_US', 199, 'Cher'),
('en_US', 200, 'Corrèze'),
('en_US', 201, 'Corse-du-Sud'),
('en_US', 202, 'Haute-Corse'),
('en_US', 203, 'Côte-d\'Or'),
('en_US', 204, 'Côtes-d\'Armor'),
('en_US', 205, 'Creuse'),
('en_US', 206, 'Dordogne'),
('en_US', 207, 'Doubs'),
('en_US', 208, 'Drôme'),
('en_US', 209, 'Eure'),
('en_US', 210, 'Eure-et-Loir'),
('en_US', 211, 'Finistère'),
('en_US', 212, 'Gard'),
('en_US', 213, 'Haute-Garonne'),
('en_US', 214, 'Gers'),
('en_US', 215, 'Gironde'),
('en_US', 216, 'Hérault'),
('en_US', 217, 'Ille-et-Vilaine'),
('en_US', 218, 'Indre'),
('en_US', 219, 'Indre-et-Loire'),
('en_US', 220, 'Isère'),
('en_US', 221, 'Jura'),
('en_US', 222, 'Landes'),
('en_US', 223, 'Loir-et-Cher'),
('en_US', 224, 'Loire'),
('en_US', 225, 'Haute-Loire'),
('en_US', 226, 'Loire-Atlantique'),
('en_US', 227, 'Loiret'),
('en_US', 228, 'Lot'),
('en_US', 229, 'Lot-et-Garonne'),
('en_US', 230, 'Lozère'),
('en_US', 231, 'Maine-et-Loire'),
('en_US', 232, 'Manche'),
('en_US', 233, 'Marne'),
('en_US', 234, 'Haute-Marne'),
('en_US', 235, 'Mayenne'),
('en_US', 236, 'Meurthe-et-Moselle'),
('en_US', 237, 'Meuse'),
('en_US', 238, 'Morbihan'),
('en_US', 239, 'Moselle'),
('en_US', 240, 'Nièvre'),
('en_US', 241, 'Nord'),
('en_US', 242, 'Oise'),
('en_US', 243, 'Orne'),
('en_US', 244, 'Pas-de-Calais'),
('en_US', 245, 'Puy-de-Dôme'),
('en_US', 246, 'Pyrénées-Atlantiques'),
('en_US', 247, 'Hautes-Pyrénées'),
('en_US', 248, 'Pyrénées-Orientales'),
('en_US', 249, 'Bas-Rhin'),
('en_US', 250, 'Haut-Rhin'),
('en_US', 251, 'Rhône'),
('en_US', 252, 'Haute-Saône'),
('en_US', 253, 'Saône-et-Loire'),
('en_US', 254, 'Sarthe'),
('en_US', 255, 'Savoie'),
('en_US', 256, 'Haute-Savoie'),
('en_US', 257, 'Paris'),
('en_US', 258, 'Seine-Maritime'),
('en_US', 259, 'Seine-et-Marne'),
('en_US', 260, 'Yvelines'),
('en_US', 261, 'Deux-Sèvres'),
('en_US', 262, 'Somme'),
('en_US', 263, 'Tarn'),
('en_US', 264, 'Tarn-et-Garonne'),
('en_US', 265, 'Var'),
('en_US', 266, 'Vaucluse'),
('en_US', 267, 'Vendée'),
('en_US', 268, 'Vienne'),
('en_US', 269, 'Haute-Vienne'),
('en_US', 270, 'Vosges'),
('en_US', 271, 'Yonne'),
('en_US', 272, 'Territoire-de-Belfort'),
('en_US', 273, 'Essonne'),
('en_US', 274, 'Hauts-de-Seine'),
('en_US', 275, 'Seine-Saint-Denis'),
('en_US', 276, 'Val-de-Marne'),
('en_US', 277, 'Val-d\'Oise');

DROP TABLE IF EXISTS `dxov_directory_currency_rate`;
CREATE TABLE `dxov_directory_currency_rate` (
  `currency_from` char(3) NOT NULL default '',
  `currency_to` char(3) NOT NULL default '',
  `rate` decimal(24,12) NOT NULL default '0.000000000000',
  PRIMARY KEY  (`currency_from`,`currency_to`),
  KEY `FK_CURRENCY_RATE_TO` (`currency_to`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_directory_currency_rate` VALUES
('EUR', 'EUR', '1.000000000000'),
('EUR', 'USD', '1.415000000000'),
('USD', 'EUR', '0.706700000000'),
('USD', 'USD', '1.000000000000');

DROP TABLE IF EXISTS `dxov_downloadable_link`;
CREATE TABLE `dxov_downloadable_link` (
  `link_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `sort_order` int(10) unsigned NOT NULL default '0',
  `number_of_downloads` int(10) unsigned default NULL,
  `is_shareable` smallint(1) unsigned NOT NULL default '0',
  `link_url` varchar(255) NOT NULL default '',
  `link_file` varchar(255) NOT NULL default '',
  `link_type` varchar(20) NOT NULL default '',
  `sample_url` varchar(255) NOT NULL default '',
  `sample_file` varchar(255) NOT NULL default '',
  `sample_type` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`link_id`),
  KEY `DOWNLODABLE_LINK_PRODUCT` (`product_id`),
  KEY `DOWNLODABLE_LINK_PRODUCT_SORT_ORDER` (`product_id`,`sort_order`),
  CONSTRAINT `FK_DOWNLODABLE_LINK_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_downloadable_link_price`;
CREATE TABLE `dxov_downloadable_link_price` (
  `price_id` int(10) unsigned NOT NULL auto_increment,
  `link_id` int(10) unsigned NOT NULL default '0',
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `price` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`price_id`),
  KEY `DOWNLOADABLE_LINK_PRICE_LINK` (`link_id`),
  KEY `DOWNLOADABLE_LINK_PRICE_WEBSITE` (`website_id`),
  CONSTRAINT `FK_DOWNLOADABLE_LINK_PRICE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_DOWNLOADABLE_LINK_PRICE_LINK` FOREIGN KEY (`link_id`) REFERENCES `dxov_downloadable_link` (`link_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_downloadable_link_purchased`;
CREATE TABLE `dxov_downloadable_link_purchased` (
  `purchased_id` int(10) unsigned NOT NULL auto_increment,
  `order_id` int(10) unsigned NOT NULL default '0',
  `order_increment_id` varchar(50) NOT NULL default '',
  `order_item_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `customer_id` int(10) unsigned NOT NULL default '0',
  `product_name` varchar(255) NOT NULL default '',
  `product_sku` varchar(255) NOT NULL default '',
  `link_section_title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`purchased_id`),
  KEY `DOWNLOADABLE_ORDER_ID` (`order_id`),
  KEY `DOWNLOADABLE_CUSTOMER_ID` (`customer_id`),
  KEY `KEY_DOWNLOADABLE_ORDER_ITEM_ID` (`order_item_id`),
  CONSTRAINT `FK_DOWNLOADABLE_PURCHASED_ORDER_ITEM_ID` FOREIGN KEY (`order_item_id`) REFERENCES `dxov_sales_flat_order_item` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_DOWNLOADABLE_ORDER_ID` FOREIGN KEY (`order_id`) REFERENCES `dxov_sales_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_downloadable_link_purchased_item`;
CREATE TABLE `dxov_downloadable_link_purchased_item` (
  `item_id` int(10) unsigned NOT NULL auto_increment,
  `purchased_id` int(10) unsigned NOT NULL default '0',
  `order_item_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned default '0',
  `link_hash` varchar(255) NOT NULL default '',
  `number_of_downloads_bought` int(10) unsigned NOT NULL default '0',
  `number_of_downloads_used` int(10) unsigned NOT NULL default '0',
  `link_id` int(20) unsigned NOT NULL default '0',
  `link_title` varchar(255) NOT NULL default '',
  `is_shareable` smallint(1) unsigned NOT NULL default '0',
  `link_url` varchar(255) NOT NULL default '',
  `link_file` varchar(255) NOT NULL default '',
  `link_type` varchar(255) NOT NULL default '',
  `status` varchar(50) NOT NULL default '',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`item_id`),
  KEY `DOWNLOADABLE_LINK_PURCHASED_ID` (`purchased_id`),
  KEY `DOWNLOADABLE_ORDER_ITEM_ID` (`order_item_id`),
  KEY `DOWNLOADALBE_LINK_HASH` (`link_hash`),
  CONSTRAINT `FK_DOWNLOADABLE_LINK_PURCHASED_ID` FOREIGN KEY (`purchased_id`) REFERENCES `dxov_downloadable_link_purchased` (`purchased_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_DOWNLOADABLE_ORDER_ITEM_ID` FOREIGN KEY (`order_item_id`) REFERENCES `dxov_sales_flat_order_item` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_downloadable_link_title`;
CREATE TABLE `dxov_downloadable_link_title` (
  `title_id` int(10) unsigned NOT NULL auto_increment,
  `link_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`title_id`),
  KEY `DOWNLOADABLE_LINK_TITLE_LINK` (`link_id`),
  KEY `DOWNLOADABLE_LINK_TITLE_STORE` (`store_id`),
  CONSTRAINT `FK_DOWNLOADABLE_LINK_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_DOWNLOADABLE_LINK_TITLE_LINK` FOREIGN KEY (`link_id`) REFERENCES `dxov_downloadable_link` (`link_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_downloadable_sample`;
CREATE TABLE `dxov_downloadable_sample` (
  `sample_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `sample_url` varchar(255) NOT NULL default '',
  `sample_file` varchar(255) NOT NULL default '',
  `sample_type` varchar(20) NOT NULL default '',
  `sort_order` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`sample_id`),
  KEY `DOWNLODABLE_SAMPLE_PRODUCT` (`product_id`),
  CONSTRAINT `FK_DOWNLODABLE_SAMPLE_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_downloadable_sample_title`;
CREATE TABLE `dxov_downloadable_sample_title` (
  `title_id` int(10) unsigned NOT NULL auto_increment,
  `sample_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`title_id`),
  KEY `DOWNLOADABLE_SAMPLE_TITLE_SAMPLE` (`sample_id`),
  KEY `DOWNLOADABLE_SAMPLE_TITLE_STORE` (`store_id`),
  CONSTRAINT `FK_DOWNLOADABLE_SAMPLE_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_DOWNLOADABLE_SAMPLE_TITLE_SAMPLE` FOREIGN KEY (`sample_id`) REFERENCES `dxov_downloadable_sample` (`sample_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_eav_attribute`;
CREATE TABLE `dxov_eav_attribute` (
  `attribute_id` smallint(5) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_code` varchar(255) NOT NULL default '',
  `attribute_model` varchar(255) default NULL,
  `backend_model` varchar(255) default NULL,
  `backend_type` enum('static','datetime','decimal','int','text','varchar') NOT NULL default 'static',
  `backend_table` varchar(255) default NULL,
  `frontend_model` varchar(255) default NULL,
  `frontend_input` varchar(50) default NULL,
  `frontend_input_renderer` varchar(255) default NULL,
  `frontend_label` varchar(255) default NULL,
  `frontend_class` varchar(255) default NULL,
  `source_model` varchar(255) default NULL,
  `is_global` tinyint(1) unsigned NOT NULL default '1',
  `is_visible` tinyint(1) unsigned NOT NULL default '1',
  `is_required` tinyint(1) unsigned NOT NULL default '0',
  `is_user_defined` tinyint(1) unsigned NOT NULL default '0',
  `default_value` text,
  `is_searchable` tinyint(1) unsigned NOT NULL default '0',
  `is_filterable` tinyint(1) unsigned NOT NULL default '0',
  `is_comparable` tinyint(1) unsigned NOT NULL default '0',
  `is_visible_on_front` tinyint(1) unsigned NOT NULL default '0',
  `is_html_allowed_on_front` tinyint(1) unsigned NOT NULL default '0',
  `is_unique` tinyint(1) unsigned NOT NULL default '0',
  `is_used_for_price_rules` tinyint(1) unsigned NOT NULL default '0',
  `is_filterable_in_search` tinyint(1) unsigned NOT NULL default '0',
  `used_in_product_listing` tinyint(1) unsigned NOT NULL default '0',
  `used_for_sort_by` tinyint(1) unsigned NOT NULL default '0',
  `is_configurable` tinyint(1) unsigned NOT NULL default '1',
  `apply_to` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `note` varchar(255) NOT NULL,
  `is_visible_in_advanced_search` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`attribute_id`),
  UNIQUE KEY `entity_type_id` (`entity_type_id`,`attribute_code`),
  KEY `IDX_USED_FOR_SORT_BY` (`entity_type_id`,`used_for_sort_by`),
  KEY `IDX_USED_IN_PRODUCT_LISTING` (`entity_type_id`,`used_in_product_listing`),
  CONSTRAINT `FK_eav_attribute` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=530 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_eav_attribute` VALUES
(1, 1, 'website_id', NULL, 'customer/customer_attribute_backend_website', 'static', '', '', 'select', '', 'Associate to Website', NULL, 'customer/customer_attribute_source_website', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(2, 1, 'store_id', NULL, 'customer/customer_attribute_backend_store', 'static', '', '', 'select', '', 'Create In', NULL, 'customer/customer_attribute_source_store', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(3, 1, 'created_in', NULL, '', 'varchar', '', '', 'text', '', 'Created From', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(4, 1, 'prefix', NULL, '', 'varchar', '', '', 'text', '', 'Prefix', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(5, 1, 'firstname', NULL, '', 'varchar', '', '', 'text', '', 'First Name', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(6, 1, 'middlename', NULL, '', 'varchar', '', '', 'text', '', 'Middle Name/Initial', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(7, 1, 'lastname', NULL, '', 'varchar', '', '', 'text', '', 'Last Name', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(8, 1, 'suffix', NULL, '', 'varchar', '', '', 'text', '', 'Suffix', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(9, 1, 'email', NULL, '', 'static', '', '', 'text', '', 'Email', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(10, 1, 'group_id', NULL, '', 'static', '', '', 'select', '', 'Customer Group', NULL, 'customer/customer_attribute_source_group', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(11, 1, 'dob', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', '', 'Date Of Birth', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(12, 1, 'password_hash', NULL, 'customer/customer_attribute_backend_password', 'varchar', '', '', 'hidden', '', '', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(13, 1, 'default_billing', NULL, 'customer/customer_attribute_backend_billing', 'int', '', '', 'text', '', '', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(14, 1, 'default_shipping', NULL, 'customer/customer_attribute_backend_shipping', 'int', '', '', 'text', '', '', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(15, 1, 'taxvat', NULL, '', 'varchar', '', '', 'text', '', 'Tax/VAT number', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(16, 1, 'confirmation', NULL, '', 'varchar', '', '', 'text', '', 'Is confirmed', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(17, 2, 'prefix', NULL, '', 'varchar', '', '', 'text', '', 'Prefix', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(18, 2, 'firstname', NULL, '', 'varchar', '', '', 'text', '', 'First Name', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(19, 2, 'middlename', NULL, '', 'varchar', '', '', 'text', '', 'Middle Name/Initial', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(20, 2, 'lastname', NULL, '', 'varchar', '', '', 'text', '', 'Last Name', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(21, 2, 'suffix', NULL, '', 'varchar', '', '', 'text', '', 'Suffix', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(22, 2, 'company', NULL, '', 'varchar', '', '', 'text', '', 'Company', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(23, 2, 'street', NULL, 'customer_entity/address_attribute_backend_street', 'text', '', '', 'multiline', '', 'Street Address', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(24, 2, 'city', NULL, '', 'varchar', '', '', 'text', '', 'City', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(25, 2, 'country_id', NULL, '', 'varchar', '', '', 'select', '', 'Country', NULL, 'customer_entity/address_attribute_source_country', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(26, 2, 'region', NULL, 'customer_entity/address_attribute_backend_region', 'varchar', '', '', 'text', '', 'State/Province', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(27, 2, 'region_id', NULL, '', 'int', '', '', 'hidden', '', '', NULL, 'customer_entity/address_attribute_source_region', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(28, 2, 'postcode', NULL, '', 'varchar', '', '', 'text', '', 'Zip/Postal Code', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(29, 2, 'telephone', NULL, '', 'varchar', '', '', 'text', '', 'Telephone', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(30, 2, 'fax', NULL, '', 'varchar', '', '', 'text', '', 'Fax', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(31, 3, 'name', NULL, '', 'varchar', '', '', 'text', '', 'Name', NULL, '', 0, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(32, 3, 'is_active', NULL, '', 'int', '', '', 'select', '', 'Is Active', NULL, 'eav/entity_attribute_source_boolean', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(33, 3, 'url_key', NULL, 'catalog/category_attribute_backend_urlkey', 'varchar', '', '', 'text', '', 'URL key', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(34, 3, 'description', NULL, '', 'text', '', '', 'textarea', '', 'Description', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(35, 3, 'image', NULL, 'catalog/category_attribute_backend_image', 'varchar', '', '', 'image', '', 'Image', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(36, 3, 'meta_title', NULL, '', 'varchar', '', '', 'text', '', 'Page Title', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(37, 3, 'meta_keywords', NULL, '', 'text', '', '', 'textarea', '', 'Meta Keywords', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(38, 3, 'meta_description', NULL, '', 'text', '', '', 'textarea', '', 'Meta Description', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(39, 3, 'display_mode', NULL, '', 'varchar', '', '', 'select', '', 'Display Mode', NULL, 'catalog/category_attribute_source_mode', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(40, 3, 'landing_page', NULL, '', 'int', '', '', 'select', '', 'CMS Block', NULL, 'catalog/category_attribute_source_page', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(41, 3, 'is_anchor', NULL, '', 'int', '', '', 'select', '', 'Is Anchor', NULL, 'eav/entity_attribute_source_boolean', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(42, 3, 'path', NULL, '', 'static', '', '', '', '', 'Path', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(43, 3, 'position', NULL, '', 'static', '', '', '', '', 'Position', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(44, 3, 'all_children', NULL, '', 'text', '', '', '', '', '', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(45, 3, 'path_in_store', NULL, '', 'text', '', '', '', '', '', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(46, 3, 'children', NULL, '', 'text', '', '', '', '', '', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(47, 3, 'url_path', NULL, '', 'varchar', '', '', '', '', '', NULL, '', 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, '', 1, '', 0),
(48, 3, 'custom_design', NULL, '', 'varchar', '', '', 'select', '', 'Custom Design', NULL, 'core/design_source_design', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(49, 3, 'custom_design_apply', NULL, '', 'int', '', '', 'select', '', 'Apply To', NULL, 'core/design_source_apply', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(50, 3, 'custom_design_from', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', '', 'Active From', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(51, 3, 'custom_design_to', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', '', 'Active To', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(52, 3, 'page_layout', NULL, '', 'varchar', '', '', 'select', '', 'Page Layout', NULL, 'catalog/category_attribute_source_layout', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(53, 3, 'custom_layout_update', NULL, '', 'text', '', '', 'textarea', '', 'Custom Layout Update', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(54, 3, 'level', NULL, '', 'static', '', '', '', '', 'Level', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(55, 3, 'children_count', NULL, '', 'static', '', '', '', '', 'Children Count', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(56, 4, 'name', NULL, '', 'varchar', '', '', 'text', '', 'Name', NULL, '', 0, 1, 1, 0, '', 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, '', 1, '', 1),
(57, 4, 'description', NULL, '', 'text', '', '', 'textarea', '', 'Description', NULL, '', 0, 1, 1, 0, '', 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 1),
(58, 4, 'short_description', NULL, '', 'text', '', '', 'textarea', '', 'Short Description', NULL, '', 0, 1, 1, 0, '', 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, '', 1, '', 1),
(59, 4, 'sku', NULL, '', 'static', '', '', 'text', '', 'SKU', NULL, '', 1, 1, 1, 0, '', 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, '', 1, '', 1),
(60, 4, 'price', NULL, 'catalog/product_attribute_backend_price', 'decimal', '', '', 'price', '', 'Price', NULL, '', 2, 1, 1, 0, '', 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 'simple,configurable,virtual,bundle,downloadable', 0, '', 1),
(61, 4, 'special_price', NULL, 'catalog/product_attribute_backend_price', 'decimal', '', '', 'price', '', 'Special Price', NULL, '', 2, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 1, '', 0),
(62, 4, 'special_from_date', NULL, 'catalog/product_attribute_backend_startdate', 'datetime', '', '', 'date', '', 'Special Price From Date', NULL, '', 2, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 1, '', 0),
(63, 4, 'special_to_date', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', '', 'Special Price To Date', NULL, '', 2, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 1, '', 0),
(64, 4, 'cost', NULL, 'catalog/product_attribute_backend_price', 'decimal', '', '', 'price', '', 'Cost', NULL, '', 2, 1, 0, 1, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 1, '', 0),
(65, 4, 'weight', NULL, '', 'decimal', '', '', 'text', '', 'Weight', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 'simple,bundle', 1, '', 0),
(66, 4, 'manufacturer', NULL, '', 'int', '', '', 'select', '', 'Manufacturer', NULL, '', 1, 1, 0, 1, '', 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 'simple', 1, '', 1),
(67, 4, 'meta_title', NULL, '', 'varchar', '', '', 'text', '', 'Meta Title', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(68, 4, 'meta_keyword', NULL, '', 'text', '', '', 'textarea', '', 'Meta Keywords', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(69, 4, 'meta_description', NULL, '', 'varchar', '', '', 'textarea', '', 'Meta Description', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, 'Maximum 255 chars', 0),
(70, 4, 'image', NULL, '', 'varchar', '', 'catalog/product_attribute_frontend_image', 'media_image', '', 'Base Image', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(71, 4, 'small_image', NULL, '', 'varchar', '', 'catalog/product_attribute_frontend_image', 'media_image', '', 'Small Image', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, '', 1, '', 0),
(72, 4, 'thumbnail', NULL, '', 'varchar', '', 'catalog/product_attribute_frontend_image', 'media_image', '', 'Thumbnail', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, '', 1, '', 0),
(73, 4, 'media_gallery', NULL, 'catalog/product_attribute_backend_media', 'varchar', '', '', 'gallery', '', 'Media Gallery', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(74, 4, 'old_id', NULL, '', 'int', '', '', '', '', '', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(75, 4, 'tier_price', NULL, 'catalog/product_attribute_backend_tierprice', 'decimal', '', '', 'text', '', 'Tier Price', NULL, '', 2, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 1, '', 0),
(76, 4, 'color', NULL, '', 'int', '', '', 'select', '', 'Color', NULL, '', 1, 1, 0, 1, '', 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 'simple', 1, '', 1),
(77, 4, 'news_from_date', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', '', 'Set Product as New from Date', NULL, '', 2, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, '', 1, '', 0),
(78, 4, 'news_to_date', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', '', 'Set Product as New to Date', NULL, '', 2, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, '', 1, '', 0),
(79, 4, 'gallery', NULL, '', 'varchar', '', '', 'gallery', '', 'Image Gallery', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(80, 4, 'status', NULL, '', 'int', '', '', 'select', '', 'Status', NULL, 'catalog/product_status', 2, 1, 1, 0, '', 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, '', 1, '', 0),
(81, 4, 'tax_class_id', NULL, '', 'int', '', '', 'select', '', 'Tax Class', NULL, 'tax/class_source_product', 2, 1, 1, 0, '', 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 1, '', 1),
(82, 4, 'url_key', NULL, 'catalog/product_attribute_backend_urlkey', 'varchar', '', '', 'text', '', 'URL key', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, '', 1, '', 0),
(83, 4, 'url_path', NULL, '', 'varchar', '', '', '', '', '', NULL, '', 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, '', 1, '', 0),
(84, 4, 'minimal_price', NULL, '', 'decimal', '', '', 'price', '', 'Minimal Price', NULL, '', 0, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 1, '', 0),
(85, 4, 'visibility', NULL, '', 'int', '', '', 'select', '', 'Visibility', NULL, 'catalog/product_visibility', 0, 1, 1, 0, '4', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(86, 4, 'custom_design', NULL, '', 'varchar', '', '', 'select', '', 'Custom Design', NULL, 'core/design_source_design', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(87, 4, 'custom_design_from', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', '', 'Active From', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(88, 4, 'custom_design_to', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', '', 'Active To', NULL, '', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(89, 4, 'custom_layout_update', NULL, '', 'text', '', '', 'textarea', '', 'Custom Layout Update', NULL, '', 1, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(90, 4, 'page_layout', NULL, '', 'varchar', '', '', 'select', '', 'Page Layout', NULL, 'catalog/product_attribute_source_layout', 0, 1, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(91, 4, 'category_ids', NULL, '', 'static', '', '', '', '', '', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 1, '', 0),
(92, 4, 'options_container', NULL, '', 'varchar', '', '', 'select', '', 'Display product options in', NULL, 'catalog/entity_product_attribute_design_options_container', 0, 1, 0, 0, 'container2', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(93, 4, 'required_options', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, '', 0, '', 0),
(94, 4, 'has_options', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(95, 4, 'image_label', NULL, '', 'varchar', '', '', 'text', '', 'Image Label', NULL, '', 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, '', 0, '', 0),
(96, 4, 'small_image_label', NULL, '', 'varchar', '', '', 'text', '', 'Small Image Label', NULL, '', 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, '', 0, '', 0),
(97, 4, 'thumbnail_label', NULL, '', 'varchar', '', '', 'text', '', 'Thumbnail Label', NULL, '', 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, '', 0, '', 0),
(98, 3, 'available_sort_by', NULL, 'catalog/category_attribute_backend_sortby', 'text', '', '', 'multiselect', 'adminhtml/catalog_category_helper_sortby_available', 'Available Product Listing Sort by', NULL, 'catalog/category_attribute_source_sortby', 0, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(99, 3, 'default_sort_by', NULL, 'catalog/category_attribute_backend_sortby', 'varchar', '', '', 'select', 'adminhtml/catalog_category_helper_sortby_default', 'Default Product Listing Sort by', NULL, 'catalog/category_attribute_source_sortby', 0, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(100, 11, 'entity_id', NULL, 'sales_entity/order_attribute_backend_parent', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(101, 11, 'store_id', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(102, 11, 'store_name', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(103, 11, 'remote_ip', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(104, 11, 'status', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(105, 11, 'state', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(106, 11, 'hold_before_status', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(107, 11, 'hold_before_state', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(108, 11, 'relation_parent_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(109, 11, 'relation_parent_real_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(110, 11, 'relation_child_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(111, 11, 'relation_child_real_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(112, 11, 'original_increment_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(113, 11, 'edit_increment', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(114, 11, 'ext_order_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(115, 11, 'ext_customer_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(116, 11, 'quote_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(117, 11, 'quote_address_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(118, 11, 'billing_address_id', NULL, 'sales_entity/order_attribute_backend_billing', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(119, 11, 'shipping_address_id', NULL, 'sales_entity/order_attribute_backend_shipping', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(120, 11, 'coupon_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(121, 11, 'applied_rule_ids', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(122, 11, 'giftcert_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(123, 11, 'global_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(124, 11, 'base_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(125, 11, 'store_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(126, 11, 'order_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(127, 11, 'store_to_base_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(128, 11, 'store_to_order_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(129, 11, 'base_to_global_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(130, 11, 'base_to_order_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(131, 11, 'is_virtual', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(132, 11, 'is_multi_payment', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(133, 11, 'shipping_method', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(134, 11, 'shipping_description', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(135, 11, 'weight', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(136, 11, 'tax_amount', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(137, 11, 'shipping_amount', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(138, 11, 'shipping_tax_amount', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(139, 11, 'discount_amount', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(140, 11, 'giftcert_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(141, 11, 'custbalance_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(142, 11, 'subtotal', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(143, 11, 'grand_total', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(144, 11, 'total_paid', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(145, 11, 'total_due', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(146, 11, 'total_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(147, 11, 'total_qty_ordered', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(148, 11, 'total_canceled', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(149, 11, 'total_invoiced', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(150, 11, 'total_online_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(151, 11, 'total_offline_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(152, 11, 'adjustment_positive', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(153, 11, 'adjustment_negative', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(154, 11, 'base_tax_amount', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(155, 11, 'base_shipping_amount', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(156, 11, 'base_shipping_tax_amount', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(157, 11, 'base_discount_amount', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(158, 11, 'base_giftcert_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(159, 11, 'base_custbalance_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(160, 11, 'base_subtotal', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(161, 11, 'base_grand_total', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(162, 11, 'base_total_paid', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(163, 11, 'base_total_due', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(164, 11, 'base_total_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(165, 11, 'base_total_qty_ordered', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(166, 11, 'base_total_canceled', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(167, 11, 'base_total_invoiced', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(168, 11, 'base_total_online_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(169, 11, 'base_total_offline_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(170, 11, 'base_adjustment_positive', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(171, 11, 'base_adjustment_negative', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(172, 11, 'subtotal_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(173, 11, 'subtotal_canceled', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(174, 11, 'discount_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(175, 11, 'discount_canceled', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(176, 11, 'discount_invoiced', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(177, 11, 'subtotal_invoiced', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(178, 11, 'tax_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(179, 11, 'tax_canceled', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(180, 11, 'tax_invoiced', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(181, 11, 'shipping_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(182, 11, 'shipping_canceled', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(183, 11, 'shipping_invoiced', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(184, 11, 'base_subtotal_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(185, 11, 'base_subtotal_canceled', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(186, 11, 'base_discount_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(187, 11, 'base_discount_canceled', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(188, 11, 'base_discount_invoiced', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(189, 11, 'base_subtotal_invoiced', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(190, 11, 'base_tax_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(191, 11, 'base_tax_canceled', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(192, 11, 'base_tax_invoiced', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(193, 11, 'base_shipping_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(194, 11, 'base_shipping_canceled', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(195, 11, 'base_shipping_invoiced', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(196, 11, 'customer_id', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(197, 11, 'customer_group_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(198, 11, 'customer_email', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(199, 11, 'customer_prefix', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(200, 11, 'customer_firstname', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(201, 11, 'customer_middlename', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(202, 11, 'customer_lastname', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(203, 11, 'customer_suffix', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(204, 11, 'customer_note', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(205, 11, 'customer_note_notify', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(206, 11, 'customer_is_guest', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(207, 11, 'email_sent', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(208, 11, 'customer_taxvat', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(209, 11, 'customer_dob', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(210, 12, 'parent_id', NULL, 'sales_entity/order_attribute_backend_child', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(211, 12, 'quote_address_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(212, 12, 'address_type', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(213, 12, 'customer_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(214, 12, 'customer_address_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(215, 12, 'email', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(216, 12, 'prefix', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(217, 12, 'firstname', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(218, 12, 'middlename', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(219, 12, 'lastname', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(220, 12, 'suffix', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(221, 12, 'company', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(222, 12, 'street', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(223, 12, 'city', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(224, 12, 'region', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(225, 12, 'region_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(226, 12, 'postcode', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(227, 12, 'country_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(228, 12, 'telephone', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(229, 12, 'fax', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(230, 13, 'parent_id', NULL, 'sales_entity/order_attribute_backend_child', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(231, 13, 'quote_item_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(232, 13, 'product_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(233, 13, 'super_product_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(234, 13, 'parent_product_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(235, 13, 'is_virtual', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(236, 13, 'sku', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(237, 13, 'name', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(238, 13, 'description', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(239, 13, 'weight', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(240, 13, 'is_qty_decimal', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(241, 13, 'qty_ordered', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(242, 13, 'qty_backordered', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(243, 13, 'qty_invoiced', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(244, 13, 'qty_canceled', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(245, 13, 'qty_shipped', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(246, 13, 'qty_refunded', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(247, 13, 'original_price', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(248, 13, 'price', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(249, 13, 'cost', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(250, 13, 'discount_percent', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(251, 13, 'discount_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(252, 13, 'discount_invoiced', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(253, 13, 'tax_percent', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(254, 13, 'tax_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(255, 13, 'tax_invoiced', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(256, 13, 'row_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(257, 13, 'row_weight', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(258, 13, 'row_invoiced', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(259, 13, 'invoiced_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(260, 13, 'amount_refunded', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(261, 13, 'base_price', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(262, 13, 'base_original_price', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(263, 13, 'base_discount_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(264, 13, 'base_discount_invoiced', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(265, 13, 'base_tax_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(266, 13, 'base_tax_invoiced', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(267, 13, 'base_row_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(268, 13, 'base_row_invoiced', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(269, 13, 'base_invoiced_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(270, 13, 'base_amount_refunded', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(271, 13, 'applied_rule_ids', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(272, 13, 'additional_data', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(273, 14, 'parent_id', NULL, 'sales_entity/order_attribute_backend_child', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(274, 14, 'quote_payment_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(275, 14, 'method', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(276, 14, 'additional_data', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(277, 14, 'last_trans_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(278, 14, 'po_number', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(279, 14, 'cc_type', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(280, 14, 'cc_number_enc', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(281, 14, 'cc_last4', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(282, 14, 'cc_owner', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(283, 14, 'cc_exp_month', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(284, 14, 'cc_exp_year', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(285, 14, 'cc_ss_issue', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(286, 14, 'cc_ss_start_month', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(287, 14, 'cc_ss_start_year', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(288, 14, 'cc_status', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(289, 14, 'cc_status_description', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(290, 14, 'cc_trans_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(291, 14, 'cc_approval', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(292, 14, 'cc_avs_status', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(293, 14, 'cc_cid_status', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(294, 14, 'cc_debug_request_body', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(295, 14, 'cc_debug_response_body', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(296, 14, 'cc_debug_response_serialized', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(297, 14, 'anet_trans_method', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(298, 14, 'echeck_routing_number', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(299, 14, 'echeck_bank_name', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(300, 14, 'echeck_account_type', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(301, 14, 'echeck_account_name', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(302, 14, 'echeck_type', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(303, 14, 'amount_ordered', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(304, 14, 'amount_authorized', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(305, 14, 'amount_paid', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(306, 14, 'amount_canceled', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(307, 14, 'amount_refunded', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(308, 14, 'shipping_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(309, 14, 'shipping_captured', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(310, 14, 'shipping_refunded', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(311, 14, 'base_amount_ordered', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(312, 14, 'base_amount_authorized', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(313, 14, 'base_amount_paid', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(314, 14, 'base_amount_canceled', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(315, 14, 'base_amount_refunded', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(316, 14, 'base_shipping_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(317, 14, 'base_shipping_captured', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(318, 14, 'base_shipping_refunded', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(319, 15, 'parent_id', NULL, 'sales_entity/order_attribute_backend_child', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(320, 15, 'status', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(321, 15, 'comment', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(322, 15, 'is_customer_notified', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(323, 16, 'entity_id', NULL, 'sales_entity/order_invoice_attribute_backend_parent', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(324, 16, 'state', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(325, 16, 'is_used_for_refund', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(326, 16, 'transaction_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(327, 16, 'order_id', NULL, 'sales_entity/order_invoice_attribute_backend_order', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(328, 16, 'billing_address_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(329, 16, 'shipping_address_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(330, 16, 'global_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(331, 16, 'base_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(332, 16, 'store_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(333, 16, 'order_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(334, 16, 'store_to_base_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(335, 16, 'store_to_order_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(336, 16, 'base_to_global_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(337, 16, 'base_to_order_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(338, 16, 'subtotal', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(339, 16, 'discount_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(340, 16, 'tax_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(341, 16, 'shipping_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(342, 16, 'grand_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(343, 16, 'total_qty', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(344, 16, 'can_void_flag', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(345, 16, 'base_subtotal', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(346, 16, 'base_discount_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(347, 16, 'base_tax_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(348, 16, 'base_shipping_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(349, 16, 'base_grand_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(350, 16, 'email_sent', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(351, 16, 'store_id', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(352, 17, 'parent_id', NULL, 'sales_entity/order_invoice_attribute_backend_child', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(353, 17, 'order_item_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(354, 17, 'product_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(355, 17, 'name', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(356, 17, 'description', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(357, 17, 'sku', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(358, 17, 'qty', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(359, 17, 'cost', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(360, 17, 'price', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(361, 17, 'discount_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(362, 17, 'tax_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(363, 17, 'row_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(364, 17, 'base_price', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(365, 17, 'base_discount_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(366, 17, 'base_tax_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(367, 17, 'base_row_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(368, 17, 'additional_data', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(369, 18, 'parent_id', NULL, 'sales_entity/order_invoice_attribute_backend_child', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(370, 18, 'comment', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(371, 18, 'is_customer_notified', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(372, 19, 'entity_id', NULL, 'sales_entity/order_shipment_attribute_backend_parent', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(373, 19, 'customer_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(374, 19, 'order_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(375, 19, 'shipment_status', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(376, 19, 'billing_address_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(377, 19, 'shipping_address_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(378, 19, 'total_qty', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(379, 19, 'total_weight', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(380, 19, 'email_sent', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(381, 19, 'store_id', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(382, 20, 'parent_id', NULL, 'sales_entity/order_shipment_attribute_backend_child', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(383, 20, 'order_item_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(384, 20, 'product_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(385, 20, 'name', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(386, 20, 'description', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(387, 20, 'sku', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(388, 20, 'qty', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(389, 20, 'price', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(390, 20, 'weight', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(391, 20, 'row_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(392, 20, 'additional_data', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(393, 21, 'parent_id', NULL, 'sales_entity/order_shipment_attribute_backend_child', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(394, 21, 'comment', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(395, 21, 'is_customer_notified', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(396, 22, 'parent_id', NULL, 'sales_entity/order_shipment_attribute_backend_child', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(397, 22, 'order_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(398, 22, 'number', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(399, 22, 'carrier_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(400, 22, 'title', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(401, 22, 'description', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(402, 22, 'qty', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(403, 22, 'weight', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(404, 23, 'entity_id', NULL, 'sales_entity/order_creditmemo_attribute_backend_parent', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(405, 23, 'state', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(406, 23, 'invoice_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(407, 23, 'transaction_id', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(408, 23, 'order_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(409, 23, 'creditmemo_status', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(410, 23, 'billing_address_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(411, 23, 'shipping_address_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(412, 23, 'global_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(413, 23, 'base_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(414, 23, 'store_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(415, 23, 'order_currency_code', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(416, 23, 'store_to_base_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(417, 23, 'store_to_order_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(418, 23, 'base_to_global_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(419, 23, 'base_to_order_rate', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(420, 23, 'subtotal', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(421, 23, 'discount_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(422, 23, 'tax_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(423, 23, 'shipping_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(424, 23, 'adjustment', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(425, 23, 'adjustment_positive', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(426, 23, 'adjustment_negative', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(427, 23, 'grand_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(428, 23, 'base_subtotal', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(429, 23, 'base_discount_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(430, 23, 'base_tax_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(431, 23, 'base_shipping_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(432, 23, 'base_adjustment', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(433, 23, 'base_adjustment_positive', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(434, 23, 'base_adjustment_negative', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(435, 23, 'base_grand_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(436, 23, 'email_sent', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(437, 23, 'store_id', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(438, 24, 'parent_id', NULL, 'sales_entity/order_creditmemo_attribute_backend_child', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(439, 24, 'order_item_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(440, 24, 'product_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(441, 24, 'name', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(442, 24, 'description', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(443, 24, 'sku', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(444, 24, 'qty', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(445, 24, 'cost', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(446, 24, 'price', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(447, 24, 'discount_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(448, 24, 'tax_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(449, 24, 'row_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(450, 24, 'base_price', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(451, 24, 'base_discount_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(452, 24, 'base_tax_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(453, 24, 'base_row_total', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(454, 24, 'additional_data', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(455, 25, 'parent_id', NULL, 'sales_entity/order_creditmemo_attribute_backend_child', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(456, 25, 'comment', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(457, 25, 'is_customer_notified', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(458, 13, 'product_type', NULL, '', 'varchar', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(459, 11, 'can_ship_partially', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(460, 11, 'can_ship_partially_item', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(461, 11, 'payment_authorization_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(462, 11, 'payment_authorization_expiration', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(463, 11, 'shipping_tax_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(464, 11, 'base_shipping_tax_refunded', NULL, '', 'static', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(466, 4, 'enable_googlecheckout', NULL, '', 'int', '', '', 'select', '', 'Is product available for purchase with Google Checkout', NULL, 'eav/entity_attribute_source_boolean', 1, 1, 0, 0, '1', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '', 0, '', 0),
(467, 11, 'gift_message_id', NULL, '', 'int', '', '', 'text', '', '', NULL, '', 1, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(468, 4, 'gift_message_available', NULL, 'giftmessage/entity_attribute_backend_boolean_config', 'varchar', '', '', 'select', '', 'Allow Gift Message', NULL, 'giftmessage/entity_attribute_source_boolean_config', 1, 1, 0, 0, '2', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '', 0, '', 0),
(469, 4, 'price_type', NULL, '', 'int', '', '', '', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 'bundle', 0, '', 0),
(470, 4, 'sku_type', NULL, '', 'int', '', '', '', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 'bundle', 0, '', 0),
(471, 4, 'weight_type', NULL, '', 'int', '', '', '', '', '', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 'bundle', 0, '', 0),
(472, 4, 'price_view', NULL, '', 'int', '', '', 'select', '', 'Price View', NULL, 'bundle/product_attribute_source_price_view', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 'bundle', 0, '', 0),
(473, 4, 'shipment_type', NULL, '', 'int', '', '', '', '', 'Shipment', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 'bundle', 0, '', 0),
(474, 4, 'links_purchased_separately', NULL, '', 'int', '', '', '', '', 'Links can be purchased separately', NULL, '', 1, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 'downloadable', 0, '', 0),
(475, 4, 'samples_title', NULL, '', 'varchar', '', '', '', '', 'Samples title', NULL, '', 0, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 'downloadable', 0, '', 0),
(476, 4, 'links_title', NULL, '', 'varchar', '', '', '', '', 'Links title', NULL, '', 0, 0, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 'downloadable', 0, '', 0),
(477, 24, 'base_weee_tax_applied_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(478, 24, 'base_weee_tax_applied_row_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(479, 24, 'weee_tax_applied_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(480, 24, 'weee_tax_applied_row_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(481, 17, 'base_weee_tax_applied_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(482, 17, 'base_weee_tax_applied_row_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(483, 17, 'weee_tax_applied_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(484, 17, 'weee_tax_applied_row_amount', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(485, 17, 'weee_tax_applied', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(486, 24, 'weee_tax_applied', NULL, '', 'text', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(487, 24, 'weee_tax_disposition', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(488, 24, 'weee_tax_row_disposition', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(489, 24, 'base_weee_tax_disposition', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(490, 24, 'base_weee_tax_row_disposition', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(491, 17, 'weee_tax_disposition', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(492, 17, 'weee_tax_row_disposition', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(493, 17, 'base_weee_tax_disposition', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(494, 17, 'base_weee_tax_row_disposition', NULL, '', 'decimal', '', '', 'text', '', '', NULL, '', 1, 1, 1, 0, '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '', 0, '', 0),
(495, 3, 'created_time', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'created_time', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(496, 3, 'heading_title', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'heading_title', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(497, 3, 'head_title_tag', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'head_title_tag', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(498, 3, 'head_description_tag', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'head_description_tag', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(499, 3, 'head_keywords_tag', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'head_keywords_tag', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(500, 3, 'htc_title_tag', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'htc_title_tag', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(501, 3, 'htc_description', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'htc_description', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(502, 3, 'htc_description_tag', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'htc_description_tag', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(503, 3, 'htc_keywords_tag', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'htc_keywords_tag', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(504, 4, 'avail_time', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'avail_time', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(505, 4, 'ordered_count', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'ordered_count', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(506, 4, 'parent_id', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'parent_id', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(507, 4, 'viewed_count', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'viewed_count', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(508, 4, 'meta_keywords', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'meta_keywords', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(509, 1, 'login', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'login', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(510, 1, 'usertype', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'usertype', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(511, 1, 'gender', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'gender', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(512, 1, 'birthdate', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'birthdate', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(513, 1, 'phone', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'phone', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(514, 1, 'fax', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'fax', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(515, 1, 'url', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'url', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(516, 1, 'company', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'company', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(517, 1, 'status', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'status', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(518, 1, 'newsletter', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'newsletter', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(519, 1, 'selected_template', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'selected_template', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(520, 1, 'group_ra', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'group_ra', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(521, 1, 'payment_allowed', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'payment_allowed', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(522, 1, 'shipment_allowed', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'shipment_allowed', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(523, 1, 'purchased_without_account', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'purchased_without_account', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(524, 2, 'gender', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'gender', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(525, 2, 'address2', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'address2', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(526, 2, 'suburb', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'suburb', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(527, 2, 'state_iso', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'state_iso', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(528, 2, 'country_name', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'country_name', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1),
(529, 2, 'company_tax_id', NULL, NULL, 'varchar', NULL, NULL, 'text', NULL, 'company_tax_id', NULL, NULL, 1, 1, 0, 1, NULL, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 0, '', 1);

DROP TABLE IF EXISTS `dxov_eav_attribute_group`;
CREATE TABLE `dxov_eav_attribute_group` (
  `attribute_group_id` smallint(5) unsigned NOT NULL auto_increment,
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_group_name` varchar(255) NOT NULL default '',
  `sort_order` smallint(6) NOT NULL default '0',
  `default_id` smallint(5) unsigned default '0',
  PRIMARY KEY  (`attribute_group_id`),
  UNIQUE KEY `attribute_set_id` (`attribute_set_id`,`attribute_group_name`),
  KEY `attribute_set_id_2` (`attribute_set_id`,`sort_order`),
  CONSTRAINT `FK_eav_attribute_group` FOREIGN KEY (`attribute_set_id`) REFERENCES `dxov_eav_attribute_set` (`attribute_set_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_eav_attribute_group` VALUES
(1, 1, 'General', 1, 1),
(2, 2, 'General', 1, 1),
(3, 3, 'General Information', 10, 1),
(4, 4, 'General', 1, 1),
(5, 4, 'Prices', 2, 0),
(6, 4, 'Meta Information', 3, 0),
(7, 4, 'Images', 4, 0),
(8, 4, 'Design', 6, 0),
(9, 3, 'Display Settings', 20, 0),
(10, 3, 'Custom Design', 30, 0),
(11, 5, 'General', 1, 1),
(12, 6, 'General', 1, 1),
(13, 7, 'General', 1, 1),
(14, 8, 'General', 1, 1),
(15, 9, 'General', 1, 1),
(16, 10, 'General', 1, 1),
(17, 11, 'General', 1, 1),
(18, 12, 'General', 1, 1),
(19, 13, 'General', 1, 1),
(20, 14, 'General', 1, 1),
(21, 15, 'General', 1, 1),
(22, 16, 'General', 1, 1),
(23, 17, 'General', 1, 1),
(24, 18, 'General', 1, 1),
(25, 19, 'General', 1, 1),
(26, 20, 'General', 1, 1),
(27, 21, 'General', 1, 1),
(28, 22, 'General', 1, 1),
(29, 23, 'General', 1, 1),
(30, 24, 'General', 1, 1),
(31, 25, 'General', 1, 1);

DROP TABLE IF EXISTS `dxov_eav_attribute_option`;
CREATE TABLE `dxov_eav_attribute_option` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `sort_order` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`option_id`),
  KEY `FK_ATTRIBUTE_OPTION_ATTRIBUTE` (`attribute_id`),
  CONSTRAINT `FK_ATTRIBUTE_OPTION_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Attributes option (for source model)';

DROP TABLE IF EXISTS `dxov_eav_attribute_option_value`;
CREATE TABLE `dxov_eav_attribute_option_value` (
  `value_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  KEY `FK_ATTRIBUTE_OPTION_VALUE_OPTION` (`option_id`),
  KEY `FK_ATTRIBUTE_OPTION_VALUE_STORE` (`store_id`),
  CONSTRAINT `FK_ATTRIBUTE_OPTION_VALUE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `dxov_eav_attribute_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ATTRIBUTE_OPTION_VALUE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Attribute option values per store';

DROP TABLE IF EXISTS `dxov_eav_attribute_set`;
CREATE TABLE `dxov_eav_attribute_set` (
  `attribute_set_id` smallint(5) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_set_name` varchar(255) /*!40101 character set utf8 */ /*!40101 collate utf8_swedish_ci */ NOT NULL default '',
  `sort_order` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`attribute_set_id`),
  UNIQUE KEY `entity_type_id` (`entity_type_id`,`attribute_set_name`),
  KEY `entity_type_id_2` (`entity_type_id`,`sort_order`),
  CONSTRAINT `FK_eav_attribute_set` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_eav_attribute_set` VALUES
(1, 1, 'Default', 3),
(2, 2, 'Default', 3),
(3, 3, 'Default', 11),
(4, 4, 'Default', 11),
(5, 5, 'Default', 1),
(6, 6, 'Default', 1),
(7, 7, 'Default', 1),
(8, 8, 'Default', 1),
(9, 9, 'Default', 1),
(10, 10, 'Default', 1),
(11, 11, 'Default', 1),
(12, 12, 'Default', 1),
(13, 13, 'Default', 1),
(14, 14, 'Default', 1),
(15, 15, 'Default', 1),
(16, 16, 'Default', 1),
(17, 17, 'Default', 1),
(18, 18, 'Default', 1),
(19, 19, 'Default', 1),
(20, 20, 'Default', 1),
(21, 21, 'Default', 1),
(22, 22, 'Default', 1),
(23, 23, 'Default', 1),
(24, 24, 'Default', 1),
(25, 25, 'Default', 1);

DROP TABLE IF EXISTS `dxov_eav_entity`;
CREATE TABLE `dxov_eav_entity` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `increment_id` varchar(50) NOT NULL default '',
  `parent_id` int(11) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `is_active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`entity_id`),
  KEY `FK_ENTITY_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ENTITY_STORE` (`store_id`),
  CONSTRAINT `FK_eav_entity` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_eav_entity_store` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Entityies';

DROP TABLE IF EXISTS `dxov_eav_entity_attribute`;
CREATE TABLE `dxov_eav_entity_attribute` (
  `entity_attribute_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_group_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `sort_order` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`entity_attribute_id`),
  UNIQUE KEY `attribute_set_id_2` (`attribute_set_id`,`attribute_id`),
  UNIQUE KEY `attribute_group_id` (`attribute_group_id`,`attribute_id`),
  KEY `attribute_set_id_3` (`attribute_set_id`,`sort_order`),
  KEY `FK_EAV_ENTITY_ATTRIVUTE_ATTRIBUTE` (`attribute_id`),
  CONSTRAINT `FK_EAV_ENTITY_ATTRIBUTE_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EAV_ENTITY_ATTRIBUTE_GROUP` FOREIGN KEY (`attribute_group_id`) REFERENCES `dxov_eav_attribute_group` (`attribute_group_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=495 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_eav_entity_attribute` VALUES
(1, 1, 1, 1, 1, 10),
(2, 1, 1, 1, 2, 20),
(3, 1, 1, 1, 3, 30),
(4, 1, 1, 1, 4, 37),
(5, 1, 1, 1, 5, 40),
(6, 1, 1, 1, 6, 43),
(7, 1, 1, 1, 7, 50),
(8, 1, 1, 1, 8, 53),
(9, 1, 1, 1, 9, 60),
(10, 1, 1, 1, 10, 70),
(11, 1, 1, 1, 11, 80),
(12, 1, 1, 1, 12, 81),
(13, 1, 1, 1, 13, 82),
(14, 1, 1, 1, 14, 83),
(15, 1, 1, 1, 15, 84),
(16, 1, 1, 1, 16, 85),
(17, 2, 2, 2, 17, 7),
(18, 2, 2, 2, 18, 10),
(19, 2, 2, 2, 19, 13),
(20, 2, 2, 2, 20, 20),
(21, 2, 2, 2, 21, 23),
(22, 2, 2, 2, 22, 30),
(23, 2, 2, 2, 23, 40),
(24, 2, 2, 2, 24, 50),
(25, 2, 2, 2, 25, 60),
(26, 2, 2, 2, 26, 70),
(27, 2, 2, 2, 27, 80),
(28, 2, 2, 2, 28, 90),
(29, 2, 2, 2, 29, 100),
(30, 2, 2, 2, 30, 110),
(31, 3, 3, 3, 31, 1),
(32, 3, 3, 3, 32, 2),
(33, 3, 3, 3, 33, 3),
(34, 3, 3, 3, 34, 4),
(35, 3, 3, 3, 35, 5),
(36, 3, 3, 3, 36, 6),
(37, 3, 3, 3, 37, 7),
(38, 3, 3, 3, 38, 8),
(39, 3, 3, 9, 39, 10),
(40, 3, 3, 9, 40, 20),
(41, 3, 3, 9, 41, 30),
(42, 3, 3, 3, 42, 12),
(43, 3, 3, 3, 43, 13),
(44, 3, 3, 3, 44, 14),
(45, 3, 3, 3, 45, 15),
(46, 3, 3, 3, 46, 16),
(47, 3, 3, 3, 47, 17),
(48, 3, 3, 10, 48, 10),
(49, 3, 3, 10, 49, 20),
(50, 3, 3, 10, 50, 30),
(51, 3, 3, 10, 51, 40),
(52, 3, 3, 10, 52, 50),
(53, 3, 3, 10, 53, 60),
(54, 3, 3, 3, 54, 24),
(55, 3, 3, 3, 55, 25),
(56, 4, 4, 4, 56, 1),
(57, 4, 4, 4, 57, 2),
(58, 4, 4, 4, 58, 3),
(59, 4, 4, 4, 59, 4),
(60, 4, 4, 5, 60, 1),
(61, 4, 4, 5, 61, 2),
(62, 4, 4, 5, 62, 3),
(63, 4, 4, 5, 63, 4),
(64, 4, 4, 5, 64, 5),
(65, 4, 4, 4, 65, 5),
(66, 4, 4, 4, 66, 6),
(67, 4, 4, 6, 67, 1),
(68, 4, 4, 6, 68, 2),
(69, 4, 4, 6, 69, 3),
(70, 4, 4, 7, 70, 1),
(71, 4, 4, 7, 71, 2),
(72, 4, 4, 7, 72, 3),
(73, 4, 4, 7, 73, 4),
(74, 4, 4, 4, 74, 7),
(75, 4, 4, 5, 75, 10),
(76, 4, 4, 4, 76, 8),
(77, 4, 4, 4, 77, 9),
(78, 4, 4, 4, 78, 10),
(79, 4, 4, 7, 79, 5),
(80, 4, 4, 4, 80, 11),
(81, 4, 4, 5, 81, 7),
(82, 4, 4, 4, 82, 12),
(83, 4, 4, 4, 83, 13),
(84, 4, 4, 5, 84, 8),
(85, 4, 4, 4, 85, 14),
(86, 4, 4, 8, 86, 1),
(87, 4, 4, 8, 87, 2),
(88, 4, 4, 8, 88, 3),
(89, 4, 4, 8, 89, 4),
(90, 4, 4, 8, 90, 5),
(91, 4, 4, 4, 91, 15),
(92, 4, 4, 8, 92, 6),
(93, 4, 4, 4, 93, 16),
(94, 4, 4, 4, 94, 17),
(95, 4, 4, 4, 95, 18),
(96, 4, 4, 4, 96, 19),
(97, 4, 4, 4, 97, 20),
(98, 3, 3, 9, 98, 40),
(99, 3, 3, 9, 99, 50),
(100, 11, 11, 17, 100, 1),
(101, 11, 11, 17, 101, 2),
(102, 11, 11, 17, 102, 3),
(103, 11, 11, 17, 103, 4),
(104, 11, 11, 17, 104, 5),
(105, 11, 11, 17, 105, 6),
(106, 11, 11, 17, 106, 7),
(107, 11, 11, 17, 107, 8),
(108, 11, 11, 17, 108, 9),
(109, 11, 11, 17, 109, 10),
(110, 11, 11, 17, 110, 11),
(111, 11, 11, 17, 111, 12),
(112, 11, 11, 17, 112, 13),
(113, 11, 11, 17, 113, 14),
(114, 11, 11, 17, 114, 15),
(115, 11, 11, 17, 115, 16),
(116, 11, 11, 17, 116, 17),
(117, 11, 11, 17, 117, 18),
(118, 11, 11, 17, 118, 19),
(119, 11, 11, 17, 119, 20),
(120, 11, 11, 17, 120, 21),
(121, 11, 11, 17, 121, 22),
(122, 11, 11, 17, 122, 23),
(123, 11, 11, 17, 123, 24),
(124, 11, 11, 17, 124, 25),
(125, 11, 11, 17, 125, 26),
(126, 11, 11, 17, 126, 27),
(127, 11, 11, 17, 127, 28),
(128, 11, 11, 17, 128, 29),
(129, 11, 11, 17, 129, 30),
(130, 11, 11, 17, 130, 31),
(131, 11, 11, 17, 131, 32),
(132, 11, 11, 17, 132, 33),
(133, 11, 11, 17, 133, 34),
(134, 11, 11, 17, 134, 35),
(135, 11, 11, 17, 135, 36),
(136, 11, 11, 17, 136, 37),
(137, 11, 11, 17, 137, 38),
(138, 11, 11, 17, 138, 39),
(139, 11, 11, 17, 139, 40),
(140, 11, 11, 17, 140, 41),
(141, 11, 11, 17, 141, 42),
(142, 11, 11, 17, 142, 43),
(143, 11, 11, 17, 143, 44),
(144, 11, 11, 17, 144, 45),
(145, 11, 11, 17, 145, 46),
(146, 11, 11, 17, 146, 47),
(147, 11, 11, 17, 147, 48),
(148, 11, 11, 17, 148, 49),
(149, 11, 11, 17, 149, 50),
(150, 11, 11, 17, 150, 51),
(151, 11, 11, 17, 151, 52),
(152, 11, 11, 17, 152, 53),
(153, 11, 11, 17, 153, 54),
(154, 11, 11, 17, 154, 55),
(155, 11, 11, 17, 155, 56),
(156, 11, 11, 17, 156, 57),
(157, 11, 11, 17, 157, 58),
(158, 11, 11, 17, 158, 59),
(159, 11, 11, 17, 159, 60),
(160, 11, 11, 17, 160, 61),
(161, 11, 11, 17, 161, 62),
(162, 11, 11, 17, 162, 63),
(163, 11, 11, 17, 163, 64),
(164, 11, 11, 17, 164, 65),
(165, 11, 11, 17, 165, 66),
(166, 11, 11, 17, 166, 67),
(167, 11, 11, 17, 167, 68),
(168, 11, 11, 17, 168, 69),
(169, 11, 11, 17, 169, 70),
(170, 11, 11, 17, 170, 71),
(171, 11, 11, 17, 171, 72),
(172, 11, 11, 17, 172, 73),
(173, 11, 11, 17, 173, 74),
(174, 11, 11, 17, 174, 75),
(175, 11, 11, 17, 175, 76),
(176, 11, 11, 17, 176, 77),
(177, 11, 11, 17, 177, 78),
(178, 11, 11, 17, 178, 79),
(179, 11, 11, 17, 179, 80),
(180, 11, 11, 17, 180, 81),
(181, 11, 11, 17, 181, 82),
(182, 11, 11, 17, 182, 83),
(183, 11, 11, 17, 183, 84),
(184, 11, 11, 17, 184, 85),
(185, 11, 11, 17, 185, 86),
(186, 11, 11, 17, 186, 87),
(187, 11, 11, 17, 187, 88),
(188, 11, 11, 17, 188, 89),
(189, 11, 11, 17, 189, 90),
(190, 11, 11, 17, 190, 91),
(191, 11, 11, 17, 191, 92),
(192, 11, 11, 17, 192, 93),
(193, 11, 11, 17, 193, 94),
(194, 11, 11, 17, 194, 95),
(195, 11, 11, 17, 195, 96),
(196, 11, 11, 17, 196, 97),
(197, 11, 11, 17, 197, 98),
(198, 11, 11, 17, 198, 99),
(199, 11, 11, 17, 199, 100),
(200, 11, 11, 17, 200, 101),
(201, 11, 11, 17, 201, 102),
(202, 11, 11, 17, 202, 103),
(203, 11, 11, 17, 203, 104),
(204, 11, 11, 17, 204, 105),
(205, 11, 11, 17, 205, 106),
(206, 11, 11, 17, 206, 107),
(207, 11, 11, 17, 207, 108),
(208, 11, 11, 17, 208, 109),
(209, 11, 11, 17, 209, 110),
(210, 12, 12, 18, 210, 1),
(211, 12, 12, 18, 211, 2),
(212, 12, 12, 18, 212, 3),
(213, 12, 12, 18, 213, 4),
(214, 12, 12, 18, 214, 5),
(215, 12, 12, 18, 215, 6),
(216, 12, 12, 18, 216, 7),
(217, 12, 12, 18, 217, 8),
(218, 12, 12, 18, 218, 9),
(219, 12, 12, 18, 219, 10),
(220, 12, 12, 18, 220, 11),
(221, 12, 12, 18, 221, 12),
(222, 12, 12, 18, 222, 13),
(223, 12, 12, 18, 223, 14),
(224, 12, 12, 18, 224, 15),
(225, 12, 12, 18, 225, 16),
(226, 12, 12, 18, 226, 17),
(227, 12, 12, 18, 227, 18),
(228, 12, 12, 18, 228, 19),
(229, 12, 12, 18, 229, 20),
(230, 13, 13, 19, 230, 1),
(231, 13, 13, 19, 231, 2),
(232, 13, 13, 19, 232, 3),
(233, 13, 13, 19, 233, 4),
(234, 13, 13, 19, 234, 5),
(235, 13, 13, 19, 235, 6),
(236, 13, 13, 19, 236, 7),
(237, 13, 13, 19, 237, 8),
(238, 13, 13, 19, 238, 9),
(239, 13, 13, 19, 239, 10),
(240, 13, 13, 19, 240, 11),
(241, 13, 13, 19, 241, 12),
(242, 13, 13, 19, 242, 13),
(243, 13, 13, 19, 243, 14),
(244, 13, 13, 19, 244, 15),
(245, 13, 13, 19, 245, 16),
(246, 13, 13, 19, 246, 17),
(247, 13, 13, 19, 247, 18),
(248, 13, 13, 19, 248, 19),
(249, 13, 13, 19, 249, 20),
(250, 13, 13, 19, 250, 21),
(251, 13, 13, 19, 251, 22),
(252, 13, 13, 19, 252, 23),
(253, 13, 13, 19, 253, 24),
(254, 13, 13, 19, 254, 25),
(255, 13, 13, 19, 255, 26),
(256, 13, 13, 19, 256, 27),
(257, 13, 13, 19, 257, 28),
(258, 13, 13, 19, 258, 29),
(259, 13, 13, 19, 259, 30),
(260, 13, 13, 19, 260, 31),
(261, 13, 13, 19, 261, 32),
(262, 13, 13, 19, 262, 33),
(263, 13, 13, 19, 263, 34),
(264, 13, 13, 19, 264, 35),
(265, 13, 13, 19, 265, 36),
(266, 13, 13, 19, 266, 37),
(267, 13, 13, 19, 267, 38),
(268, 13, 13, 19, 268, 39),
(269, 13, 13, 19, 269, 40),
(270, 13, 13, 19, 270, 41),
(271, 13, 13, 19, 271, 42),
(272, 13, 13, 19, 272, 43),
(273, 14, 14, 20, 273, 1),
(274, 14, 14, 20, 274, 2),
(275, 14, 14, 20, 275, 3),
(276, 14, 14, 20, 276, 4),
(277, 14, 14, 20, 277, 5),
(278, 14, 14, 20, 278, 6),
(279, 14, 14, 20, 279, 7),
(280, 14, 14, 20, 280, 8),
(281, 14, 14, 20, 281, 9),
(282, 14, 14, 20, 282, 10),
(283, 14, 14, 20, 283, 11),
(284, 14, 14, 20, 284, 12),
(285, 14, 14, 20, 285, 13),
(286, 14, 14, 20, 286, 14),
(287, 14, 14, 20, 287, 15),
(288, 14, 14, 20, 288, 16),
(289, 14, 14, 20, 289, 17),
(290, 14, 14, 20, 290, 18),
(291, 14, 14, 20, 291, 19),
(292, 14, 14, 20, 292, 20),
(293, 14, 14, 20, 293, 21),
(294, 14, 14, 20, 294, 22),
(295, 14, 14, 20, 295, 23),
(296, 14, 14, 20, 296, 24),
(297, 14, 14, 20, 297, 25),
(298, 14, 14, 20, 298, 26),
(299, 14, 14, 20, 299, 27),
(300, 14, 14, 20, 300, 28),
(301, 14, 14, 20, 301, 29),
(302, 14, 14, 20, 302, 30),
(303, 14, 14, 20, 303, 31),
(304, 14, 14, 20, 304, 32),
(305, 14, 14, 20, 305, 33),
(306, 14, 14, 20, 306, 34),
(307, 14, 14, 20, 307, 35),
(308, 14, 14, 20, 308, 36),
(309, 14, 14, 20, 309, 37),
(310, 14, 14, 20, 310, 38),
(311, 14, 14, 20, 311, 39),
(312, 14, 14, 20, 312, 40),
(313, 14, 14, 20, 313, 41),
(314, 14, 14, 20, 314, 42),
(315, 14, 14, 20, 315, 43),
(316, 14, 14, 20, 316, 44),
(317, 14, 14, 20, 317, 45),
(318, 14, 14, 20, 318, 46),
(319, 15, 15, 21, 319, 1),
(320, 15, 15, 21, 320, 2),
(321, 15, 15, 21, 321, 3),
(322, 15, 15, 21, 322, 4),
(323, 16, 16, 22, 323, 1),
(324, 16, 16, 22, 324, 2),
(325, 16, 16, 22, 325, 3),
(326, 16, 16, 22, 326, 4),
(327, 16, 16, 22, 327, 5),
(328, 16, 16, 22, 328, 6),
(329, 16, 16, 22, 329, 7),
(330, 16, 16, 22, 330, 8),
(331, 16, 16, 22, 331, 9),
(332, 16, 16, 22, 332, 10),
(333, 16, 16, 22, 333, 11),
(334, 16, 16, 22, 334, 12),
(335, 16, 16, 22, 335, 13),
(336, 16, 16, 22, 336, 14),
(337, 16, 16, 22, 337, 15),
(338, 16, 16, 22, 338, 16),
(339, 16, 16, 22, 339, 17),
(340, 16, 16, 22, 340, 18),
(341, 16, 16, 22, 341, 19),
(342, 16, 16, 22, 342, 20),
(343, 16, 16, 22, 343, 21),
(344, 16, 16, 22, 344, 22),
(345, 16, 16, 22, 345, 23),
(346, 16, 16, 22, 346, 24),
(347, 16, 16, 22, 347, 25),
(348, 16, 16, 22, 348, 26),
(349, 16, 16, 22, 349, 27),
(350, 16, 16, 22, 350, 28),
(351, 16, 16, 22, 351, 29),
(352, 17, 17, 23, 352, 1),
(353, 17, 17, 23, 353, 2),
(354, 17, 17, 23, 354, 3),
(355, 17, 17, 23, 355, 4),
(356, 17, 17, 23, 356, 5),
(357, 17, 17, 23, 357, 6),
(358, 17, 17, 23, 358, 7),
(359, 17, 17, 23, 359, 8),
(360, 17, 17, 23, 360, 9),
(361, 17, 17, 23, 361, 10),
(362, 17, 17, 23, 362, 11),
(363, 17, 17, 23, 363, 12),
(364, 17, 17, 23, 364, 13),
(365, 17, 17, 23, 365, 14),
(366, 17, 17, 23, 366, 15),
(367, 17, 17, 23, 367, 16),
(368, 17, 17, 23, 368, 17),
(369, 18, 18, 24, 369, 1),
(370, 18, 18, 24, 370, 2),
(371, 18, 18, 24, 371, 3),
(372, 19, 19, 25, 372, 1),
(373, 19, 19, 25, 373, 2),
(374, 19, 19, 25, 374, 3),
(375, 19, 19, 25, 375, 4),
(376, 19, 19, 25, 376, 5),
(377, 19, 19, 25, 377, 6),
(378, 19, 19, 25, 378, 7),
(379, 19, 19, 25, 379, 8),
(380, 19, 19, 25, 380, 9),
(381, 19, 19, 25, 381, 10),
(382, 20, 20, 26, 382, 1),
(383, 20, 20, 26, 383, 2),
(384, 20, 20, 26, 384, 3),
(385, 20, 20, 26, 385, 4),
(386, 20, 20, 26, 386, 5),
(387, 20, 20, 26, 387, 6),
(388, 20, 20, 26, 388, 7),
(389, 20, 20, 26, 389, 8),
(390, 20, 20, 26, 390, 9),
(391, 20, 20, 26, 391, 10),
(392, 20, 20, 26, 392, 11),
(393, 21, 21, 27, 393, 1),
(394, 21, 21, 27, 394, 2),
(395, 21, 21, 27, 395, 3),
(396, 22, 22, 28, 396, 1),
(397, 22, 22, 28, 397, 2),
(398, 22, 22, 28, 398, 3),
(399, 22, 22, 28, 399, 4),
(400, 22, 22, 28, 400, 5),
(401, 22, 22, 28, 401, 6),
(402, 22, 22, 28, 402, 7),
(403, 22, 22, 28, 403, 8),
(404, 23, 23, 29, 404, 1),
(405, 23, 23, 29, 405, 2),
(406, 23, 23, 29, 406, 3),
(407, 23, 23, 29, 407, 4),
(408, 23, 23, 29, 408, 5),
(409, 23, 23, 29, 409, 6),
(410, 23, 23, 29, 410, 7),
(411, 23, 23, 29, 411, 8),
(412, 23, 23, 29, 412, 9),
(413, 23, 23, 29, 413, 10),
(414, 23, 23, 29, 414, 11),
(415, 23, 23, 29, 415, 12),
(416, 23, 23, 29, 416, 13),
(417, 23, 23, 29, 417, 14),
(418, 23, 23, 29, 418, 15),
(419, 23, 23, 29, 419, 16),
(420, 23, 23, 29, 420, 17),
(421, 23, 23, 29, 421, 18),
(422, 23, 23, 29, 422, 19),
(423, 23, 23, 29, 423, 20),
(424, 23, 23, 29, 424, 21),
(425, 23, 23, 29, 425, 22),
(426, 23, 23, 29, 426, 23),
(427, 23, 23, 29, 427, 24),
(428, 23, 23, 29, 428, 25),
(429, 23, 23, 29, 429, 26),
(430, 23, 23, 29, 430, 27),
(431, 23, 23, 29, 431, 28),
(432, 23, 23, 29, 432, 29),
(433, 23, 23, 29, 433, 30),
(434, 23, 23, 29, 434, 31),
(435, 23, 23, 29, 435, 32),
(436, 23, 23, 29, 436, 33),
(437, 23, 23, 29, 437, 34),
(438, 24, 24, 30, 438, 1),
(439, 24, 24, 30, 439, 2),
(440, 24, 24, 30, 440, 3),
(441, 24, 24, 30, 441, 4),
(442, 24, 24, 30, 442, 5),
(443, 24, 24, 30, 443, 6),
(444, 24, 24, 30, 444, 7),
(445, 24, 24, 30, 445, 8),
(446, 24, 24, 30, 446, 9),
(447, 24, 24, 30, 447, 10),
(448, 24, 24, 30, 448, 11),
(449, 24, 24, 30, 449, 12),
(450, 24, 24, 30, 450, 13),
(451, 24, 24, 30, 451, 14),
(452, 24, 24, 30, 452, 15),
(453, 24, 24, 30, 453, 16),
(454, 24, 24, 30, 454, 17),
(455, 25, 25, 31, 455, 1),
(456, 25, 25, 31, 456, 2),
(457, 25, 25, 31, 457, 3),
(458, 13, 13, 19, 458, 44),
(459, 11, 11, 17, 459, 111),
(460, 11, 11, 17, 460, 112),
(461, 11, 11, 17, 461, 113),
(462, 11, 11, 17, 462, 114),
(463, 11, 11, 17, 463, 115),
(464, 11, 11, 17, 464, 116),
(465, 11, 11, 17, 465, 117),
(466, 4, 4, 5, 466, 21),
(467, 11, 11, 17, 467, 118),
(468, 4, 4, 4, 468, 21),
(469, 4, 4, 4, 469, 22),
(470, 4, 4, 4, 470, 23),
(471, 4, 4, 4, 471, 24),
(472, 4, 4, 5, 472, 22),
(473, 4, 4, 4, 473, 25),
(474, 4, 4, 4, 474, 26),
(475, 4, 4, 4, 475, 27),
(476, 4, 4, 4, 476, 28),
(477, 24, 24, 30, 477, 18),
(478, 24, 24, 30, 478, 19),
(479, 24, 24, 30, 479, 20),
(480, 24, 24, 30, 480, 21),
(481, 17, 17, 23, 481, 18),
(482, 17, 17, 23, 482, 19),
(483, 17, 17, 23, 483, 20),
(484, 17, 17, 23, 484, 21),
(485, 17, 17, 23, 485, 22),
(486, 24, 24, 30, 486, 22),
(487, 24, 24, 30, 487, 23),
(488, 24, 24, 30, 488, 24),
(489, 24, 24, 30, 489, 25),
(490, 24, 24, 30, 490, 26),
(491, 17, 17, 23, 491, 23),
(492, 17, 17, 23, 492, 24),
(493, 17, 17, 23, 493, 25),
(494, 17, 17, 23, 494, 26);

DROP TABLE IF EXISTS `dxov_eav_entity_datetime`;
CREATE TABLE `dxov_eav_entity_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`value_id`),
  KEY `FK_ATTRIBUTE_DATETIME_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ATTRIBUTE_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_ATTRIBUTE_DATETIME_STORE` (`store_id`),
  KEY `FK_ATTRIBUTE_DATETIME_ENTITY` (`entity_id`),
  KEY `value_by_attribute` (`attribute_id`,`value`),
  KEY `value_by_entity_type` (`entity_type_id`,`value`),
  CONSTRAINT `FK_EAV_ENTITY_DATETIME_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_eav_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EAV_ENTITY_DATETIME_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EAV_ENTITY_DATETIME_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Datetime values of attributes';

DROP TABLE IF EXISTS `dxov_eav_entity_decimal`;
CREATE TABLE `dxov_eav_entity_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  KEY `FK_ATTRIBUTE_DECIMAL_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ATTRIBUTE_DECIMAL_ATTRIBUTE` (`attribute_id`),
  KEY `FK_ATTRIBUTE_DECIMAL_STORE` (`store_id`),
  KEY `FK_ATTRIBUTE_DECIMAL_ENTITY` (`entity_id`),
  KEY `value_by_attribute` (`attribute_id`,`value`),
  KEY `value_by_entity_type` (`entity_type_id`,`value`),
  CONSTRAINT `FK_EAV_ENTITY_DECIMAL_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_eav_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EAV_ENTITY_DECIMAL_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EAV_ENTITY_DECIMAL_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Decimal values of attributes';

DROP TABLE IF EXISTS `dxov_eav_entity_int`;
CREATE TABLE `dxov_eav_entity_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  KEY `FK_ATTRIBUTE_INT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ATTRIBUTE_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_ATTRIBUTE_INT_STORE` (`store_id`),
  KEY `FK_ATTRIBUTE_INT_ENTITY` (`entity_id`),
  KEY `value_by_attribute` (`attribute_id`,`value`),
  KEY `value_by_entity_type` (`entity_type_id`,`value`),
  CONSTRAINT `FK_EAV_ENTITY_INT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_eav_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EAV_ENTITY_INT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EAV_ENTITY_INT_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Integer values of attributes';

DROP TABLE IF EXISTS `dxov_eav_entity_store`;
CREATE TABLE `dxov_eav_entity_store` (
  `entity_store_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `increment_prefix` varchar(20) NOT NULL default '',
  `increment_last_id` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`entity_store_id`),
  KEY `FK_eav_entity_store_entity_type` (`entity_type_id`),
  KEY `FK_eav_entity_store_store` (`store_id`),
  CONSTRAINT `FK_eav_entity_store_entity_type` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_eav_entity_store_store` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_eav_entity_text`;
CREATE TABLE `dxov_eav_entity_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  KEY `FK_ATTRIBUTE_TEXT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ATTRIBUTE_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_ATTRIBUTE_TEXT_STORE` (`store_id`),
  KEY `FK_ATTRIBUTE_TEXT_ENTITY` (`entity_id`),
  CONSTRAINT `FK_EAV_ENTITY_TEXT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_eav_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EAV_ENTITY_TEXT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EAV_ENTITY_TEXT_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Text values of attributes';

DROP TABLE IF EXISTS `dxov_eav_entity_type`;
CREATE TABLE `dxov_eav_entity_type` (
  `entity_type_id` smallint(5) unsigned NOT NULL auto_increment,
  `entity_type_code` varchar(50) NOT NULL default '',
  `entity_model` varchar(255) NOT NULL,
  `attribute_model` varchar(255) NOT NULL,
  `entity_table` varchar(255) NOT NULL default '',
  `value_table_prefix` varchar(255) NOT NULL default '',
  `entity_id_field` varchar(255) NOT NULL default '',
  `is_data_sharing` tinyint(4) unsigned NOT NULL default '1',
  `data_sharing_key` varchar(100) default 'default',
  `default_attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `increment_model` varchar(255) NOT NULL default '',
  `increment_per_store` tinyint(1) unsigned NOT NULL default '0',
  `increment_pad_length` tinyint(8) unsigned NOT NULL default '8',
  `increment_pad_char` char(1) NOT NULL default '0',
  PRIMARY KEY  (`entity_type_id`),
  KEY `entity_name` (`entity_type_code`)
) ENGINE=InnoDB AUTO_INCREMENT=26 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_eav_entity_type` VALUES
(1, 'customer', 'customer/customer', '', 'customer/entity', '', '', 1, 'default', 1, 'eav/entity_increment_numeric', 0, 8, '0'),
(2, 'customer_address', 'customer/customer_address', '', 'customer/address_entity', '', '', 1, 'default', 2, '', 0, 8, '0'),
(3, 'catalog_category', 'catalog/category', 'catalog/resource_eav_attribute', 'catalog/category', '', '', 1, 'default', 3, '', 0, 8, '0'),
(4, 'catalog_product', 'catalog/product', 'catalog/resource_eav_attribute', 'catalog/product', '', '', 1, 'default', 4, '', 0, 8, '0'),
(5, 'quote', 'sales/quote', '', 'sales/quote', '', '', 1, 'default', 5, '', 0, 8, '0'),
(6, 'quote_item', 'sales/quote_item', '', 'sales/quote_item', '', '', 1, 'default', 6, '', 0, 8, '0'),
(7, 'quote_address', 'sales/quote_address', '', 'sales/quote_address', '', '', 1, 'default', 7, '', 0, 8, '0'),
(8, 'quote_address_item', 'sales/quote_address_item', '', 'sales/quote_entity', '', '', 1, 'default', 8, '', 0, 8, '0'),
(9, 'quote_address_rate', 'sales/quote_address_rate', '', 'sales/quote_entity', '', '', 1, 'default', 9, '', 0, 8, '0'),
(10, 'quote_payment', 'sales/quote_payment', '', 'sales/quote_entity', '', '', 1, 'default', 10, '', 0, 8, '0'),
(11, 'order', 'sales/order', '', 'sales/order', '', '', 1, 'default', 11, 'eav/entity_increment_numeric', 1, 8, '0'),
(12, 'order_address', 'sales/order_address', '', 'sales/order_entity', '', '', 1, 'default', 12, '', 0, 8, '0'),
(13, 'order_item', 'sales/order_item', '', 'sales/order_entity', '', '', 1, 'default', 13, '', 0, 8, '0'),
(14, 'order_payment', 'sales/order_payment', '', 'sales/order_entity', '', '', 1, 'default', 14, '', 0, 8, '0'),
(15, 'order_status_history', 'sales/order_status_history', '', 'sales/order_entity', '', '', 1, 'default', 15, '', 0, 8, '0'),
(16, 'invoice', 'sales/order_invoice', '', 'sales/order_entity', '', '', 1, 'default', 16, 'eav/entity_increment_numeric', 1, 8, '0'),
(17, 'invoice_item', 'sales/order_invoice_item', '', 'sales/order_entity', '', '', 1, 'default', 17, '', 0, 8, '0'),
(18, 'invoice_comment', 'sales/order_invoice_comment', '', 'sales/order_entity', '', '', 1, 'default', 18, '', 0, 8, '0'),
(19, 'shipment', 'sales/order_shipment', '', 'sales/order_entity', '', '', 1, 'default', 19, 'eav/entity_increment_numeric', 1, 8, '0'),
(20, 'shipment_item', 'sales/order_shipment_item', '', 'sales/order_entity', '', '', 1, 'default', 20, '', 0, 8, '0'),
(21, 'shipment_comment', 'sales/order_shipment_comment', '', 'sales/order_entity', '', '', 1, 'default', 21, '', 0, 8, '0'),
(22, 'shipment_track', 'sales/order_shipment_track', '', 'sales/order_entity', '', '', 1, 'default', 22, '', 0, 8, '0'),
(23, 'creditmemo', 'sales/order_creditmemo', '', 'sales/order_entity', '', '', 1, 'default', 23, 'eav/entity_increment_numeric', 1, 8, '0'),
(24, 'creditmemo_item', 'sales/order_creditmemo_item', '', 'sales/order_entity', '', '', 1, 'default', 24, '', 0, 8, '0'),
(25, 'creditmemo_comment', 'sales/order_creditmemo_comment', '', 'sales/order_entity', '', '', 1, 'default', 25, '', 0, 8, '0');

DROP TABLE IF EXISTS `dxov_eav_entity_varchar`;
CREATE TABLE `dxov_eav_entity_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  KEY `FK_ATTRIBUTE_VARCHAR_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ATTRIBUTE_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_ATTRIBUTE_VARCHAR_STORE` (`store_id`),
  KEY `FK_ATTRIBUTE_VARCHAR_ENTITY` (`entity_id`),
  KEY `value_by_attribute` (`attribute_id`,`value`),
  KEY `value_by_entity_type` (`entity_type_id`,`value`),
  CONSTRAINT `FK_EAV_ENTITY_VARCHAR_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_eav_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EAV_ENTITY_VARCHAR_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EAV_ENTITY_VARCHAR_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Varchar values of attributes';

DROP TABLE IF EXISTS `dxov_gift_message`;
CREATE TABLE `dxov_gift_message` (
  `gift_message_id` int(7) unsigned NOT NULL auto_increment,
  `customer_id` int(7) unsigned NOT NULL default '0',
  `sender` varchar(255) NOT NULL default '',
  `recipient` varchar(255) NOT NULL default '',
  `message` text NOT NULL,
  PRIMARY KEY  (`gift_message_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_googlebase_attributes`;
CREATE TABLE `dxov_googlebase_attributes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `attribute_id` smallint(5) unsigned NOT NULL,
  `gbase_attribute` varchar(255) NOT NULL,
  `type_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `GOOGLEBASE_ATTRIBUTES_ATTRIBUTE_ID` (`attribute_id`),
  KEY `GOOGLEBASE_ATTRIBUTES_TYPE_ID` (`type_id`),
  CONSTRAINT `GOOGLEBASE_ATTRIBUTES_ATTRIBUTE_ID` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE,
  CONSTRAINT `GOOGLEBASE_ATTRIBUTES_TYPE_ID` FOREIGN KEY (`type_id`) REFERENCES `dxov_googlebase_types` (`type_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Google Base Attributes link Product Attributes';

DROP TABLE IF EXISTS `dxov_googlebase_items`;
CREATE TABLE `dxov_googlebase_items` (
  `item_id` int(10) unsigned NOT NULL auto_increment,
  `type_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL,
  `gbase_item_id` varchar(255) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `published` datetime NOT NULL default '0000-00-00 00:00:00',
  `expires` datetime NOT NULL default '0000-00-00 00:00:00',
  `impr` smallint(5) unsigned NOT NULL default '0',
  `clicks` smallint(5) unsigned NOT NULL default '0',
  `views` smallint(5) unsigned NOT NULL default '0',
  `is_hidden` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`item_id`),
  KEY `GOOGLEBASE_ITEMS_PRODUCT_ID` (`product_id`),
  KEY `GOOGLEBASE_ITEMS_STORE_ID` (`store_id`),
  CONSTRAINT `GOOGLEBASE_ITEMS_PRODUCT_ID` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE,
  CONSTRAINT `GOOGLEBASE_ITEMS_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Google Base Items Products';

DROP TABLE IF EXISTS `dxov_googlebase_types`;
CREATE TABLE `dxov_googlebase_types` (
  `type_id` int(10) unsigned NOT NULL auto_increment,
  `attribute_set_id` smallint(5) unsigned NOT NULL,
  `gbase_itemtype` varchar(255) NOT NULL,
  `target_country` varchar(2) NOT NULL default 'US',
  PRIMARY KEY  (`type_id`),
  KEY `GOOGLEBASE_TYPES_ATTRIBUTE_SET_ID` (`attribute_set_id`),
  CONSTRAINT `GOOGLEBASE_TYPES_ATTRIBUTE_SET_ID` FOREIGN KEY (`attribute_set_id`) REFERENCES `dxov_eav_attribute_set` (`attribute_set_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Google Base Item Types link Attribute Sets';

DROP TABLE IF EXISTS `dxov_googlecheckout_api_debug`;
CREATE TABLE `dxov_googlecheckout_api_debug` (
  `debug_id` int(10) unsigned NOT NULL auto_increment,
  `dir` enum('in','out') default NULL,
  `url` varchar(255) default NULL,
  `request_body` text,
  `response_body` text,
  PRIMARY KEY  (`debug_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_googleoptimizer_code`;
CREATE TABLE `dxov_googleoptimizer_code` (
  `code_id` int(10) unsigned NOT NULL auto_increment,
  `entity_id` int(10) unsigned NOT NULL,
  `entity_type` varchar(50) NOT NULL default '',
  `store_id` smallint(5) unsigned NOT NULL,
  `control_script` text,
  `tracking_script` text,
  `conversion_script` text,
  `conversion_page` varchar(255) NOT NULL default '',
  `additional_data` text,
  PRIMARY KEY  (`code_id`),
  KEY `GOOGLEOPTIMIZER_CODE_STORE` (`store_id`),
  CONSTRAINT `FK_GOOGLEOPTIMIZER_CODE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_livechat_messages`;
CREATE TABLE `dxov_livechat_messages` (
  `id` int(10) NOT NULL auto_increment,
  `livechat_session_id` int(10) NOT NULL,
  `autor_name` varchar(32) NOT NULL,
  `is_customer_message` enum('0','1') NOT NULL default '0',
  `message` text NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `livechat_session_id` (`livechat_session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_livechat_messages` VALUES
(30, 2, 'Customer', '1', 'hello', '2009-05-25 20:19:39'),
(31, 2, 'System', '0', 'Your message has been sent, an operator will answer you soon', '2009-05-25 20:19:39'),
(32, 2, 'Customer', '1', 'shprits', '2009-05-25 20:19:50');

DROP TABLE IF EXISTS `dxov_livechat_messages_archives`;
CREATE TABLE `dxov_livechat_messages_archives` (
  `id` int(10) NOT NULL auto_increment,
  `livechat_session_id` int(10) NOT NULL,
  `autor_name` varchar(32) NOT NULL,
  `is_customer_message` enum('0','1') NOT NULL default '0',
  `message` text NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `livechat_session_id` (`livechat_session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_livechat_messages_archives` VALUES
(1, 1, 'Customer', '1', 'Hello&#124;', '2009-05-25 18:59:06'),
(2, 1, 'System', '0', 'Your message has been sent, an operator will answer you soon', '2009-05-25 18:59:06'),
(3, 1, 'alex', '0', 'Hello', '2009-05-25 19:00:06'),
(4, 1, 'Customer', '1', 'I am interested in the Big Ace', '2009-05-25 19:00:23'),
(5, 1, 'alex', '0', 'That is an excellent choice', '2009-05-25 19:01:12'),
(6, 1, 'alex', '0', 'What gauge do you like', '2009-05-25 19:01:30'),
(7, 1, 'Customer', '1', '1.15', '2009-05-25 19:01:39'),
(8, 1, 'alex', '0', 'hh\\', '2009-05-25 19:02:12'),
(9, 1, 'alex', '0', 'm', '2009-05-25 19:02:14'),
(10, 1, 'alex', '0', ',', '2009-05-25 19:02:15'),
(11, 1, 'alex', '0', ',', '2009-05-25 19:02:16'),
(12, 1, 'alex', '0', ',', '2009-05-25 19:02:16'),
(13, 1, 'alex', '0', ',,', '2009-05-25 19:02:17'),
(14, 1, 'alex', '0', ',', '2009-05-25 19:02:18'),
(15, 1, 'alex', '0', ',', '2009-05-25 19:02:18'),
(16, 1, 'alex', '0', ',', '2009-05-25 19:02:18'),
(17, 1, 'alex', '0', ',', '2009-05-25 19:02:19'),
(18, 1, 'Customer', '1', 'what is the best string you have', '2009-05-25 19:02:58'),
(19, 1, 'alex', '0', 'that is a tough question...', '2009-05-25 19:03:08'),
(20, 1, 'Customer', '1', 'please answer me&#124;&#124;', '2009-05-25 19:03:17'),
(21, 1, 'alex', '0', 'is there anything else I can help you with?', '2009-05-25 19:03:59'),
(22, 1, 'Customer', '1', 'nope', '2009-05-25 19:04:29'),
(23, 1, 'Customer', '1', 'I will place an order soon', '2009-05-25 19:04:34'),
(24, 1, 'alex', '0', 'Thank you for your interest in The Tennis Depot', '2009-05-25 19:04:51'),
(25, 1, 'alex', '0', 'We hope to serve you soon!', '2009-05-25 19:04:58'),
(26, 1, 'alex', '0', 'Bye', '2009-05-25 19:05:03'),
(27, 1, 'Customer', '1', 'bye', '2009-05-25 19:05:10'),
(28, 1, 'Customer', '1', 'test', '2009-05-25 19:06:32'),
(29, 1, 'Customer', '1', 'test', '2009-05-25 19:06:34');

DROP TABLE IF EXISTS `dxov_livechat_operators`;
CREATE TABLE `dxov_livechat_operators` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(32) NOT NULL,
  `is_online` enum('0','1') NOT NULL default '0',
  `store_allowed` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_livechat_operators` VALUES
(1, 'alex', '1', '1');

DROP TABLE IF EXISTS `dxov_livechat_sessions`;
CREATE TABLE `dxov_livechat_sessions` (
  `id` int(10) NOT NULL auto_increment,
  `customer_name` varchar(32) NOT NULL,
  `date_started` datetime NOT NULL,
  `customer_session_id` varchar(255) NOT NULL,
  `dispatched` int(10) NOT NULL default '0',
  `store_id` int(10) NOT NULL,
  `order_placed` varchar(25) NOT NULL,
  `close` enum('0','1') NOT NULL default '0',
  `customer_url` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `customer_session_id` (`customer_session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_livechat_sessions` VALUES
(2, 'Customer', '2009-05-25 20:19:39', 'ef97e949990375682f1cbd679e96b431', 0, 1, '', '0', '');

DROP TABLE IF EXISTS `dxov_livechat_sessions_archives`;
CREATE TABLE `dxov_livechat_sessions_archives` (
  `id` int(10) NOT NULL auto_increment,
  `customer_name` varchar(32) NOT NULL,
  `date_started` datetime NOT NULL,
  `customer_session_id` varchar(255) NOT NULL,
  `dispatched` int(10) NOT NULL default '0',
  `store_id` int(10) NOT NULL,
  `order_placed` varchar(25) NOT NULL,
  `close` enum('0','1') NOT NULL default '0',
  `customer_url` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `customer_session_id` (`customer_session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_livechat_sessions_archives` VALUES
(1, 'Customer', '2009-05-25 18:59:06', '1097950acae6e92b80a5978a32abbaa6about-magento-demo-store', 1, 1, '', '1', 'http://www.thetennisdepot.com/skin/adminhtml/default/default/images/livechat/ajax-loader.gif');

DROP TABLE IF EXISTS `dxov_log_customer`;
CREATE TABLE `dxov_log_customer` (
  `log_id` int(10) unsigned NOT NULL auto_increment,
  `visitor_id` bigint(20) unsigned default NULL,
  `customer_id` int(11) NOT NULL default '0',
  `login_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `logout_at` datetime default NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`log_id`),
  KEY `IDX_VISITOR` (`visitor_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Customers log information';

DROP TABLE IF EXISTS `dxov_log_quote`;
CREATE TABLE `dxov_log_quote` (
  `quote_id` int(10) unsigned NOT NULL default '0',
  `visitor_id` bigint(20) unsigned default NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `deleted_at` datetime default NULL,
  PRIMARY KEY  (`quote_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Quote log data';

DROP TABLE IF EXISTS `dxov_log_summary`;
CREATE TABLE `dxov_log_summary` (
  `summary_id` bigint(20) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL,
  `type_id` smallint(5) unsigned default NULL,
  `visitor_count` int(11) NOT NULL default '0',
  `customer_count` int(11) NOT NULL default '0',
  `add_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`summary_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Summary log information';

DROP TABLE IF EXISTS `dxov_log_summary_type`;
CREATE TABLE `dxov_log_summary_type` (
  `type_id` smallint(5) unsigned NOT NULL auto_increment,
  `type_code` varchar(64) NOT NULL default '',
  `period` smallint(5) unsigned NOT NULL default '0',
  `period_type` enum('MINUTE','HOUR','DAY','WEEK','MONTH') NOT NULL default 'MINUTE',
  PRIMARY KEY  (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Type of summary information';

INSERT INTO `dxov_log_summary_type` VALUES
(1, 'hour', 1, 'HOUR'),
(2, 'day', 1, 'DAY');

DROP TABLE IF EXISTS `dxov_log_url`;
CREATE TABLE `dxov_log_url` (
  `url_id` bigint(20) unsigned NOT NULL default '0',
  `visitor_id` bigint(20) unsigned default NULL,
  `visit_time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`url_id`),
  KEY `IDX_VISITOR` (`visitor_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='URL visiting history';

INSERT INTO `dxov_log_url` VALUES
(1, 1, '2009-05-25 13:46:25'),
(2, 1, '2009-05-25 13:46:39'),
(3, 1, '2009-05-25 13:47:13'),
(4, 1, '2009-05-25 13:47:22'),
(5, 1, '2009-05-25 13:47:29'),
(6, 2, '2009-05-25 14:13:45'),
(7, 2, '2009-05-25 14:14:18'),
(8, 3, '2009-05-25 14:40:21'),
(9, 4, '2009-05-25 16:43:28'),
(10, 5, '2009-05-25 16:43:34'),
(11, 6, '2009-05-25 17:25:32'),
(12, 7, '2009-05-25 17:25:32'),
(13, 7, '2009-05-25 17:28:55'),
(14, 7, '2009-05-25 17:29:07'),
(15, 8, '2009-05-25 17:47:07'),
(16, 9, '2009-05-25 17:47:13'),
(17, 10, '2009-05-25 17:49:38'),
(18, 9, '2009-05-25 17:55:33'),
(19, 11, '2009-05-25 18:34:15'),
(20, 11, '2009-05-25 18:34:47'),
(21, 11, '2009-05-25 18:42:45'),
(22, 11, '2009-05-25 18:43:47'),
(23, 11, '2009-05-25 18:50:54'),
(24, 11, '2009-05-25 18:58:53'),
(25, 11, '2009-05-25 18:59:06'),
(26, 11, '2009-05-25 18:59:06'),
(27, 11, '2009-05-25 18:59:17'),
(28, 11, '2009-05-25 18:59:27'),
(29, 11, '2009-05-25 18:59:37'),
(30, 11, '2009-05-25 18:59:48'),
(31, 11, '2009-05-25 18:59:54'),
(32, 11, '2009-05-25 18:59:58'),
(33, 11, '2009-05-25 19:00:08'),
(34, 11, '2009-05-25 19:00:18'),
(35, 11, '2009-05-25 19:00:23'),
(36, 11, '2009-05-25 19:00:29'),
(37, 11, '2009-05-25 19:00:39'),
(38, 11, '2009-05-25 19:00:43'),
(39, 11, '2009-05-25 19:00:44'),
(40, 11, '2009-05-25 19:00:49'),
(41, 11, '2009-05-25 19:00:54'),
(42, 11, '2009-05-25 19:01:00'),
(43, 11, '2009-05-25 19:01:10'),
(44, 11, '2009-05-25 19:01:20'),
(45, 11, '2009-05-25 19:01:31'),
(46, 11, '2009-05-25 19:01:39'),
(47, 11, '2009-05-25 19:01:41'),
(48, 11, '2009-05-25 19:01:51'),
(49, 11, '2009-05-25 19:02:02'),
(50, 11, '2009-05-25 19:02:12'),
(51, 11, '2009-05-25 19:02:23'),
(52, 11, '2009-05-25 19:02:34'),
(53, 11, '2009-05-25 19:02:44'),
(54, 11, '2009-05-25 19:02:54'),
(55, 11, '2009-05-25 19:02:58'),
(56, 11, '2009-05-25 19:03:05'),
(57, 11, '2009-05-25 19:03:15'),
(58, 11, '2009-05-25 19:03:17'),
(59, 11, '2009-05-25 19:03:25'),
(60, 11, '2009-05-25 19:03:36'),
(61, 11, '2009-05-25 19:03:46'),
(62, 11, '2009-05-25 19:03:56'),
(63, 11, '2009-05-25 19:04:07'),
(64, 11, '2009-05-25 19:04:17'),
(65, 11, '2009-05-25 19:04:27'),
(66, 11, '2009-05-25 19:04:29'),
(67, 11, '2009-05-25 19:04:34'),
(68, 11, '2009-05-25 19:04:38'),
(69, 11, '2009-05-25 19:04:48'),
(70, 11, '2009-05-25 19:04:58'),
(71, 11, '2009-05-25 19:05:09'),
(72, 11, '2009-05-25 19:05:10'),
(73, 11, '2009-05-25 19:05:19'),
(74, 11, '2009-05-25 19:05:29'),
(75, 11, '2009-05-25 19:05:40'),
(76, 11, '2009-05-25 19:05:50'),
(77, 11, '2009-05-25 19:06:00'),
(78, 11, '2009-05-25 19:06:11'),
(79, 11, '2009-05-25 19:06:21'),
(80, 11, '2009-05-25 19:06:31'),
(81, 11, '2009-05-25 19:06:32'),
(82, 11, '2009-05-25 19:06:34'),
(83, 11, '2009-05-25 19:06:42'),
(84, 11, '2009-05-25 19:06:52'),
(85, 11, '2009-05-25 19:07:03'),
(86, 11, '2009-05-25 19:07:08'),
(87, 11, '2009-05-25 19:07:14'),
(88, 11, '2009-05-25 19:07:24'),
(89, 11, '2009-05-25 19:07:34'),
(90, 11, '2009-05-25 19:07:45'),
(91, 11, '2009-05-25 19:07:55'),
(92, 11, '2009-05-25 19:08:05'),
(93, 11, '2009-05-25 19:08:16'),
(94, 11, '2009-05-25 19:08:26'),
(95, 11, '2009-05-25 19:08:36'),
(96, 11, '2009-05-25 19:08:47'),
(97, 11, '2009-05-25 19:08:57'),
(98, 11, '2009-05-25 19:09:07'),
(99, 11, '2009-05-25 19:09:18'),
(100, 11, '2009-05-25 19:09:28'),
(101, 11, '2009-05-25 19:09:39'),
(102, 11, '2009-05-25 19:09:50'),
(103, 11, '2009-05-25 19:10:00'),
(104, 11, '2009-05-25 19:10:11'),
(105, 11, '2009-05-25 19:10:15'),
(106, 11, '2009-05-25 19:10:16'),
(107, 11, '2009-05-25 19:10:20'),
(108, 11, '2009-05-25 19:11:11'),
(109, 11, '2009-05-25 19:11:12'),
(110, 11, '2009-05-25 19:11:22'),
(111, 11, '2009-05-25 19:11:25'),
(112, 11, '2009-05-25 19:11:26'),
(113, 11, '2009-05-25 19:11:37'),
(114, 11, '2009-05-25 19:11:47'),
(115, 11, '2009-05-25 19:11:57'),
(116, 11, '2009-05-25 19:12:33'),
(117, 11, '2009-05-25 19:12:34'),
(118, 11, '2009-05-25 19:12:45'),
(119, 11, '2009-05-25 19:12:55'),
(120, 11, '2009-05-25 19:13:05'),
(121, 11, '2009-05-25 19:15:10'),
(122, 11, '2009-05-25 19:15:11'),
(123, 11, '2009-05-25 19:15:21'),
(124, 11, '2009-05-25 19:15:31'),
(125, 11, '2009-05-25 19:15:42'),
(126, 11, '2009-05-25 19:15:52'),
(127, 11, '2009-05-25 19:16:02'),
(128, 11, '2009-05-25 19:16:11'),
(129, 11, '2009-05-25 19:16:13'),
(130, 11, '2009-05-25 19:16:23'),
(131, 11, '2009-05-25 19:16:33'),
(132, 11, '2009-05-25 19:16:44'),
(133, 11, '2009-05-25 19:16:57'),
(134, 11, '2009-05-25 19:17:07'),
(135, 11, '2009-05-25 19:17:18'),
(136, 11, '2009-05-25 19:17:28'),
(137, 11, '2009-05-25 19:17:39'),
(138, 11, '2009-05-25 19:17:46'),
(139, 11, '2009-05-25 19:17:46'),
(140, 11, '2009-05-25 19:17:49'),
(141, 11, '2009-05-25 19:18:00'),
(142, 11, '2009-05-25 19:18:10'),
(143, 11, '2009-05-25 19:18:13'),
(144, 11, '2009-05-25 19:18:21'),
(145, 11, '2009-05-25 19:18:31'),
(146, 11, '2009-05-25 19:18:41'),
(147, 11, '2009-05-25 19:18:45'),
(148, 11, '2009-05-25 19:18:46'),
(149, 11, '2009-05-25 19:18:56'),
(150, 11, '2009-05-25 19:19:06'),
(151, 11, '2009-05-25 19:19:17'),
(152, 11, '2009-05-25 19:19:27'),
(153, 11, '2009-05-25 19:19:38'),
(154, 11, '2009-05-25 19:19:48'),
(155, 11, '2009-05-25 19:19:58'),
(156, 11, '2009-05-25 19:20:09'),
(157, 11, '2009-05-25 19:20:19'),
(158, 11, '2009-05-25 19:20:30'),
(159, 11, '2009-05-25 19:20:40'),
(160, 11, '2009-05-25 19:20:50'),
(161, 11, '2009-05-25 19:21:01'),
(162, 11, '2009-05-25 19:21:11'),
(163, 11, '2009-05-25 19:21:21'),
(164, 12, '2009-05-25 20:08:37'),
(165, 13, '2009-05-25 20:09:04'),
(166, 14, '2009-05-25 20:15:43'),
(167, 15, '2009-05-25 20:19:13'),
(168, 15, '2009-05-25 20:19:25'),
(169, 15, '2009-05-25 20:19:28'),
(170, 15, '2009-05-25 20:19:39'),
(171, 15, '2009-05-25 20:19:39'),
(172, 15, '2009-05-25 20:19:49'),
(173, 15, '2009-05-25 20:19:50'),
(174, 15, '2009-05-25 20:20:00'),
(175, 16, '2009-05-25 23:43:18'),
(176, 16, '2009-05-25 23:51:47'),
(177, 16, '2009-05-25 23:56:10'),
(178, 16, '2009-05-25 23:56:21'),
(179, 17, '2009-05-26 01:31:36'),
(180, 18, '2009-05-26 02:35:33'),
(181, 19, '2009-05-26 03:27:14'),
(182, 19, '2009-05-26 03:27:41'),
(183, 20, '2009-05-26 05:12:25'),
(184, 20, '2009-05-26 05:12:28'),
(185, 21, '2009-05-26 10:18:49'),
(186, 22, '2009-05-26 11:50:10'),
(187, 23, '2009-05-26 14:32:11'),
(188, 24, '2009-05-26 16:07:06'),
(189, 24, '2009-05-26 16:07:22'),
(190, 24, '2009-05-26 16:08:13'),
(191, 24, '2009-05-26 16:08:24'),
(192, 25, '2009-05-26 16:19:43'),
(193, 26, '2009-05-26 16:26:55'),
(194, 27, '2009-05-26 16:45:26');

DROP TABLE IF EXISTS `dxov_log_url_info`;
CREATE TABLE `dxov_log_url_info` (
  `url_id` bigint(20) unsigned NOT NULL auto_increment,
  `url` varchar(255) NOT NULL default '',
  `referer` varchar(255) default NULL,
  PRIMARY KEY  (`url_id`)
) ENGINE=MyISAM AUTO_INCREMENT=195 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Detale information about url visit';

INSERT INTO `dxov_log_url_info` VALUES
(1, 'http://www.thetennisdepot.com/index.php/', ''),
(2, 'http://www.thetennisdepot.com/', ''),
(3, 'http://www.thetennisdepot.com/about-magento-demo-store', 'http://www.thetennisdepot.com'),
(4, 'http://www.thetennisdepot.com/customer/account/login/', 'http://www.thetennisdepot.com/about-magento-demo-store'),
(5, 'http://www.thetennisdepot.com/customer/account/create/', ''),
(6, 'http://thetennisdepot.com/', ''),
(7, 'http://thetennisdepot.com/mail', ''),
(8, 'http://thetennisdepot.com/', ''),
(9, 'http://www.thetennisdepot.com/cart2cart/bridge.php?action=checkbridge&token=d607ba5a834ce780fad0e4d61d91656f&ver=9', ''),
(10, 'http://www.thetennisdepot.com/cart2cart/bridge.php?action=checkbridge&token=d607ba5a834ce780fad0e4d61d91656f&ver=9', ''),
(11, 'http://www.thetennisdepot.com/skin/adminhtml/default/default/tinymce_content.css', 'http://www.thetennisdepot.com/index.php/admin/catalog_product/new/set/4/type/simple/key/f6564500edf2da56c5067f3b74497901/'),
(12, 'http://www.thetennisdepot.com/skin/adminhtml/default/default/tinymce_content.css', 'http://www.thetennisdepot.com/index.php/admin/catalog_product/new/set/4/type/simple/key/f6564500edf2da56c5067f3b74497901/'),
(13, 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/dialog/skins/default/fck_dialog.css', 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/dialog/fck_template.html'),
(14, 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/dialog/skins/default/fck_dialog.css', 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/dialog/fck_form.html'),
(15, 'http://thetennisdepot.com/', ''),
(16, 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store', 'http://thetennisdepot.com/'),
(17, 'http://thetennisdepot.com/', ''),
(18, 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store', 'http://thetennisdepot.com/'),
(19, 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store', 'http://thetennisdepot.com/'),
(20, 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store', 'http://thetennisdepot.com/'),
(21, 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store', 'http://thetennisdepot.com/'),
(22, 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store', 'http://thetennisdepot.com/'),
(23, 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store', 'http://thetennisdepot.com/'),
(24, 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store', 'http://thetennisdepot.com/'),
(25, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=Hello!', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(26, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(27, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(28, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(29, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(30, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(31, 'http://www.thetennisdepot.com/skin/adminhtml/default/default/images/livechat/ajax-loader.gif', 'http://www.thetennisdepot.com/index.php/livechat/session_live/index/key/49ae899fe1e7525dc15f7e7d59dcbe0b/'),
(32, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(33, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(34, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(35, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=I%20am%20interested%20in%20the%20Big%20Ace', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(36, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(37, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(38, 'http://www.thetennisdepot.com/skin/adminhtml/default/default/images/livechat/ajax-loader.gif', 'http://www.thetennisdepot.com/index.php/livechat/session_live/index/key/49ae899fe1e7525dc15f7e7d59dcbe0b/'),
(39, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/skin/adminhtml/default/default/images/livechat/ajax-loader.gif'),
(40, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(41, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/skin/adminhtml/default/default/images/livechat/ajax-loader.gif'),
(42, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(43, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(44, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(45, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(46, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=1.15', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(47, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(48, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(49, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(50, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(51, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(52, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(53, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(54, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(55, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=what%20is%20the%20best%20string%20you%20have', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(56, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(57, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(58, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=please%20answer%20me!!', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(59, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(60, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(61, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(62, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(63, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(64, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(65, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(66, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=nope', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(67, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=I%20will%20place%20an%20order%20soon', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(68, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(69, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(70, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(71, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(72, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=bye', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(73, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(74, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(75, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(76, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(77, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(78, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(79, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(80, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(81, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=test', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(82, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=test', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(83, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(84, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(85, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(86, 'http://www.thetennisdepot.com/skin/adminhtml/default/default/images/livechat/ajax-loader.gif', 'http://www.thetennisdepot.com/index.php/livechat/session_live/index/key/49ae899fe1e7525dc15f7e7d59dcbe0b/'),
(87, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(88, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(89, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(90, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(91, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(92, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(93, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(94, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(95, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(96, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(97, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(98, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(99, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(100, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(101, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(102, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(103, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(104, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(105, 'http://www.thetennisdepot.com/', 'http://www.thetennisdepot.com/?SID=1097950acae6e92b80a5978a32abbaa6about-magento-demo-store'),
(106, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(107, 'http://www.thetennisdepot.com/customer/account/login/', 'http://www.thetennisdepot.com/'),
(108, 'http://www.thetennisdepot.com/', 'http://www.thetennisdepot.com/customer/account/login/'),
(109, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(110, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(111, 'http://www.thetennisdepot.com/', 'http://www.thetennisdepot.com/customer/account/login/'),
(112, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(113, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(114, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(115, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(116, 'http://www.thetennisdepot.com/', ''),
(117, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(118, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(119, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(120, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(121, 'http://www.thetennisdepot.com/', ''),
(122, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(123, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(124, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(125, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(126, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(127, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(128, 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/dialog/skins/default/fck_dialog.css', 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/dialog/fck_div.html'),
(129, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(130, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(131, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(132, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(133, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(134, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(135, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(136, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(137, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(138, 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/{{skin%20url=%27images/media/404_callout2.jpg%27}}', 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/fckeditor.html?InstanceName=page_content&Toolbar=Default'),
(139, 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/{{skin%20url=%27images/media/404_callout1.jpg%27}}', 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/fckeditor.html?InstanceName=page_content&Toolbar=Default'),
(140, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(141, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(142, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(143, 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/{{skin%20url=%27images/media/about_us_img.jpg%27}}', 'http://www.thetennisdepot.com/js/fontis/fckeditor/editor/fckeditor.html?InstanceName=page_content&Toolbar=Default'),
(144, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(145, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(146, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(147, 'http://www.thetennisdepot.com/contacts/', 'http://www.thetennisdepot.com'),
(148, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(149, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(150, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(151, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(152, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(153, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(154, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(155, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(156, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(157, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(158, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(159, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(160, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(161, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(162, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(163, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/contacts/'),
(164, 'http://thetennisdepot.com/', ''),
(165, 'http://www.thetennisdepot.com/?SID=c4f10c65a339829216585e9c5cd89ec1about-magento-demo-store', 'http://thetennisdepot.com/'),
(166, 'http://thetennisdepot.com/', ''),
(167, 'http://thetennisdepot.com/', ''),
(168, 'http://www.thetennisdepot.com/customer/account/login/', 'http://thetennisdepot.com/'),
(169, 'http://www.thetennisdepot.com/', 'http://www.thetennisdepot.com/customer/account/login/'),
(170, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=hello', 'http://www.thetennisdepot.com/'),
(171, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(172, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(173, 'http://www.thetennisdepot.com/flivechat/chat/sendmessage/store_id/1/?message=shprits', 'http://www.thetennisdepot.com/'),
(174, 'http://www.thetennisdepot.com/flivechat/chat/getMessageSession/store_id/1/', 'http://www.thetennisdepot.com/'),
(175, 'http://www.thetennisdepot.com/', ''),
(176, 'http://www.thetennisdepot.com/customer/account/login/', 'http://www.thetennisdepot.com/'),
(177, 'http://www.thetennisdepot.com/checkout/cart/', 'http://www.thetennisdepot.com/customer/account/login/'),
(178, 'http://www.thetennisdepot.com/', 'http://www.thetennisdepot.com/checkout/cart/'),
(179, 'http://www.thetennisdepot.com/', ''),
(180, 'http://www.thetennisdepot.com/', 'http://mail.google.com/a/asia-connect.com.vn/?ui=2&view=bsp&ver=1qygpcgurkovy'),
(181, 'http://www.thetennisdepot.com/', ''),
(182, 'http://www.thetennisdepot.com/contacts/', 'http://www.thetennisdepot.com/'),
(183, 'http://www.thetennisdepot.com/', ''),
(184, 'http://www.thetennisdepot.com/', ''),
(185, 'http://www.thetennisdepot.com/cart2cart/bridge.php?action=checkbridge&token=d607ba5a834ce780fad0e4d61d91656f&ver=9', ''),
(186, 'http://thetennisdepot.com/', ''),
(187, 'http://www.thetennisdepot.com/', ''),
(188, 'http://www.thetennisdepot.com/', 'http://app.shopping-cart-migration.com/migrations/wizard/?wid=1243352967'),
(189, 'http://www.thetennisdepot.com/catalog/category/view/s/kirschbaum/id/4/', 'http://www.thetennisdepot.com/'),
(190, 'http://www.thetennisdepot.com/catalog/category/view/s/tennis-strings/id/3/', 'http://www.thetennisdepot.com/catalog/category/view/s/kirschbaum/id/4/'),
(191, 'http://www.thetennisdepot.com/catalog/category/view/s/kirschbaum/id/4/', 'http://www.thetennisdepot.com/catalog/category/view/s/tennis-strings/id/3/'),
(192, 'http://thetennisdepot.com/', ''),
(193, 'http://thetennisdepot.com/robots.txt', ''),
(194, 'http://thetennisdepot.com/robots.txt', '');

DROP TABLE IF EXISTS `dxov_log_visitor`;
CREATE TABLE `dxov_log_visitor` (
  `visitor_id` bigint(20) unsigned NOT NULL auto_increment,
  `session_id` char(64) NOT NULL default '',
  `first_visit_at` datetime default NULL,
  `last_visit_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_url_id` bigint(20) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`visitor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='System visitors log';

INSERT INTO `dxov_log_visitor` VALUES
(1, 'a612cb1a855c6727b1d68da36f1c8f1d', '2009-05-25 13:46:25', '2009-05-25 13:47:29', 5, 1),
(2, '45c6e08096a0a15a1974485f20732ad3', '2009-05-25 14:13:45', '2009-05-25 14:14:18', 7, 1),
(3, 'ef59afa5265c4cf709c8634bb3020fa7', '2009-05-25 14:40:21', '2009-05-25 14:40:21', 8, 1),
(4, 'da9a9b886e191cd2552a9d274d8a68cb', '2009-05-25 16:43:28', '2009-05-25 16:43:28', 9, 1),
(5, 'd9a6449a9023de8fb35333d178d34112', '2009-05-25 16:43:34', '2009-05-25 16:43:34', 10, 1),
(6, 'e979279aa5fcd97f63f3bc2cc082b4a5', '2009-05-25 17:25:32', '2009-05-25 17:25:32', 11, 1),
(7, 'b3399b62f74578b24155e265edd2b519', '2009-05-25 17:25:32', '2009-05-25 17:29:07', 14, 1),
(8, '1097950acae6e92b80a5978a32abbaa6', '2009-05-25 17:47:07', '2009-05-25 17:47:07', 15, 1),
(9, '1097950acae6e92b80a5978a32abbaa6about-magento-demo-store', '2009-05-25 17:47:13', '2009-05-25 17:55:33', 18, 1),
(10, '7a8e41db37249ea1faf3750d293ed399', '2009-05-25 17:49:38', '2009-05-25 17:49:38', 17, 1),
(11, '1097950acae6e92b80a5978a32abbaa6about-magento-demo-store', '2009-05-25 18:34:15', '2009-05-25 19:21:21', 163, 1),
(12, 'c4f10c65a339829216585e9c5cd89ec1', '2009-05-25 20:08:37', '2009-05-25 20:08:37', 164, 1),
(13, 'c4f10c65a339829216585e9c5cd89ec1about-magento-demo-store', '2009-05-25 20:09:04', '2009-05-25 20:09:04', 165, 1),
(14, '6f5a58402d692ed536bc4fd491b4dd43', '2009-05-25 20:15:43', '2009-05-25 20:15:43', 166, 1),
(15, 'ef97e949990375682f1cbd679e96b431', '2009-05-25 20:19:12', '2009-05-25 20:20:00', 174, 1),
(16, 'e22a26cf86256af230e9cde70f9a7102', '2009-05-25 23:43:18', '2009-05-25 23:56:21', 178, 1),
(17, '506c95ce3612aedd707e4a1d35d811f8', '2009-05-26 01:31:36', '2009-05-26 01:31:36', 179, 1),
(18, 'b031424640917275de738c17dbe09fce', '2009-05-26 02:35:33', '2009-05-26 02:35:33', 180, 1),
(19, 'dce4e9ec434a9c945fd7fdcbbee75a2c', '2009-05-26 03:27:14', '2009-05-26 03:27:41', 182, 1),
(20, '32cd7ba5a86ef31ef23a0cbb7dec24e1', '2009-05-26 05:12:25', '2009-05-26 05:12:28', 184, 1),
(21, '4d94d4ec8fb9bff5c00456e84b1a6331', '2009-05-26 10:18:49', '2009-05-26 10:18:49', 185, 1),
(22, '9152dfb9305137f08e7946a0d234be05', '2009-05-26 11:50:10', '2009-05-26 11:50:10', 186, 1),
(23, 'be9685ba27bbf5036a93b0b449c0b8e1', '2009-05-26 14:32:11', '2009-05-26 14:32:11', 187, 1),
(24, '499b657500a8627c6ce12223982a91a8', '2009-05-26 16:07:05', '2009-05-26 16:08:24', 191, 1),
(25, 'e95d3be96f13da2ead755c1ac17d9468', '2009-05-26 16:19:43', '2009-05-26 16:19:43', 192, 1),
(26, '75e717de021a15cae515d2134948b8c7', '2009-05-26 16:26:55', '2009-05-26 16:26:55', 193, 1),
(27, 'df6e645602b6d21aa8fdd17702a081be', '2009-05-26 16:45:26', '2009-05-26 16:45:26', 194, 1);

DROP TABLE IF EXISTS `dxov_log_visitor_info`;
CREATE TABLE `dxov_log_visitor_info` (
  `visitor_id` bigint(20) unsigned NOT NULL default '0',
  `http_referer` varchar(255) default NULL,
  `http_user_agent` varchar(255) default NULL,
  `http_accept_charset` varchar(255) default NULL,
  `http_accept_language` varchar(255) default NULL,
  `server_addr` bigint(20) default NULL,
  `remote_addr` bigint(20) default NULL,
  PRIMARY KEY  (`visitor_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Additional information by visitor';

INSERT INTO `dxov_log_visitor_info` VALUES
(1, '', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '', 'en-us', 1138544690, 2922382233),
(2, '', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '', 'en-us', 1138544690, 2922382233),
(3, '', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/2.0.0.12;MEGAUPLOAD 1.0', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 1138544690, 3411169125),
(4, '', '', '', '', 1138544690, 1546675865),
(5, '', '', '', '', 1138544690, 1546675865),
(6, 'http://www.thetennisdepot.com/index.php/admin/catalog_product/new/set/4/type/simple/key/f6564500edf2da56c5067f3b74497901/', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '', 'en-us', 1138544690, 2922382233),
(7, 'http://www.thetennisdepot.com/index.php/admin/catalog_product/new/set/4/type/simple/key/f6564500edf2da56c5067f3b74497901/', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '', 'en-us', 1138544690, 2922382233),
(8, '', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '', 'en-us', 1138544690, 2922382233),
(9, 'http://thetennisdepot.com/', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '', 'en-us', 1138544690, 2922382233),
(10, '', 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)', '', '', 1138544690, 1659381641),
(11, 'http://thetennisdepot.com/', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '', 'en-us', 1138544690, 2922382233),
(12, '', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)', '', 'en-us', 1138544690, 2922382233),
(13, 'http://thetennisdepot.com/', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)', '', 'en-us', 1138544690, 2922382233),
(14, '', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '', 'en-us', 1138544690, 2922382233),
(15, '', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; GTB6; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; InfoPath.2)', '', 'en-us', 1138544690, 2922382233),
(16, '', 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1b4pre) Gecko/20090401 Ubuntu/9.04 (jaunty) Shiretoko/3.5b4pre', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 1138544690, 3196727236),
(17, '', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '', 'en-us', 1138544690, 2922382233),
(18, 'http://mail.google.com/a/asia-connect.com.vn/?ui=2&view=bsp&ver=1qygpcgurkovy', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 1138544690, 2065224387),
(19, '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.1) Gecko/2008070208 Firefox/3.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 1138544690, 1975796517),
(20, '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 1138544690, 2006521572),
(21, '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; uk; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10', 'windows-1251,utf-8;q=0.7,*;q=0.7', 'uk,ru;q=0.8,en-us;q=0.5,en;q=0.3', 1138544690, 3267093651),
(22, '', 'Opera/9.64 (Windows NT 6.0; U; en) Presto/2.1.1', 'iso-8859-1, utf-8, utf-16, *;q=0.1', 'en-MY,en;q=0.9', 1138544690, 3411169125),
(23, '', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 1.1.4322; .NET CLR 3.5.30729; .NET CLR 3.0.30618)', '', 'uk', 1138544690, 1539596823),
(24, 'http://app.shopping-cart-migration.com/migrations/wizard/?wid=1243352967', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 1138544690, 2922382233),
(25, '', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; GTB6; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; InfoPath.2)', '', 'en-us', 1138544690, 2922382233),
(26, '', 'ia_archiver-web.archive.org', '', '', 1138544690, 3488736075),
(27, '', 'ia_archiver-web.archive.org', '', '', 1138544690, 3488736091);

DROP TABLE IF EXISTS `dxov_log_visitor_online`;
CREATE TABLE `dxov_log_visitor_online` (
  `visitor_id` bigint(20) unsigned NOT NULL auto_increment,
  `visitor_type` char(1) NOT NULL,
  `remote_addr` bigint(20) NOT NULL,
  `first_visit_at` datetime default NULL,
  `last_visit_at` datetime default NULL,
  `customer_id` int(10) unsigned default NULL,
  `last_url` varchar(255) default NULL,
  PRIMARY KEY  (`visitor_id`),
  KEY `IDX_VISITOR_TYPE` (`visitor_type`),
  KEY `IDX_VISIT_TIME` (`first_visit_at`,`last_visit_at`),
  KEY `IDX_CUSTOMER` (`customer_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_newsletter_problem`;
CREATE TABLE `dxov_newsletter_problem` (
  `problem_id` int(7) unsigned NOT NULL auto_increment,
  `subscriber_id` int(7) unsigned default NULL,
  `queue_id` int(7) unsigned NOT NULL default '0',
  `problem_error_code` int(3) unsigned default '0',
  `problem_error_text` varchar(200) default NULL,
  PRIMARY KEY  (`problem_id`),
  KEY `FK_PROBLEM_SUBSCRIBER` (`subscriber_id`),
  KEY `FK_PROBLEM_QUEUE` (`queue_id`),
  CONSTRAINT `FK_PROBLEM_QUEUE` FOREIGN KEY (`queue_id`) REFERENCES `dxov_newsletter_queue` (`queue_id`),
  CONSTRAINT `FK_PROBLEM_SUBSCRIBER` FOREIGN KEY (`subscriber_id`) REFERENCES `dxov_newsletter_subscriber` (`subscriber_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Newsletter problems';

DROP TABLE IF EXISTS `dxov_newsletter_queue`;
CREATE TABLE `dxov_newsletter_queue` (
  `queue_id` int(7) unsigned NOT NULL auto_increment,
  `template_id` int(7) unsigned NOT NULL default '0',
  `queue_status` int(3) unsigned NOT NULL default '0',
  `queue_start_at` datetime default NULL,
  `queue_finish_at` datetime default NULL,
  PRIMARY KEY  (`queue_id`),
  KEY `FK_QUEUE_TEMPLATE` (`template_id`),
  CONSTRAINT `FK_QUEUE_TEMPLATE` FOREIGN KEY (`template_id`) REFERENCES `dxov_newsletter_template` (`template_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Newsletter queue';

DROP TABLE IF EXISTS `dxov_newsletter_queue_link`;
CREATE TABLE `dxov_newsletter_queue_link` (
  `queue_link_id` int(9) unsigned NOT NULL auto_increment,
  `queue_id` int(7) unsigned NOT NULL default '0',
  `subscriber_id` int(7) unsigned NOT NULL default '0',
  `letter_sent_at` datetime default NULL,
  PRIMARY KEY  (`queue_link_id`),
  KEY `FK_QUEUE_LINK_SUBSCRIBER` (`subscriber_id`),
  KEY `FK_QUEUE_LINK_QUEUE` (`queue_id`),
  CONSTRAINT `FK_QUEUE_LINK_QUEUE` FOREIGN KEY (`queue_id`) REFERENCES `dxov_newsletter_queue` (`queue_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_QUEUE_LINK_SUBSCRIBER` FOREIGN KEY (`subscriber_id`) REFERENCES `dxov_newsletter_subscriber` (`subscriber_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Newsletter queue to subscriber link';

DROP TABLE IF EXISTS `dxov_newsletter_queue_store_link`;
CREATE TABLE `dxov_newsletter_queue_store_link` (
  `queue_id` int(7) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`queue_id`,`store_id`),
  KEY `FK_NEWSLETTER_QUEUE_STORE_LINK_STORE` (`store_id`),
  CONSTRAINT `FK_NEWSLETTER_QUEUE_STORE_LINK_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_LINK_QUEUE` FOREIGN KEY (`queue_id`) REFERENCES `dxov_newsletter_queue` (`queue_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_newsletter_subscriber`;
CREATE TABLE `dxov_newsletter_subscriber` (
  `subscriber_id` int(7) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned default '0',
  `change_status_at` datetime default NULL,
  `customer_id` int(11) unsigned NOT NULL default '0',
  `subscriber_email` varchar(150) /*!40101 character set latin1 */ /*!40101 collate latin1_general_ci */ NOT NULL default '',
  `subscriber_status` int(3) NOT NULL default '0',
  `subscriber_confirm_code` varchar(32) default 'NULL',
  PRIMARY KEY  (`subscriber_id`),
  KEY `FK_SUBSCRIBER_CUSTOMER` (`customer_id`),
  KEY `FK_NEWSLETTER_SUBSCRIBER_STORE` (`store_id`),
  CONSTRAINT `FK_NEWSLETTER_SUBSCRIBER_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Newsletter subscribers';

DROP TABLE IF EXISTS `dxov_newsletter_template`;
CREATE TABLE `dxov_newsletter_template` (
  `template_id` int(7) unsigned NOT NULL auto_increment,
  `template_code` varchar(150) default NULL,
  `template_text` text,
  `template_text_preprocessed` text,
  `template_type` int(3) unsigned default NULL,
  `template_subject` varchar(200) default NULL,
  `template_sender_name` varchar(200) default NULL,
  `template_sender_email` varchar(200) /*!40101 character set latin1 */ /*!40101 collate latin1_general_ci */ default NULL,
  `template_actual` tinyint(1) unsigned default '1',
  `added_at` datetime default NULL,
  `modified_at` datetime default NULL,
  PRIMARY KEY  (`template_id`),
  KEY `template_actual` (`template_actual`),
  KEY `added_at` (`added_at`),
  KEY `modified_at` (`modified_at`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Newsletter templates';

DROP TABLE IF EXISTS `dxov_paygate_authorizenet_debug`;
CREATE TABLE `dxov_paygate_authorizenet_debug` (
  `debug_id` int(10) unsigned NOT NULL auto_increment,
  `request_body` text,
  `response_body` text,
  `request_serialized` text,
  `result_serialized` text,
  `request_dump` text,
  `result_dump` text,
  PRIMARY KEY  (`debug_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_paypal_api_debug`;
CREATE TABLE `dxov_paypal_api_debug` (
  `debug_id` int(10) unsigned NOT NULL auto_increment,
  `debug_at` timestamp NOT NULL /*!40101 default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP */,
  `request_body` text,
  `response_body` text,
  PRIMARY KEY  (`debug_id`),
  KEY `debug_at` (`debug_at`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_paypaluk_api_debug`;
CREATE TABLE `dxov_paypaluk_api_debug` (
  `debug_id` int(10) unsigned NOT NULL auto_increment,
  `debug_at` timestamp NOT NULL /*!40101 default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP */,
  `request_body` text,
  `response_body` text,
  PRIMARY KEY  (`debug_id`),
  KEY `debug_at` (`debug_at`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_poll`;
CREATE TABLE `dxov_poll` (
  `poll_id` int(10) unsigned NOT NULL auto_increment,
  `poll_title` varchar(255) NOT NULL default '',
  `votes_count` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned default '0',
  `date_posted` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_closed` datetime default NULL,
  `active` smallint(6) NOT NULL default '1',
  `closed` tinyint(1) NOT NULL default '0',
  `answers_display` smallint(6) default NULL,
  PRIMARY KEY  (`poll_id`),
  KEY `FK_POLL_STORE` (`store_id`),
  CONSTRAINT `FK_POLL_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_poll_answer`;
CREATE TABLE `dxov_poll_answer` (
  `answer_id` int(10) unsigned NOT NULL auto_increment,
  `poll_id` int(10) unsigned NOT NULL default '0',
  `answer_title` varchar(255) NOT NULL default '',
  `votes_count` int(10) unsigned NOT NULL default '0',
  `answer_order` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`answer_id`),
  KEY `FK_POLL_PARENT` (`poll_id`),
  CONSTRAINT `FK_POLL_PARENT` FOREIGN KEY (`poll_id`) REFERENCES `dxov_poll` (`poll_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_poll_store`;
CREATE TABLE `dxov_poll_store` (
  `poll_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`poll_id`,`store_id`),
  KEY `FK_POLL_STORE_STORE` (`store_id`),
  CONSTRAINT `FK_POLL_STORE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_POLL_STORE_POLL` FOREIGN KEY (`poll_id`) REFERENCES `dxov_poll` (`poll_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_poll_vote`;
CREATE TABLE `dxov_poll_vote` (
  `vote_id` int(10) unsigned NOT NULL auto_increment,
  `poll_id` int(10) unsigned NOT NULL default '0',
  `poll_answer_id` int(10) unsigned NOT NULL default '0',
  `ip_address` bigint(20) default NULL,
  `customer_id` int(11) default NULL,
  `vote_time` timestamp NOT NULL /*!40101 default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP */,
  PRIMARY KEY  (`vote_id`),
  KEY `FK_POLL_ANSWER` (`poll_answer_id`),
  CONSTRAINT `FK_POLL_ANSWER` FOREIGN KEY (`poll_answer_id`) REFERENCES `dxov_poll_answer` (`answer_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_product_alert_price`;
CREATE TABLE `dxov_product_alert_price` (
  `alert_price_id` int(10) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `add_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_send_date` datetime default NULL,
  `send_count` smallint(5) unsigned NOT NULL default '0',
  `status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`alert_price_id`),
  KEY `FK_PRODUCT_ALERT_PRICE_CUSTOMER` (`customer_id`),
  KEY `FK_PRODUCT_ALERT_PRICE_PRODUCT` (`product_id`),
  KEY `FK_PRODUCT_ALERT_PRICE_WEBSITE` (`website_id`),
  CONSTRAINT `FK_PRODUCT_ALERT_PRICE_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PRODUCT_ALERT_PRICE_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PRODUCT_ALERT_PRICE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_product_alert_stock`;
CREATE TABLE `dxov_product_alert_stock` (
  `alert_stock_id` int(10) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `add_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `send_date` datetime default NULL,
  `send_count` smallint(5) unsigned NOT NULL default '0',
  `status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`alert_stock_id`),
  KEY `FK_PRODUCT_ALERT_STOCK_CUSTOMER` (`customer_id`),
  KEY `FK_PRODUCT_ALERT_STOCK_PRODUCT` (`product_id`),
  KEY `FK_PRODUCT_ALERT_STOCK_WEBSITE` (`website_id`),
  CONSTRAINT `FK_PRODUCT_ALERT_STOCK_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PRODUCT_ALERT_STOCK_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PRODUCT_ALERT_STOCK_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_rating`;
CREATE TABLE `dxov_rating` (
  `rating_id` smallint(6) unsigned NOT NULL auto_increment,
  `entity_id` smallint(6) unsigned NOT NULL default '0',
  `rating_code` varchar(64) NOT NULL default '',
  `position` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`rating_id`),
  UNIQUE KEY `IDX_CODE` (`rating_code`),
  KEY `FK_RATING_ENTITY` (`entity_id`),
  CONSTRAINT `FK_RATING_ENTITY_KEY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_rating_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='ratings';

INSERT INTO `dxov_rating` VALUES
(1, 1, 'Quality', 0),
(2, 1, 'Value', 0),
(3, 1, 'Price', 0);

DROP TABLE IF EXISTS `dxov_rating_entity`;
CREATE TABLE `dxov_rating_entity` (
  `entity_id` smallint(6) unsigned NOT NULL auto_increment,
  `entity_code` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`entity_id`),
  UNIQUE KEY `IDX_CODE` (`entity_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Rating entities';

INSERT INTO `dxov_rating_entity` VALUES
(1, 'product'),
(2, 'product_review'),
(3, 'review');

DROP TABLE IF EXISTS `dxov_rating_option`;
CREATE TABLE `dxov_rating_option` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `rating_id` smallint(6) unsigned NOT NULL default '0',
  `code` varchar(32) NOT NULL default '',
  `value` tinyint(3) unsigned NOT NULL default '0',
  `position` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`option_id`),
  KEY `FK_RATING_OPTION_RATING` (`rating_id`),
  CONSTRAINT `FK_RATING_OPTION_RATING` FOREIGN KEY (`rating_id`) REFERENCES `dxov_rating` (`rating_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Rating options';

INSERT INTO `dxov_rating_option` VALUES
(1, 1, '1', 1, 1),
(2, 1, '2', 2, 2),
(3, 1, '3', 3, 3),
(4, 1, '4', 4, 4),
(5, 1, '5', 5, 5),
(6, 2, '1', 1, 1),
(7, 2, '2', 2, 2),
(8, 2, '3', 3, 3),
(9, 2, '4', 4, 4),
(10, 2, '5', 5, 5),
(11, 3, '1', 1, 1),
(12, 3, '2', 2, 2),
(13, 3, '3', 3, 3),
(14, 3, '4', 4, 4),
(15, 3, '5', 5, 5);

DROP TABLE IF EXISTS `dxov_rating_option_vote`;
CREATE TABLE `dxov_rating_option_vote` (
  `vote_id` bigint(20) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL default '0',
  `remote_ip` varchar(16) NOT NULL default '',
  `remote_ip_long` int(11) NOT NULL default '0',
  `customer_id` int(11) unsigned default '0',
  `entity_pk_value` bigint(20) unsigned NOT NULL default '0',
  `rating_id` smallint(6) unsigned NOT NULL default '0',
  `review_id` bigint(20) unsigned default NULL,
  `percent` tinyint(3) NOT NULL default '0',
  `value` tinyint(3) NOT NULL default '0',
  PRIMARY KEY  (`vote_id`),
  KEY `FK_RATING_OPTION_VALUE_OPTION` (`option_id`),
  KEY `FK_RATING_OPTION_REVIEW_ID` (`review_id`),
  CONSTRAINT `FK_RATING_OPTION_REVIEW_ID` FOREIGN KEY (`review_id`) REFERENCES `dxov_review` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_RATING_OPTION_VALUE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `dxov_rating_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Rating option values';

DROP TABLE IF EXISTS `dxov_rating_option_vote_aggregated`;
CREATE TABLE `dxov_rating_option_vote_aggregated` (
  `primary_id` int(11) NOT NULL auto_increment,
  `rating_id` smallint(6) unsigned NOT NULL default '0',
  `entity_pk_value` bigint(20) unsigned NOT NULL default '0',
  `vote_count` int(10) unsigned NOT NULL default '0',
  `vote_value_sum` int(10) unsigned NOT NULL default '0',
  `percent` tinyint(3) NOT NULL default '0',
  `percent_approved` tinyint(3) default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`primary_id`),
  KEY `FK_RATING_OPTION_VALUE_AGGREGATE` (`rating_id`),
  KEY `FK_RATING_OPTION_VOTE_AGGREGATED_STORE` (`store_id`),
  CONSTRAINT `FK_RATING_OPTION_VALUE_AGGREGATE` FOREIGN KEY (`rating_id`) REFERENCES `dxov_rating` (`rating_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_RATING_OPTION_VOTE_AGGREGATED_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_rating_store`;
CREATE TABLE `dxov_rating_store` (
  `rating_id` smallint(6) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`rating_id`,`store_id`),
  KEY `FK_RATING_STORE_STORE` (`store_id`),
  CONSTRAINT `FK_RATING_STORE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_RATING_STORE_RATING` FOREIGN KEY (`rating_id`) REFERENCES `dxov_rating` (`rating_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_rating_title`;
CREATE TABLE `dxov_rating_title` (
  `rating_id` smallint(6) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`rating_id`,`store_id`),
  KEY `FK_RATING_TITLE_STORE` (`store_id`),
  CONSTRAINT `FK_RATING_TITLE` FOREIGN KEY (`rating_id`) REFERENCES `dxov_rating` (`rating_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_RATING_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_report_event`;
CREATE TABLE `dxov_report_event` (
  `event_id` bigint(20) unsigned NOT NULL auto_increment,
  `logged_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `event_type_id` smallint(6) unsigned NOT NULL default '0',
  `object_id` int(10) unsigned NOT NULL default '0',
  `subject_id` int(10) unsigned NOT NULL default '0',
  `subtype` tinyint(3) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`event_id`),
  KEY `IDX_EVENT_TYPE` (`event_type_id`),
  KEY `IDX_SUBJECT` (`subject_id`),
  KEY `IDX_OBJECT` (`object_id`),
  KEY `IDX_SUBTYPE` (`subtype`),
  KEY `FK_REPORT_EVENT_STORE` (`store_id`),
  CONSTRAINT `FK_REPORT_EVENT_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REPORT_EVENT_TYPE` FOREIGN KEY (`event_type_id`) REFERENCES `dxov_report_event_types` (`event_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_report_event_types`;
CREATE TABLE `dxov_report_event_types` (
  `event_type_id` smallint(6) unsigned NOT NULL auto_increment,
  `event_name` varchar(64) NOT NULL,
  `customer_login` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`event_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_report_event_types` VALUES
(1, 'catalog_product_view', 1),
(2, 'sendfriend_product', 1),
(3, 'catalog_product_compare_add_product', 1),
(4, 'checkout_cart_add_product', 1),
(5, 'wishlist_add_product', 1),
(6, 'wishlist_share', 1);

DROP TABLE IF EXISTS `dxov_review`;
CREATE TABLE `dxov_review` (
  `review_id` bigint(20) unsigned NOT NULL auto_increment,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `entity_id` smallint(5) unsigned NOT NULL default '0',
  `entity_pk_value` int(10) unsigned NOT NULL default '0',
  `status_id` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`review_id`),
  KEY `FK_REVIEW_ENTITY` (`entity_id`),
  KEY `FK_REVIEW_STATUS` (`status_id`),
  KEY `FK_REVIEW_PARENT_PRODUCT` (`entity_pk_value`),
  CONSTRAINT `FK_REVIEW_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_review_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REVIEW_PARENT_PRODUCT` FOREIGN KEY (`entity_pk_value`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REVIEW_STATUS` FOREIGN KEY (`status_id`) REFERENCES `dxov_review_status` (`status_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Review base information';

DROP TABLE IF EXISTS `dxov_review_detail`;
CREATE TABLE `dxov_review_detail` (
  `detail_id` bigint(20) unsigned NOT NULL auto_increment,
  `review_id` bigint(20) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned default '0',
  `title` varchar(255) NOT NULL default '',
  `detail` text NOT NULL,
  `nickname` varchar(128) NOT NULL default '',
  `customer_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`detail_id`),
  KEY `FK_REVIEW_DETAIL_REVIEW` (`review_id`),
  KEY `FK_REVIEW_DETAIL_STORE` (`store_id`),
  CONSTRAINT `FK_REVIEW_DETAIL_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_REVIEW_DETAIL_REVIEW` FOREIGN KEY (`review_id`) REFERENCES `dxov_review` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Review detail information';

DROP TABLE IF EXISTS `dxov_review_entity`;
CREATE TABLE `dxov_review_entity` (
  `entity_id` smallint(5) unsigned NOT NULL auto_increment,
  `entity_code` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`entity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Review entities';

INSERT INTO `dxov_review_entity` VALUES
(1, 'product'),
(2, 'customer'),
(3, 'category');

DROP TABLE IF EXISTS `dxov_review_entity_summary`;
CREATE TABLE `dxov_review_entity_summary` (
  `primary_id` bigint(20) NOT NULL auto_increment,
  `entity_pk_value` bigint(20) NOT NULL default '0',
  `entity_type` tinyint(4) NOT NULL default '0',
  `reviews_count` smallint(6) NOT NULL default '0',
  `rating_summary` tinyint(4) NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`primary_id`),
  KEY `FK_REVIEW_ENTITY_SUMMARY_STORE` (`store_id`),
  CONSTRAINT `FK_REVIEW_ENTITY_SUMMARY_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_review_status`;
CREATE TABLE `dxov_review_status` (
  `status_id` tinyint(3) unsigned NOT NULL auto_increment,
  `status_code` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Review statuses';

INSERT INTO `dxov_review_status` VALUES
(1, 'Approved'),
(2, 'Pending'),
(3, 'Not Approved');

DROP TABLE IF EXISTS `dxov_review_store`;
CREATE TABLE `dxov_review_store` (
  `review_id` bigint(20) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`review_id`,`store_id`),
  KEY `FK_REVIEW_STORE_STORE` (`store_id`),
  CONSTRAINT `FK_REVIEW_STORE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REVIEW_STORE_REVIEW` FOREIGN KEY (`review_id`) REFERENCES `dxov_review` (`review_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_flat_order_item`;
CREATE TABLE `dxov_sales_flat_order_item` (
  `item_id` int(10) unsigned NOT NULL auto_increment,
  `order_id` int(10) unsigned NOT NULL default '0',
  `parent_item_id` int(10) unsigned default NULL,
  `quote_item_id` int(10) unsigned default NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `product_id` int(10) unsigned default NULL,
  `product_type` varchar(255) default NULL,
  `product_options` text,
  `weight` decimal(12,4) default '0.0000',
  `is_virtual` tinyint(1) unsigned default NULL,
  `sku` varchar(255) NOT NULL default '',
  `name` varchar(255) default NULL,
  `description` text,
  `applied_rule_ids` text,
  `additional_data` text,
  `free_shipping` tinyint(1) unsigned NOT NULL default '0',
  `is_qty_decimal` tinyint(1) unsigned default NULL,
  `no_discount` tinyint(1) unsigned default '0',
  `qty_backordered` decimal(12,4) default '0.0000',
  `qty_canceled` decimal(12,4) default '0.0000',
  `qty_invoiced` decimal(12,4) default '0.0000',
  `qty_ordered` decimal(12,4) default '0.0000',
  `qty_refunded` decimal(12,4) default '0.0000',
  `qty_shipped` decimal(12,4) default '0.0000',
  `cost` decimal(12,4) default '0.0000',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `base_price` decimal(12,4) NOT NULL default '0.0000',
  `original_price` decimal(12,4) default NULL,
  `base_original_price` decimal(12,4) default NULL,
  `tax_percent` decimal(12,4) default '0.0000',
  `tax_amount` decimal(12,4) default '0.0000',
  `base_tax_amount` decimal(12,4) default '0.0000',
  `tax_invoiced` decimal(12,4) default '0.0000',
  `base_tax_invoiced` decimal(12,4) default '0.0000',
  `discount_percent` decimal(12,4) default '0.0000',
  `discount_amount` decimal(12,4) default '0.0000',
  `base_discount_amount` decimal(12,4) default '0.0000',
  `discount_invoiced` decimal(12,4) default '0.0000',
  `base_discount_invoiced` decimal(12,4) default '0.0000',
  `amount_refunded` decimal(12,4) default '0.0000',
  `base_amount_refunded` decimal(12,4) default '0.0000',
  `row_total` decimal(12,4) NOT NULL default '0.0000',
  `base_row_total` decimal(12,4) NOT NULL default '0.0000',
  `row_invoiced` decimal(12,4) NOT NULL default '0.0000',
  `base_row_invoiced` decimal(12,4) NOT NULL default '0.0000',
  `row_weight` decimal(12,4) default '0.0000',
  `gift_message_id` int(10) default NULL,
  `gift_message_available` int(10) default NULL,
  `base_tax_before_discount` decimal(12,4) default NULL,
  `tax_before_discount` decimal(12,4) default NULL,
  `ext_order_item_id` varchar(255) default NULL,
  `weee_tax_applied` text,
  `weee_tax_applied_amount` decimal(12,4) default NULL,
  `weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `base_weee_tax_applied_amount` decimal(12,4) default NULL,
  `base_weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `weee_tax_disposition` decimal(12,4) default NULL,
  `weee_tax_row_disposition` decimal(12,4) default NULL,
  `base_weee_tax_disposition` decimal(12,4) default NULL,
  `base_weee_tax_row_disposition` decimal(12,4) default NULL,
  PRIMARY KEY  (`item_id`),
  KEY `IDX_ORDER` (`order_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_flat_quote`;
CREATE TABLE `dxov_sales_flat_quote` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `converted_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `is_active` tinyint(1) unsigned default '1',
  `is_virtual` tinyint(1) unsigned default '0',
  `is_multi_shipping` tinyint(1) unsigned default '0',
  `items_count` int(10) unsigned default '0',
  `items_qty` decimal(12,4) default '0.0000',
  `orig_order_id` int(10) unsigned default '0',
  `store_to_base_rate` decimal(12,4) default '0.0000',
  `store_to_quote_rate` decimal(12,4) default '0.0000',
  `base_currency_code` varchar(255) default NULL,
  `store_currency_code` varchar(255) default NULL,
  `quote_currency_code` varchar(255) default NULL,
  `grand_total` decimal(12,4) default '0.0000',
  `base_grand_total` decimal(12,4) default '0.0000',
  `checkout_method` varchar(255) default NULL,
  `customer_id` int(10) unsigned default '0',
  `customer_tax_class_id` int(10) unsigned default '0',
  `customer_group_id` int(10) unsigned default '0',
  `customer_email` varchar(255) default NULL,
  `customer_prefix` varchar(40) default NULL,
  `customer_firstname` varchar(255) default NULL,
  `customer_middlename` varchar(40) default NULL,
  `customer_lastname` varchar(255) default NULL,
  `customer_suffix` varchar(40) default NULL,
  `customer_dob` datetime default NULL,
  `customer_note` varchar(255) default NULL,
  `customer_note_notify` tinyint(1) unsigned default '1',
  `customer_is_guest` tinyint(1) unsigned default '0',
  `remote_ip` varchar(32) default NULL,
  `applied_rule_ids` varchar(255) default NULL,
  `reserved_order_id` varchar(64) default '',
  `password_hash` varchar(255) default NULL,
  `coupon_code` varchar(255) default NULL,
  `quote_status_id` varchar(255) default NULL,
  `billing_address_id` varchar(255) default NULL,
  `global_currency_code` varchar(255) default NULL,
  `base_to_global_rate` decimal(12,4) default NULL,
  `base_to_quote_rate` decimal(12,4) default NULL,
  `custbalance_amount` varchar(255) default NULL,
  `is_multi_payment` varchar(255) default NULL,
  `customer_taxvat` varchar(255) default NULL,
  `subtotal` decimal(12,4) default NULL,
  `base_subtotal` decimal(12,4) default NULL,
  `subtotal_with_discount` decimal(12,4) default NULL,
  `base_subtotal_with_discount` decimal(12,4) default NULL,
  `is_changed` int(10) unsigned default NULL,
  `trigger_recollect` tinyint(1) NOT NULL default '0',
  `ext_shipping_info` text,
  `gift_message_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `FK_SALES_QUOTE_STORE` (`store_id`),
  KEY `IDX_CUSTOMER` (`customer_id`,`store_id`,`is_active`),
  CONSTRAINT `FK_SALES_QUOTE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_flat_quote_address`;
CREATE TABLE `dxov_sales_flat_quote_address` (
  `address_id` int(10) unsigned NOT NULL auto_increment,
  `quote_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `customer_id` int(10) unsigned default NULL,
  `save_in_address_book` tinyint(1) default '0',
  `customer_address_id` int(10) unsigned default NULL,
  `address_type` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `prefix` varchar(40) default NULL,
  `firstname` varchar(255) default NULL,
  `middlename` varchar(40) default NULL,
  `lastname` varchar(255) default NULL,
  `suffix` varchar(40) default NULL,
  `company` varchar(255) default NULL,
  `street` varchar(255) default NULL,
  `city` varchar(255) default NULL,
  `region` varchar(255) default NULL,
  `region_id` int(10) unsigned default NULL,
  `postcode` varchar(255) default NULL,
  `country_id` varchar(255) default NULL,
  `telephone` varchar(255) default NULL,
  `fax` varchar(255) default NULL,
  `same_as_billing` tinyint(1) unsigned NOT NULL default '0',
  `free_shipping` tinyint(1) unsigned NOT NULL default '0',
  `collect_shipping_rates` tinyint(1) unsigned NOT NULL default '0',
  `shipping_method` varchar(255) NOT NULL default '',
  `shipping_description` varchar(255) NOT NULL default '',
  `weight` decimal(12,4) NOT NULL default '0.0000',
  `subtotal` decimal(12,4) NOT NULL default '0.0000',
  `base_subtotal` decimal(12,4) NOT NULL default '0.0000',
  `subtotal_with_discount` decimal(12,4) NOT NULL default '0.0000',
  `base_subtotal_with_discount` decimal(12,4) NOT NULL default '0.0000',
  `tax_amount` decimal(12,4) NOT NULL default '0.0000',
  `base_tax_amount` decimal(12,4) NOT NULL default '0.0000',
  `shipping_amount` decimal(12,4) NOT NULL default '0.0000',
  `base_shipping_amount` decimal(12,4) NOT NULL default '0.0000',
  `shipping_tax_amount` decimal(12,4) default NULL,
  `base_shipping_tax_amount` decimal(12,4) default NULL,
  `discount_amount` decimal(12,4) NOT NULL default '0.0000',
  `base_discount_amount` decimal(12,4) NOT NULL default '0.0000',
  `grand_total` decimal(12,4) NOT NULL default '0.0000',
  `base_grand_total` decimal(12,4) NOT NULL default '0.0000',
  `customer_notes` text,
  `entity_id` varchar(255) default NULL,
  `parent_id` varchar(255) default NULL,
  `custbalance_amount` varchar(255) default NULL,
  `base_custbalance_amount` varchar(255) default NULL,
  `applied_taxes` text,
  `gift_message_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`address_id`),
  KEY `FK_SALES_QUOTE_ADDRESS_SALES_QUOTE` (`quote_id`),
  CONSTRAINT `FK_SALES_QUOTE_ADDRESS_SALES_QUOTE` FOREIGN KEY (`quote_id`) REFERENCES `dxov_sales_flat_quote` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_flat_quote_address_item`;
CREATE TABLE `dxov_sales_flat_quote_address_item` (
  `address_item_id` int(10) unsigned NOT NULL auto_increment,
  `parent_item_id` int(10) unsigned default NULL,
  `quote_address_id` int(10) unsigned NOT NULL default '0',
  `quote_item_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `applied_rule_ids` text,
  `additional_data` text,
  `weight` decimal(12,4) default '0.0000',
  `qty` decimal(12,4) NOT NULL default '0.0000',
  `discount_amount` decimal(12,4) default '0.0000',
  `tax_amount` decimal(12,4) default '0.0000',
  `row_total` decimal(12,4) NOT NULL default '0.0000',
  `base_row_total` decimal(12,4) NOT NULL default '0.0000',
  `row_total_with_discount` decimal(12,4) default '0.0000',
  `base_discount_amount` decimal(12,4) default '0.0000',
  `base_tax_amount` decimal(12,4) default '0.0000',
  `row_weight` decimal(12,4) default '0.0000',
  `parent_id` varchar(255) default NULL,
  `product_id` int(10) unsigned default NULL,
  `super_product_id` int(10) unsigned default NULL,
  `parent_product_id` int(10) unsigned default NULL,
  `sku` varchar(255) default NULL,
  `image` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `description` text,
  `free_shipping` int(10) unsigned default NULL,
  `is_qty_decimal` int(10) unsigned default NULL,
  `price` decimal(12,4) default NULL,
  `discount_percent` decimal(12,4) default NULL,
  `no_discount` int(10) unsigned default NULL,
  `tax_percent` decimal(12,4) default NULL,
  `base_price` decimal(12,4) default NULL,
  `gift_message_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`address_item_id`),
  KEY `FK_QUOTE_ADDRESS_ITEM_QUOTE_ADDRESS` (`quote_address_id`),
  KEY `FK_SALES_QUOTE_ADDRESS_ITEM_QUOTE_ITEM` (`quote_item_id`),
  KEY `FK_SALES_FLAT_QUOTE_ADDRESS_ITEM_PARENT` (`parent_item_id`),
  CONSTRAINT `FK_QUOTE_ADDRESS_ITEM_QUOTE_ADDRESS` FOREIGN KEY (`quote_address_id`) REFERENCES `dxov_sales_flat_quote_address` (`address_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_FLAT_QUOTE_ADDRESS_ITEM_PARENT` FOREIGN KEY (`parent_item_id`) REFERENCES `dxov_sales_flat_quote_address_item` (`address_item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_QUOTE_ADDRESS_ITEM_QUOTE_ITEM` FOREIGN KEY (`quote_item_id`) REFERENCES `dxov_sales_flat_quote_item` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_flat_quote_item`;
CREATE TABLE `dxov_sales_flat_quote_item` (
  `item_id` int(10) unsigned NOT NULL auto_increment,
  `quote_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `product_id` int(10) unsigned default NULL,
  `parent_item_id` int(10) unsigned default NULL,
  `is_virtual` tinyint(1) unsigned default NULL,
  `sku` varchar(255) NOT NULL default '',
  `name` varchar(255) default NULL,
  `description` text,
  `applied_rule_ids` text,
  `additional_data` text,
  `free_shipping` tinyint(1) unsigned NOT NULL default '0',
  `is_qty_decimal` tinyint(1) unsigned default NULL,
  `no_discount` tinyint(1) unsigned default '0',
  `weight` decimal(12,4) default '0.0000',
  `qty` decimal(12,4) NOT NULL default '0.0000',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `base_price` decimal(12,4) NOT NULL default '0.0000',
  `custom_price` decimal(12,4) default NULL,
  `discount_percent` decimal(12,4) default '0.0000',
  `discount_amount` decimal(12,4) default '0.0000',
  `base_discount_amount` decimal(12,4) default '0.0000',
  `tax_percent` decimal(12,4) default '0.0000',
  `tax_amount` decimal(12,4) default '0.0000',
  `base_tax_amount` decimal(12,4) default '0.0000',
  `row_total` decimal(12,4) NOT NULL default '0.0000',
  `base_row_total` decimal(12,4) NOT NULL default '0.0000',
  `row_total_with_discount` decimal(12,4) default '0.0000',
  `row_weight` decimal(12,4) default '0.0000',
  `parent_id` varchar(255) default NULL,
  `product_type` varchar(255) default NULL,
  `base_tax_before_discount` decimal(12,4) default NULL,
  `tax_before_discount` decimal(12,4) default NULL,
  `original_custom_price` decimal(12,4) default NULL,
  `gift_message_id` int(10) unsigned default NULL,
  `weee_tax_applied` text,
  `weee_tax_applied_amount` decimal(12,4) default NULL,
  `weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `base_weee_tax_applied_amount` decimal(12,4) default NULL,
  `base_weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `weee_tax_disposition` decimal(12,4) default NULL,
  `weee_tax_row_disposition` decimal(12,4) default NULL,
  `base_weee_tax_disposition` decimal(12,4) default NULL,
  `base_weee_tax_row_disposition` decimal(12,4) default NULL,
  PRIMARY KEY  (`item_id`),
  KEY `FK_SALES_QUOTE_ITEM_SALES_QUOTE` (`quote_id`),
  KEY `FK_SALES_FLAT_QUOTE_ITEM_PARENT_ITEM` (`parent_item_id`),
  KEY `FK_SALES_QUOTE_ITEM_CATALOG_PRODUCT_ENTITY` (`product_id`),
  CONSTRAINT `FK_SALES_FLAT_QUOTE_ITEM_PARENT_ITEM` FOREIGN KEY (`parent_item_id`) REFERENCES `dxov_sales_flat_quote_item` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_QUOTE_ITEM_CATALOG_PRODUCT_ENTITY` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_QUOTE_ITEM_SALES_QUOTE` FOREIGN KEY (`quote_id`) REFERENCES `dxov_sales_flat_quote` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_flat_quote_item_option`;
CREATE TABLE `dxov_sales_flat_quote_item_option` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `item_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY  (`option_id`),
  KEY `FK_SALES_QUOTE_ITEM_OPTION_ITEM_ID` (`item_id`),
  CONSTRAINT `FK_SALES_QUOTE_ITEM_OPTION_ITEM_ID` FOREIGN KEY (`item_id`) REFERENCES `dxov_sales_flat_quote_item` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Additional options for quote item';

DROP TABLE IF EXISTS `dxov_sales_flat_quote_payment`;
CREATE TABLE `dxov_sales_flat_quote_payment` (
  `payment_id` int(10) unsigned NOT NULL auto_increment,
  `quote_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `method` varchar(255) default '',
  `cc_type` varchar(255) default '',
  `cc_number_enc` varchar(255) default '',
  `cc_last4` varchar(255) default '',
  `cc_cid_enc` varchar(255) default '',
  `cc_owner` varchar(255) default '',
  `cc_exp_month` tinyint(2) unsigned default '0',
  `cc_exp_year` smallint(4) unsigned default '0',
  `cc_ss_owner` varchar(255) default '',
  `cc_ss_start_month` tinyint(2) unsigned default '0',
  `cc_ss_start_year` smallint(4) unsigned default '0',
  `cybersource_token` varchar(255) default '',
  `paypal_correlation_id` varchar(255) default '',
  `paypal_payer_id` varchar(255) default '',
  `paypal_payer_status` varchar(255) default '',
  `po_number` varchar(255) default '',
  `parent_id` varchar(255) default NULL,
  `additional_data` text,
  `cc_ss_issue` varchar(255) default NULL,
  PRIMARY KEY  (`payment_id`),
  KEY `FK_SALES_QUOTE_PAYMENT_SALES_QUOTE` (`quote_id`),
  CONSTRAINT `FK_SALES_QUOTE_PAYMENT_SALES_QUOTE` FOREIGN KEY (`quote_id`) REFERENCES `dxov_sales_flat_quote` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_flat_quote_shipping_rate`;
CREATE TABLE `dxov_sales_flat_quote_shipping_rate` (
  `rate_id` int(10) unsigned NOT NULL auto_increment,
  `address_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `carrier` varchar(255) default NULL,
  `carrier_title` varchar(255) default NULL,
  `code` varchar(255) default NULL,
  `method` varchar(255) default NULL,
  `method_description` text,
  `price` decimal(12,4) NOT NULL default '0.0000',
  `parent_id` varchar(255) default NULL,
  `error_message` text,
  `method_title` text,
  PRIMARY KEY  (`rate_id`),
  KEY `FK_SALES_QUOTE_SHIPPING_RATE_ADDRESS` (`address_id`),
  CONSTRAINT `FK_SALES_QUOTE_SHIPPING_RATE_ADDRESS` FOREIGN KEY (`address_id`) REFERENCES `dxov_sales_flat_quote_address` (`address_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_order`;
CREATE TABLE `dxov_sales_order` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `increment_id` varchar(50) NOT NULL default '',
  `parent_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned default NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `is_active` tinyint(1) unsigned NOT NULL default '1',
  `customer_id` int(11) default NULL,
  `tax_amount` decimal(12,4) NOT NULL default '0.0000',
  `shipping_amount` decimal(12,4) NOT NULL default '0.0000',
  `discount_amount` decimal(12,4) NOT NULL default '0.0000',
  `subtotal` decimal(12,4) NOT NULL default '0.0000',
  `grand_total` decimal(12,4) NOT NULL default '0.0000',
  `total_paid` decimal(12,4) NOT NULL default '0.0000',
  `total_refunded` decimal(12,4) NOT NULL default '0.0000',
  `total_qty_ordered` decimal(12,4) NOT NULL default '0.0000',
  `total_canceled` decimal(12,4) NOT NULL default '0.0000',
  `total_invoiced` decimal(12,4) NOT NULL default '0.0000',
  `total_online_refunded` decimal(12,4) NOT NULL default '0.0000',
  `total_offline_refunded` decimal(12,4) NOT NULL default '0.0000',
  `base_tax_amount` decimal(12,4) NOT NULL default '0.0000',
  `base_shipping_amount` decimal(12,4) NOT NULL default '0.0000',
  `base_discount_amount` decimal(12,4) NOT NULL default '0.0000',
  `base_subtotal` decimal(12,4) NOT NULL default '0.0000',
  `base_grand_total` decimal(12,4) NOT NULL default '0.0000',
  `base_total_paid` decimal(12,4) NOT NULL default '0.0000',
  `base_total_refunded` decimal(12,4) NOT NULL default '0.0000',
  `base_total_qty_ordered` decimal(12,4) NOT NULL default '0.0000',
  `base_total_canceled` decimal(12,4) NOT NULL default '0.0000',
  `base_total_invoiced` decimal(12,4) NOT NULL default '0.0000',
  `base_total_online_refunded` decimal(12,4) NOT NULL default '0.0000',
  `base_total_offline_refunded` decimal(12,4) NOT NULL default '0.0000',
  `subtotal_refunded` decimal(12,4) default NULL,
  `subtotal_canceled` decimal(12,4) default NULL,
  `discount_refunded` decimal(12,4) default NULL,
  `discount_canceled` decimal(12,4) default NULL,
  `discount_invoiced` decimal(12,4) default NULL,
  `tax_refunded` decimal(12,4) default NULL,
  `tax_canceled` decimal(12,4) default NULL,
  `shipping_refunded` decimal(12,4) default NULL,
  `shipping_canceled` decimal(12,4) default NULL,
  `base_subtotal_refunded` decimal(12,4) default NULL,
  `base_subtotal_canceled` decimal(12,4) default NULL,
  `base_discount_refunded` decimal(12,4) default NULL,
  `base_discount_canceled` decimal(12,4) default NULL,
  `base_discount_invoiced` decimal(12,4) default NULL,
  `base_tax_refunded` decimal(12,4) default NULL,
  `base_tax_canceled` decimal(12,4) default NULL,
  `base_shipping_refunded` decimal(12,4) default NULL,
  `base_shipping_canceled` decimal(12,4) default NULL,
  `subtotal_invoiced` decimal(12,4) default NULL,
  `tax_invoiced` decimal(12,4) default NULL,
  `shipping_invoiced` decimal(12,4) default NULL,
  `base_subtotal_invoiced` decimal(12,4) default NULL,
  `base_tax_invoiced` decimal(12,4) default NULL,
  `base_shipping_invoiced` decimal(12,4) default NULL,
  `shipping_tax_amount` decimal(12,4) default NULL,
  `base_shipping_tax_amount` decimal(12,4) default NULL,
  `shipping_tax_refunded` decimal(12,4) default NULL,
  `base_shipping_tax_refunded` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `FK_SALES_ORDER_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_STORE` (`store_id`),
  KEY `IDX_CUSTOMER` (`customer_id`),
  KEY `IDX_INCREMENT_ID` (`increment_id`),
  CONSTRAINT `FK_SALE_ORDER_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_SALE_ORDER_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `dxov_sales_order_datetime`;
CREATE TABLE `dxov_sales_order_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ENTITY_ATTRIBUTE_TYPE` (`entity_id`,`attribute_id`,`entity_type_id`),
  KEY `FK_SALES_ORDER_DATETIME_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_SALES_ORDER_DATETIME` (`entity_id`),
  CONSTRAINT `FK_SALES_ORDER_DATETIME` FOREIGN KEY (`entity_id`) REFERENCES `dxov_sales_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_DATETIME_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_DATETIME_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_order_decimal`;
CREATE TABLE `dxov_sales_order_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ENTITY_ATTRIBUTE_TYPE` (`entity_id`,`attribute_id`,`entity_type_id`),
  KEY `FK_SALES_ORDER_DECIMAL_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_DECIMAL_ATTRIBUTE` (`attribute_id`),
  KEY `FK_SALES_ORDER_DECIMAL` (`entity_id`),
  CONSTRAINT `FK_SALES_ORDER_DECIMAL` FOREIGN KEY (`entity_id`) REFERENCES `dxov_sales_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_DECIMAL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_DECIMAL_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_order_entity`;
CREATE TABLE `dxov_sales_order_entity` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `increment_id` varchar(50) NOT NULL default '',
  `parent_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned default NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `is_active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`entity_id`),
  KEY `FK_SALES_ORDER_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_ENTITY_STORE` (`store_id`),
  KEY `IDX_SALES_ORDER_ENTITY_PARENT` (`parent_id`),
  CONSTRAINT `FK_SALES_ORDER_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALE_ORDER_ENTITY_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `dxov_sales_order_entity_datetime`;
CREATE TABLE `dxov_sales_order_entity_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ENTITY_ATTRIBUTE_TYPE` (`entity_id`,`attribute_id`,`entity_type_id`),
  KEY `FK_SALES_ORDER_ENTITY_DATETIME_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_ENTITY_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_SALES_ORDER_ENTITY_DATETIME` (`entity_id`),
  CONSTRAINT `FK_SALES_ORDER_ENTITY_DATETIME` FOREIGN KEY (`entity_id`) REFERENCES `dxov_sales_order_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_ENTITY_DATETIME_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_ENTITY_DATETIME_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_order_entity_decimal`;
CREATE TABLE `dxov_sales_order_entity_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ENTITY_ATTRIBUTE_TYPE` (`entity_id`,`attribute_id`,`entity_type_id`),
  KEY `FK_SALES_ORDER_ENTITY_DECIMAL_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_ENTITY_DECIMAL_ATTRIBUTE` (`attribute_id`),
  KEY `FK_SALES_ORDER_ENTITY_DECIMAL` (`entity_id`),
  CONSTRAINT `FK_SALES_ORDER_ENTITY_DECIMAL` FOREIGN KEY (`entity_id`) REFERENCES `dxov_sales_order_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_ENTITY_DECIMAL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_ENTITY_DECIMAL_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_order_entity_int`;
CREATE TABLE `dxov_sales_order_entity_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ENTITY_ATTRIBUTE_TYPE` (`entity_id`,`attribute_id`,`entity_type_id`),
  KEY `FK_SALES_ORDER_ENTITY_INT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_ENTITY_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_SALES_ORDER_ENTITY_INT` (`entity_id`),
  CONSTRAINT `FK_SALES_ORDER_ENTITY_INT` FOREIGN KEY (`entity_id`) REFERENCES `dxov_sales_order_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_ENTITY_INT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_ENTITY_INT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_order_entity_text`;
CREATE TABLE `dxov_sales_order_entity_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ENTITY_ATTRIBUTE_TYPE` (`entity_id`,`attribute_id`,`entity_type_id`),
  KEY `FK_SALES_ORDER_ENTITY_TEXT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_ENTITY_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_SALES_ORDER_ENTITY_TEXT` (`entity_id`),
  CONSTRAINT `FK_SALES_ORDER_ENTITY_TEXT` FOREIGN KEY (`entity_id`) REFERENCES `dxov_sales_order_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_ENTITY_TEXT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_ENTITY_TEXT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_order_entity_varchar`;
CREATE TABLE `dxov_sales_order_entity_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ENTITY_ATTRIBUTE_TYPE` (`entity_id`,`attribute_id`,`entity_type_id`),
  KEY `FK_SALES_ORDER_ENTITY_VARCHAR_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_ENTITY_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_SALES_ORDER_ENTITY_VARCHAR` (`entity_id`),
  CONSTRAINT `FK_SALES_ORDER_ENTITY_VARCHAR` FOREIGN KEY (`entity_id`) REFERENCES `dxov_sales_order_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_ENTITY_VARCHAR_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_ENTITY_VARCHAR_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_order_int`;
CREATE TABLE `dxov_sales_order_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ENTITY_ATTRIBUTE_TYPE` (`entity_id`,`attribute_id`,`entity_type_id`),
  KEY `FK_SALES_ORDER_INT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_SALES_ORDER_INT` (`entity_id`),
  CONSTRAINT `FK_SALES_ORDER_INT` FOREIGN KEY (`entity_id`) REFERENCES `dxov_sales_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_INT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_INT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_order_tax`;
CREATE TABLE `dxov_sales_order_tax` (
  `tax_id` int(10) unsigned NOT NULL auto_increment,
  `order_id` int(10) unsigned NOT NULL,
  `code` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `percent` decimal(12,4) NOT NULL,
  `amount` decimal(12,4) NOT NULL,
  `priority` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `base_amount` decimal(12,4) NOT NULL,
  `process` smallint(6) NOT NULL,
  `base_real_amount` decimal(12,4) NOT NULL,
  `hidden` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`tax_id`),
  KEY `IDX_ORDER_TAX` (`order_id`,`priority`,`position`),
  CONSTRAINT `FK_SALES_ORDER_TAX_ORDER` FOREIGN KEY (`order_id`) REFERENCES `dxov_sales_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_order_text`;
CREATE TABLE `dxov_sales_order_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ENTITY_ATTRIBUTE_TYPE` (`entity_id`,`attribute_id`,`entity_type_id`),
  KEY `FK_SALES_ORDER_TEXT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_SALES_ORDER_TEXT` (`entity_id`),
  CONSTRAINT `FK_SALES_ORDER_TEXT` FOREIGN KEY (`entity_id`) REFERENCES `dxov_sales_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_TEXT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_TEXT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sales_order_varchar`;
CREATE TABLE `dxov_sales_order_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ENTITY_ATTRIBUTE_TYPE` (`entity_id`,`attribute_id`,`entity_type_id`),
  KEY `FK_SALES_ORDER_VARCHAR_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_SALES_ORDER_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_SALES_ORDER_VARCHAR` (`entity_id`),
  CONSTRAINT `FK_SALES_ORDER_VARCHAR` FOREIGN KEY (`entity_id`) REFERENCES `dxov_sales_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_VARCHAR_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_SALES_ORDER_VARCHAR_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `dxov_eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_salesrule`;
CREATE TABLE `dxov_salesrule` (
  `rule_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `from_date` date default '0000-00-00',
  `to_date` date default '0000-00-00',
  `coupon_code` varchar(255) default NULL,
  `uses_per_coupon` int(11) NOT NULL default '0',
  `uses_per_customer` int(11) NOT NULL default '0',
  `customer_group_ids` varchar(255) NOT NULL default '',
  `is_active` tinyint(1) NOT NULL default '0',
  `conditions_serialized` mediumtext NOT NULL,
  `actions_serialized` mediumtext NOT NULL,
  `stop_rules_processing` tinyint(1) NOT NULL default '1',
  `is_advanced` tinyint(3) unsigned NOT NULL default '1',
  `product_ids` text,
  `sort_order` int(10) unsigned NOT NULL default '0',
  `simple_action` varchar(32) NOT NULL default '',
  `discount_amount` decimal(12,4) NOT NULL default '0.0000',
  `discount_qty` decimal(12,4) unsigned default NULL,
  `discount_step` int(10) unsigned NOT NULL,
  `simple_free_shipping` tinyint(1) unsigned NOT NULL default '0',
  `times_used` int(11) unsigned NOT NULL default '0',
  `is_rss` tinyint(4) NOT NULL default '0',
  `website_ids` text,
  PRIMARY KEY  (`rule_id`),
  KEY `sort_order` (`is_active`,`sort_order`,`to_date`,`from_date`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_salesrule_customer`;
CREATE TABLE `dxov_salesrule_customer` (
  `rule_customer_id` int(10) unsigned NOT NULL auto_increment,
  `rule_id` int(10) unsigned NOT NULL default '0',
  `customer_id` int(10) unsigned NOT NULL default '0',
  `times_used` smallint(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`rule_customer_id`),
  KEY `rule_id` (`rule_id`,`customer_id`),
  KEY `customer_id` (`customer_id`,`rule_id`),
  CONSTRAINT `FK_salesrule_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_salesrule_customer_rule` FOREIGN KEY (`rule_id`) REFERENCES `dxov_salesrule` (`rule_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sendfriend_log`;
CREATE TABLE `dxov_sendfriend_log` (
  `log_id` int(11) NOT NULL auto_increment,
  `ip` int(11) unsigned NOT NULL default '0',
  `time` int(11) NOT NULL default '0',
  PRIMARY KEY  (`log_id`),
  KEY `ip` (`ip`),
  KEY `time` (`time`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Send to friend function log storage table';

DROP TABLE IF EXISTS `dxov_shipping_tablerate`;
CREATE TABLE `dxov_shipping_tablerate` (
  `pk` int(10) unsigned NOT NULL auto_increment,
  `website_id` int(11) NOT NULL default '0',
  `dest_country_id` varchar(4) NOT NULL default '0',
  `dest_region_id` int(10) NOT NULL default '0',
  `dest_zip` varchar(10) NOT NULL default '',
  `condition_name` varchar(20) NOT NULL default '',
  `condition_value` decimal(12,4) NOT NULL default '0.0000',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `cost` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`pk`),
  UNIQUE KEY `dest_country` (`website_id`,`dest_country_id`,`dest_region_id`,`dest_zip`,`condition_name`,`condition_value`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_sitemap`;
CREATE TABLE `dxov_sitemap` (
  `sitemap_id` int(11) NOT NULL auto_increment,
  `sitemap_type` varchar(32) default NULL,
  `sitemap_filename` varchar(32) default NULL,
  `sitemap_path` tinytext,
  `sitemap_time` timestamp NULL default NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`sitemap_id`),
  KEY `FK_SITEMAP_STORE` (`store_id`),
  CONSTRAINT `FK_SITEMAP_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_tag`;
CREATE TABLE `dxov_tag` (
  `tag_id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `status` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`tag_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_tag_relation`;
CREATE TABLE `dxov_tag_relation` (
  `tag_relation_id` int(11) unsigned NOT NULL auto_increment,
  `tag_id` int(11) unsigned NOT NULL default '0',
  `customer_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(11) unsigned NOT NULL default '0',
  `store_id` smallint(6) unsigned NOT NULL default '1',
  `active` tinyint(1) unsigned NOT NULL default '1',
  `created_at` datetime default NULL,
  PRIMARY KEY  (`tag_relation_id`),
  KEY `FK_TAG_RELATION_TAG` (`tag_id`),
  KEY `FK_TAG_RELATION_CUSTOMER` (`customer_id`),
  KEY `FK_TAG_RELATION_PRODUCT` (`product_id`),
  KEY `FK_TAG_RELATION_STORE` (`store_id`),
  CONSTRAINT `FK_TAG_RELATION_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tag_relation_ibfk_1` FOREIGN KEY (`tag_id`) REFERENCES `dxov_tag` (`tag_id`) ON DELETE CASCADE,
  CONSTRAINT `tag_relation_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE,
  CONSTRAINT `tag_relation_ibfk_4` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_tag_summary`;
CREATE TABLE `dxov_tag_summary` (
  `tag_id` int(11) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `customers` int(11) unsigned NOT NULL default '0',
  `products` int(11) unsigned NOT NULL default '0',
  `uses` int(11) unsigned NOT NULL default '0',
  `historical_uses` int(11) unsigned NOT NULL default '0',
  `popularity` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`tag_id`,`store_id`),
  KEY `FK_TAG_SUMMARY_STORE` (`store_id`),
  CONSTRAINT `FK_TAG_SUMMARY_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `TAG_SUMMARY_TAG` FOREIGN KEY (`tag_id`) REFERENCES `dxov_tag` (`tag_id`) ON DELETE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_tax_calculation`;
CREATE TABLE `dxov_tax_calculation` (
  `tax_calculation_rate_id` int(11) NOT NULL,
  `tax_calculation_rule_id` int(11) NOT NULL,
  `customer_tax_class_id` smallint(6) NOT NULL,
  `product_tax_class_id` smallint(6) NOT NULL,
  KEY `FK_TAX_CALCULATION_RULE` (`tax_calculation_rule_id`),
  KEY `FK_TAX_CALCULATION_RATE` (`tax_calculation_rate_id`),
  KEY `FK_TAX_CALCULATION_CTC` (`customer_tax_class_id`),
  KEY `FK_TAX_CALCULATION_PTC` (`product_tax_class_id`),
  KEY `IDX_TAX_CALCULATION` (`tax_calculation_rate_id`,`customer_tax_class_id`,`product_tax_class_id`),
  CONSTRAINT `FK_TAX_CALCULATION_PTC` FOREIGN KEY (`product_tax_class_id`) REFERENCES `dxov_tax_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_TAX_CALCULATION_CTC` FOREIGN KEY (`customer_tax_class_id`) REFERENCES `dxov_tax_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_TAX_CALCULATION_RATE` FOREIGN KEY (`tax_calculation_rate_id`) REFERENCES `dxov_tax_calculation_rate` (`tax_calculation_rate_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_TAX_CALCULATION_RULE` FOREIGN KEY (`tax_calculation_rule_id`) REFERENCES `dxov_tax_calculation_rule` (`tax_calculation_rule_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `dxov_tax_calculation` VALUES
(1, 1, 3, 2),
(2, 1, 3, 2);

DROP TABLE IF EXISTS `dxov_tax_calculation_rate`;
CREATE TABLE `dxov_tax_calculation_rate` (
  `tax_calculation_rate_id` int(11) NOT NULL auto_increment,
  `tax_country_id` char(2) NOT NULL,
  `tax_region_id` mediumint(9) NOT NULL,
  `tax_postcode` varchar(12) NOT NULL,
  `code` varchar(255) NOT NULL,
  `rate` decimal(12,4) NOT NULL,
  PRIMARY KEY  (`tax_calculation_rate_id`),
  KEY `IDX_TAX_CALCULATION_RATE` (`tax_country_id`,`tax_region_id`,`tax_postcode`),
  KEY `IDX_TAX_CALCULATION_RATE_CODE` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `dxov_tax_calculation_rate` VALUES
(1, 'US', 12, '*', 'US-CA-*-Rate 1', '8.2500'),
(2, 'US', 43, '*', 'US-NY-*-Rate 1', '8.3750');

DROP TABLE IF EXISTS `dxov_tax_calculation_rate_title`;
CREATE TABLE `dxov_tax_calculation_rate_title` (
  `tax_calculation_rate_title_id` int(11) NOT NULL auto_increment,
  `tax_calculation_rate_id` int(11) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY  (`tax_calculation_rate_title_id`),
  KEY `IDX_TAX_CALCULATION_RATE_TITLE` (`tax_calculation_rate_id`,`store_id`),
  KEY `FK_TAX_CALCULATION_RATE_TITLE_RATE` (`tax_calculation_rate_id`),
  KEY `FK_TAX_CALCULATION_RATE_TITLE_STORE` (`store_id`),
  CONSTRAINT `FK_TAX_CALCULATION_RATE_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_TAX_CALCULATION_RATE_TITLE_RATE` FOREIGN KEY (`tax_calculation_rate_id`) REFERENCES `dxov_tax_calculation_rate` (`tax_calculation_rate_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=latin1 */;

DROP TABLE IF EXISTS `dxov_tax_calculation_rule`;
CREATE TABLE `dxov_tax_calculation_rule` (
  `tax_calculation_rule_id` int(11) NOT NULL auto_increment,
  `code` varchar(255) NOT NULL,
  `priority` mediumint(9) NOT NULL,
  `position` mediumint(9) NOT NULL,
  PRIMARY KEY  (`tax_calculation_rule_id`),
  KEY `IDX_TAX_CALCULATION_RULE` (`priority`,`position`,`tax_calculation_rule_id`),
  KEY `IDX_TAX_CALCULATION_RULE_CODE` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `dxov_tax_calculation_rule` VALUES
(1, 'Retail Customer-Taxable Goods-Rate 1', 1, 1);

DROP TABLE IF EXISTS `dxov_tax_class`;
CREATE TABLE `dxov_tax_class` (
  `class_id` smallint(6) NOT NULL auto_increment,
  `class_name` varchar(255) NOT NULL default '',
  `class_type` enum('CUSTOMER','PRODUCT') NOT NULL default 'CUSTOMER',
  PRIMARY KEY  (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `dxov_tax_class` VALUES
(2, 'Taxable Goods', 'PRODUCT'),
(3, 'Retail Customer', 'CUSTOMER'),
(4, 'Shipping', 'PRODUCT');

DROP TABLE IF EXISTS `dxov_weee_discount`;
CREATE TABLE `dxov_weee_discount` (
  `entity_id` int(10) unsigned NOT NULL default '0',
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `value` decimal(12,4) NOT NULL default '0.0000',
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_WEBSITE` (`website_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_PRODUCT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_GROUP` (`customer_group_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_GROUP` FOREIGN KEY (`customer_group_id`) REFERENCES `dxov_customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_weee_tax`;
CREATE TABLE `dxov_weee_tax` (
  `value_id` int(11) NOT NULL auto_increment,
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `country` varchar(2) NOT NULL default '',
  `value` decimal(12,4) NOT NULL default '0.0000',
  `state` varchar(255) NOT NULL default '*',
  `attribute_id` smallint(5) unsigned NOT NULL,
  `entity_type_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`value_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_WEBSITE` (`website_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_PRODUCT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_COUNTRY` (`country`),
  KEY `FK_WEEE_TAX_ATTRIBUTE_ID` (`attribute_id`),
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_COUNTRY` FOREIGN KEY (`country`) REFERENCES `dxov_directory_country` (`country_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `dxov_core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_WEEE_TAX_ATTRIBUTE_ID` FOREIGN KEY (`attribute_id`) REFERENCES `dxov_eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `dxov_wishlist`;
CREATE TABLE `dxov_wishlist` (
  `wishlist_id` int(10) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned NOT NULL default '0',
  `shared` tinyint(1) unsigned default '0',
  `sharing_code` varchar(32) /*!40101 character set latin1 */ /*!40101 collate latin1_general_ci */ NOT NULL default '',
  PRIMARY KEY  (`wishlist_id`),
  UNIQUE KEY `FK_CUSTOMER` (`customer_id`),
  CONSTRAINT `FK_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `dxov_customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ ROW_FORMAT=DYNAMIC COMMENT='Wishlist main';

DROP TABLE IF EXISTS `dxov_wishlist_item`;
CREATE TABLE `dxov_wishlist_item` (
  `wishlist_item_id` int(10) unsigned NOT NULL auto_increment,
  `wishlist_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL,
  `added_at` datetime default NULL,
  `description` text,
  PRIMARY KEY  (`wishlist_item_id`),
  KEY `FK_ITEM_WISHLIST` (`wishlist_id`),
  KEY `FK_WISHLIST_PRODUCT` (`product_id`),
  KEY `FK_WISHLIST_STORE` (`store_id`),
  CONSTRAINT `FK_WISHLIST_ITEM_STORE` FOREIGN KEY (`store_id`) REFERENCES `dxov_core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ITEM_WISHLIST` FOREIGN KEY (`wishlist_id`) REFERENCES `dxov_wishlist` (`wishlist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_WISHLIST_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `dxov_catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Wishlist items';

SET SQL_MODE=IFNULL(@OLD_SQL_MODE,'');

SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS,0);

